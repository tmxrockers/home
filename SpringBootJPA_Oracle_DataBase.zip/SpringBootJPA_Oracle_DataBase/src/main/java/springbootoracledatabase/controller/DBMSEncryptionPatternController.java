package springbootoracledatabase.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import springbootoracledatabase.entity.DataTableEntity;
import springbootoracledatabase.repository.DataTableEntityRepository;
import springbootoracledatabase.service.DataTableService;

@RestController
@RequestMapping("/oracle/database/dbms_crypto")
public class DBMSEncryptionPatternController {

	@Autowired
	private DataTableEntityRepository dataTableRepository;
	
	@Autowired
	private DataTableService dataTableService;

	@GetMapping("/getEncryptData")
	public ResponseEntity<?> getEncryptData(@RequestParam Long id) {
		Optional<DataTableEntity> dataTableEntityOptional = dataTableRepository.findById(id);
		return ResponseEntity.of(dataTableEntityOptional);
	}

	@GetMapping("/getDecryptData")
	public ResponseEntity<?> getDecryptData() {
		Optional<DataTableEntity> dataTableEntityOptional = dataTableRepository.findById(1L);
		return ResponseEntity.of(dataTableEntityOptional);
	}
	
	@PostMapping("/save")
	public ResponseEntity<?> save(@RequestParam Long id, @RequestParam String originalData) {
		DataTableEntity dataTableEntity = new DataTableEntity();
		dataTableEntity.setId(id);
		dataTableEntity.setOriginalData(originalData);
		DataTableEntity dataTableEntityOptional = dataTableService.saveDataTableEntity(dataTableEntity);
		return ResponseEntity.of(Optional.of(dataTableEntityOptional));
	}
}
