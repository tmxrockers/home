package springbootoracledatabase.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Formula;
import org.hibernate.annotations.Type;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "data_table")
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class DataTableEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	private Long id;

	@Column(name = "original_data")
	private String originalData;

	@Column(name = "encrypted_data")
	@Type(type = "org.hibernate.type.BinaryType")
	private byte[] encryptedData;

	@Formula("DECRYPT_DATA(encrypted_data)")
	private String decryptedData;
	
}
