package springbootoracledatabase.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import springbootoracledatabase.entity.DataTableEntity;

@Repository
public interface DataTableEntityRepository extends JpaRepository<DataTableEntity, Long>, DataTableEntityRepositoryCustom {

}