package springbootoracledatabase.repository;

public interface DataTableEntityRepositoryCustom {
	
	byte[] callEncryptFunction(String data);

	String callDecryptFunction(String data);
}
