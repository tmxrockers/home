package springbootoracledatabase.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

public class DataTableEntityRepositoryImpl implements DataTableEntityRepositoryCustom {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    @Transactional
    public byte[] callEncryptFunction(String data) {
        // Call your database function to encrypt data
        // Example using EntityManager
    	return (byte[]) entityManager.createNativeQuery("SELECT encrypt_data(:data) FROM DUAL")
                .setParameter("data", data)
                .getSingleResult();
    }

    @Override
    @Transactional
    public String callDecryptFunction(String data) {
        // Call your database function to decrypt data
        // Example using EntityManager
        return (String) entityManager.createNativeQuery("SELECT decrypt_data(:data) FROM DUAL")
                .setParameter("data", data)
                .getSingleResult();
    }
}
