package springbootoracledatabase.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import springbootoracledatabase.entity.DataTableEntity;
import springbootoracledatabase.repository.DataTableEntityRepository;

@Service
public class DataTableService {

	@Autowired
	private DataTableEntityRepository dataTableEntityRepository;

	public DataTableEntity saveDataTableEntity(DataTableEntity dataTableEntity) {
		// Call your encryption function before persisting the entity
		byte[] encryptedValue = dataTableEntityRepository.callEncryptFunction(dataTableEntity.getOriginalData());
		dataTableEntity.setEncryptedData(encryptedValue);

		return dataTableEntityRepository.save(dataTableEntity);
	}

}
