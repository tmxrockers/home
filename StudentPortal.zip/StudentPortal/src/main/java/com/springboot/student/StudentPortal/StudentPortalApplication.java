package com.springboot.student.StudentPortal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@SpringBootApplication
public class StudentPortalApplication implements WebMvcConfigurer{

	private static final Logger logger = LoggerFactory.getLogger(StudentPortalApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(StudentPortalApplication.class, args);
		logger.info("Application Started");
	}

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/static/**").addResourceLocations("classpath:/static/");
        registry.addResourceHandler("/webjars/**").addResourceLocations("/webjars/");

    }
}
