package com.springboot.student.StudentPortal.repository;

import org.springframework.data.repository.CrudRepository;

import com.springboot.student.StudentPortal.model.User;

/**
 * The UserRepository class
 *
 * @author 
 * @version 1.0
 */
public interface UserRepository extends CrudRepository<User, Integer> {

    User findByUsername(String username);

    User findByEmail(String email);
}