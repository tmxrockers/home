package com.springboot.student.StudentPortal.service;

import java.util.List;

import com.springboot.student.StudentPortal.model.Student;

public interface StudentService {

	Student save(Student student);

    Boolean delete(int id);

    Student update(Student task);

    Student findById(int id);

    List<Student> findAll();
}
