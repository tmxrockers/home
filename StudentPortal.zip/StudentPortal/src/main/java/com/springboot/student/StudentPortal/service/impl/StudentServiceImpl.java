package com.springboot.student.StudentPortal.service.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.student.StudentPortal.model.Student;
import com.springboot.student.StudentPortal.repository.StudentRepository;
import com.springboot.student.StudentPortal.service.StudentService;

/**
 * 
 * @author
 *
 */
@Service
@Transactional
public class StudentServiceImpl implements StudentService {

	@Autowired
	private StudentRepository studentRepository;
	
	@Override
	public Student save(Student student) {
		return studentRepository.save(student);
	}

	@Override
	public Boolean delete(int studentId) {
		if(studentRepository.existsById(studentId)) {
			studentRepository.deleteById(studentId);
			return true;
		}
		return false;
	}

	@Override
	public Student update(Student student) {
		return save(student);
	}

	@Override
	public Student findById(int studentId) {
		return studentRepository.findById(studentId).get();
	}

	@Override
	public List<Student> findAll() {
		return (List<Student>) studentRepository.findAll();
	}

}
