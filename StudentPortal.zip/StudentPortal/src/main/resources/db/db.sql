create schema student_database;

CREATE TABLE IF NOT EXISTS student_database.student (
    student_id INT AUTO_INCREMENT,
    student_name VARCHAR(255),
    gender VARCHAR(255),
    college VARCHAR(255),
    dept VARCHAR(255),
    cgpa VARCHAR(255) NOT NULL,
    PRIMARY KEY (student_id)
);

CREATE TABLE IF NOT EXISTS student_database.user (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NULL,
    password VARCHAR(255) NULL,
    role INT NULL,
    username VARCHAR(255) NULL
);



INSERT INTO student_database.student (
	student_id,
	student_name ,
    gender,
	college,
	dept,
    cgpa    
)  values(101, 'Arun', 'Male','MIT','EEE','9.8');

INSERT INTO student_database.student (
	student_id,
	student_name ,
    gender,
	college,
	dept,
    cgpa    
)  values(102, 'Mellvin', 'Male','IIT','EEE','9.8');

INSERT INTO student_database.student (
	student_id,
	student_name ,
    gender,
	college,
	dept,
    cgpa    
)  values(103, 'Jiju', 'Male','CIT','ECE','9.9');

