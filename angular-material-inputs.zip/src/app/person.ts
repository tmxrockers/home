export interface Person {
  username: string;
  password: string;
  address: string;
  favColor: string;
  dob: string;
  tob: string;
  age: number;
}