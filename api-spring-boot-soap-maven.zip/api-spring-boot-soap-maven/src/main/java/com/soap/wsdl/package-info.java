@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://tempuri.org/", elementFormDefault = jakarta.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.soap.wsdl;
