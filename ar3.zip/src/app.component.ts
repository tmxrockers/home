import { ChangeDetectionStrategy, Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { HeaderComponent } from './components/header/header.component';
import { DashboardContentComponent } from './components/dashboard-content/dashboard-content.component';
import { FooterComponent } from './components/footer/footer.component';
import { User } from './app/services/rbac.service';
import { RolesConfigComponent } from './components/roles-config/roles-config.component';
import { ReportingDashboardComponent } from './components/reporting-dashboard/reporting-dashboard.component';

export type UserRole = 'admin' | 'dataLoader' | 'staffingOps' | 'auditor' | 'manager' | 'hrPartner' | 'financeAnalyst' | 'itSupport' | string;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, SidebarComponent, HeaderComponent, DashboardContentComponent, FooterComponent, RolesConfigComponent, ReportingDashboardComponent],
})
export class AppComponent {
  isSidebarOpen = signal(true);
  selectedPage = signal<string>('dashboard');
  
  // Mock users for demonstration
  users: User[] = [
    { id: 'u1', name: 'Admin User', email: 'admin@test.com', role: 'admin' },
    { id: 'u2', name: 'Data Loader User', email: 'dataloader@test.com', role: 'dataLoader' },
    { id: 'u3', name: 'Staffing Ops User', email: 'staffing@test.com', role: 'staffingOps' },
  ];
  
  currentUser = signal<User>(this.users[0]);

  toggleSidebar(): void {
    this.isSidebarOpen.update(v => !v);
  }

  changeUser(userId: string): void {
    const user = this.users.find(u => u.id === userId);
    if (user) {
      this.currentUser.set(user);
    }
  }

  onMenuItemSelected(pageId: string): void {
    this.selectedPage.set(pageId);
  }
}