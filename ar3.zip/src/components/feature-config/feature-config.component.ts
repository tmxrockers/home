import { ChangeDetectionStrategy, Component, computed, effect, ElementRef, inject, OnDestroy, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RbacService, MenuItem } from '../../app/services/rbac.service';
import { Subscription } from 'rxjs';
import { ConfirmationDialogComponent } from '../confirmation-dialog/confirmation-dialog.component';

interface AppRoute {
  path: string;
  name: string;
}

interface AppIcon {
  name: string;
  id: string;
}

const MAX_LABEL_LENGTH = 50;

@Component({
  selector: 'app-feature-config',
  templateUrl: './feature-config.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, ConfirmationDialogComponent],
  host: {
    '(document:click)': 'onDocumentClick($event)',
  }
})
export class FeatureConfigComponent implements OnDestroy {
  private rbacService = inject(RbacService);
  private subscriptions = new Subscription();
  private elementRef = inject(ElementRef);

  allFeatures = signal<MenuItem[]>([]);
  searchTerm = signal<string>('');
  
  private initialFeatures: MenuItem[] = [];
  private allFeaturesFlat = new Map<string, { item: MenuItem, parentId: string | null }>();

  // Local state for confirmation dialogs
  isConfirmSaveOpen = signal(false);
  isConfirmDiscardOpen = signal(false);
  isConfirmDeleteOpen = signal(false);
  itemToDelete = signal<{ id: string } | null>(null);

  successMessage = signal('');
  private successMessageTimeout: any;

  // For card accordion
  expandedFeatures = signal<Set<string>>(new Set());
  
  // For drag and drop
  draggedItemId = signal<string | null>(null);
  draggedItemParentId = signal<string | null>(null);
  dragOverId = signal<string | null>(null);
  dropPosition = signal<'before' | 'after' | null>(null);

  // For inline description editing
  editingDescriptionId = signal<string | null>(null);
  editingDescriptionValue = signal<string>('');

  // For inline label editing
  editingLabelId = signal<string | null>(null);
  editingLabelValue = signal<string>('');
  editingLabelError = signal<string | null>(null);

  // For Add/Edit Menu Item Modal
  isMenuModalOpen = signal(false);
  menuModalParentId = signal<string | null>(null);
  menuItemLabel = signal('');
  menuItemDescription = signal('');
  menuItemRoute = signal<string>('');
  menuItemIcon = signal<string>('');
  menuItemValidationError = signal<string | null>(null);
  menuItemRouteError = signal<string | null>(null);
  maxLabelLength = MAX_LABEL_LENGTH;

  isIconPickerOpen = signal(false);
  iconSearchTerm = signal('');

  availableRoutes: AppRoute[] = [
    { path: '/dashboard', name: 'Dashboard' },
    { path: '/user-access', name: 'User Access Management' },
    { path: '/service-desk', name: 'Service Desk' },
    { path: '/reports', name: 'Reports' },
    { path: '/file-upload', name: 'File Upload' },
    { path: '/config/staffing', name: 'Staffing Ops Config' },
  ];

  availableIcons: AppIcon[] = [
    { name: 'Dashboard', id: 'dashboard' },
    { name: 'Users', id: 'group' },
    { name: 'Support', id: 'support_agent' },
    { name: 'Settings', id: 'settings' },
    { name: 'Reports', id: 'assessment' },
    { name: 'Analytics', id: 'analytics' },
    { name: 'Building', id: 'business' },
    { name: 'Briefcase', id: 'work' },
    { name: 'Upload', id: 'upload_file' },
    { name: 'Download', id: 'download' },
    { name: 'History', id: 'history' },
    { name: 'Security', id: 'security' },
    { name: 'Star', id: 'star' },
    { name: 'Globe', id: 'public' },
    { name: 'Tasks', id: 'task_alt' },
    { name: 'Megaphone', id: 'campaign' },
    { name: 'View Grid', id: 'grid_view' },
  ];

  filteredIcons = computed(() => {
    const term = this.iconSearchTerm().toLowerCase();
    if (!term) return this.availableIcons;
    return this.availableIcons.filter(icon => icon.name.toLowerCase().includes(term));
  });

  isDirty = computed(() => {
    return JSON.stringify(this.initialFeatures) !== JSON.stringify(this.allFeatures());
  });

  filteredFeatures = computed(() => {
    const term = this.searchTerm().toLowerCase().trim();
    if (!term) {
      return this.allFeatures();
    }

    const results: MenuItem[] = [];
    for (const feature of this.allFeatures()) {
      const matchingChildren = feature.children?.filter(child => 
        child.label.toLowerCase().includes(term) || child.description?.toLowerCase().includes(term)
      ) ?? [];

      const featureMatch = feature.label.toLowerCase().includes(term) || feature.description?.toLowerCase().includes(term);

      if (featureMatch || matchingChildren.length > 0) {
        const newFeature = { ...feature };
        if (featureMatch) {
          newFeature.children = feature.children;
        } else {
          newFeature.children = matchingChildren;
        }
        results.push(newFeature);
      }
    }
    return results;
  });

  constructor() {
    this.loadInitialState();
    
    effect(() => {
      this.rbacService.featureDirty.set(this.isDirty());
    });

    this.subscriptions.add(
      this.rbacService.discardFeatureChanges$.subscribe(() => {
        this.resetState();
      })
    );
  }
  
  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  private showSuccessMessage(message: string): void {
    this.successMessage.set(message);
    clearTimeout(this.successMessageTimeout);
    this.successMessageTimeout = setTimeout(() => this.successMessage.set(''), 3000);
  }

  onDocumentClick(event: MouseEvent): void {
    if (this.isIconPickerOpen() && !this.elementRef.nativeElement.querySelector('.icon-picker-container')?.contains(event.target)) {
        this.isIconPickerOpen.set(false);
    }
  }

  private loadInitialState(): void {
    const features = this.rbacService.getRawFeatures();
    // Deep copy for pristine state
    this.initialFeatures = JSON.parse(JSON.stringify(features));
    this.allFeatures.set(JSON.parse(JSON.stringify(features)));
    this.rebuildFlatMap();
  }

  private rebuildFlatMap(): void {
    this.allFeaturesFlat.clear();
    const processFeatures = (items: MenuItem[], parentId: string | null = null) => {
      for (const item of items) {
        this.allFeaturesFlat.set(item.id, { item, parentId });
        if (item.children) {
          processFeatures(item.children, item.id);
        }
      }
    };
    processFeatures(this.allFeatures());
  }

  private resetState(): void {
    this.allFeatures.set(JSON.parse(JSON.stringify(this.initialFeatures)));
    this.cancelDescriptionEdit();
    this.cancelLabelEdit();
    this.rebuildFlatMap();
  }
  
  private findFeatureById(id: string, features: MenuItem[]): MenuItem | undefined {
    for (const feature of features) {
        if (feature.id === id) return feature;
        if (feature.children) {
            const found = this.findFeatureById(id, feature.children);
            if (found) return found;
        }
    }
    return undefined;
  }

  onSearchTermChange(event: Event): void {
    this.searchTerm.set((event.target as HTMLInputElement).value);
  }

  onStatusChange(featureId: string, event: Event): void {
    const isActive = (event.target as HTMLInputElement).checked;

    const updateStatusesRecursively = (items: MenuItem[], targetId: string, newStatus: boolean): MenuItem[] => {
      return items.map(item => {
        let newItem = { ...item };
        if (newItem.id === targetId) {
          newItem.isActive = newStatus;
          // If a parent is deactivated, deactivate all children recursively
          if (!newStatus && newItem.children) {
            const deactivateChildren = (children: MenuItem[]): MenuItem[] => {
              return children.map(child => ({
                ...child,
                isActive: false,
                children: child.children ? deactivateChildren(child.children) : child.children,
              }));
            };
            newItem.children = deactivateChildren(newItem.children);
          }
        } else if (item.children) {
          // Recurse on children if this isn't the target item
          newItem.children = updateStatusesRecursively(item.children, targetId, newStatus);
        }
        return newItem;
      });
    };

    this.allFeatures.update(features => {
      let updatedFeatures = updateStatusesRecursively(features, featureId, isActive);

      // If activating a child, ensure all its parents are also activated
      if (isActive) {
        const activateParents = (childId: string, currentFeatures: MenuItem[]) => {
          let parentId = this.allFeaturesFlat.get(childId)?.parentId;
          while (parentId) {
            const parentToActivate = this.findFeatureById(parentId, currentFeatures);
            if (parentToActivate) {
              parentToActivate.isActive = true;
            }
            parentId = this.allFeaturesFlat.get(parentId)?.parentId;
          }
        };
        activateParents(featureId, updatedFeatures);
      }
      
      return updatedFeatures;
    });
  }
  
  private validateLabel(label: string, idToIgnore: string | null, parentId: string | null): string | null {
    const trimmedLabel = label.trim();
    if (trimmedLabel.length > MAX_LABEL_LENGTH) {
      return `Label cannot exceed ${MAX_LABEL_LENGTH} characters.`;
    }
    
    let siblings: MenuItem[] = [];
    if (parentId) {
      const parent = this.findFeatureById(parentId, this.allFeatures());
      siblings = parent?.children || [];
    } else {
      siblings = this.allFeatures();
    }

    const isDuplicate = siblings.some(item => 
      item.id !== idToIgnore && item.label.trim().toLowerCase() === trimmedLabel.toLowerCase()
    );

    if (isDuplicate) {
      return "Another menu item at this level already has this label.";
    }

    return null;
  }

  private validateRoute(route: string, parentId: string | null): string | null {
    if (!route) {
        return null; // No route selected, so no error.
    }

    let siblings: MenuItem[] = [];
    if (parentId) {
        const parent = this.findFeatureById(parentId, this.allFeatures());
        siblings = parent?.children || [];
    } else {
        siblings = this.allFeatures();
    }

    const isDuplicate = siblings.some(item => item.route === route);

    if (isDuplicate) {
        return "This route is already in use at this level.";
    }

    return null;
  }

  // --- Label Edit Handlers ---
  startEditingLabel(item: MenuItem): void {
    if (this.editingDescriptionId() !== null) return; // Prevent simultaneous editing
    this.editingLabelId.set(item.id);
    this.editingLabelValue.set(item.label);
    this.editingLabelError.set(null);
  }

  saveLabelEdit(): void {
    const idToUpdate = this.editingLabelId();
    if (!idToUpdate) return;
    
    const parentId = this.allFeaturesFlat.get(idToUpdate)?.parentId ?? null;
    const validationError = this.validateLabel(this.editingLabelValue(), idToUpdate, parentId);

    if (validationError) {
      this.editingLabelError.set(validationError);
      return;
    }

    const newLabel = this.editingLabelValue().trim();
    if (!newLabel) return;

    const updateLabelRecursively = (items: MenuItem[]): MenuItem[] => {
      return items.map(item => {
        const newItem = { ...item };
        if (newItem.id === idToUpdate) {
          newItem.label = newLabel;
        }
        if (newItem.children) {
          newItem.children = updateLabelRecursively(newItem.children);
        }
        return newItem;
      });
    };

    this.allFeatures.update(currentFeatures => updateLabelRecursively(currentFeatures));
    this.cancelLabelEdit();
  }

  cancelLabelEdit(): void {
    this.editingLabelId.set(null);
    this.editingLabelValue.set('');
    this.editingLabelError.set(null);
  }


  // --- Description Edit Handlers ---
  startEditingDescription(feature: MenuItem): void {
    if (this.editingLabelId() !== null) return; // Prevent simultaneous editing
    this.editingDescriptionId.set(feature.id);
    this.editingDescriptionValue.set(feature.description || '');
  }

  saveDescriptionEdit(): void {
    const idToUpdate = this.editingDescriptionId();
    if (!idToUpdate) return;
    
    const newDescription = this.editingDescriptionValue();

    const updateDescriptionRecursively = (items: MenuItem[]): MenuItem[] => {
      return items.map(item => {
        const newItem = { ...item };
        if (newItem.id === idToUpdate) {
          newItem.description = newDescription;
        }
        if (newItem.children) {
          newItem.children = updateDescriptionRecursively(newItem.children);
        }
        return newItem;
      });
    };

    this.allFeatures.update(currentFeatures => updateDescriptionRecursively(currentFeatures));
    this.cancelDescriptionEdit();
  }

  cancelDescriptionEdit(): void {
    this.editingDescriptionId.set(null);
    this.editingDescriptionValue.set('');
  }

  // --- Drag and Drop Handlers ---
  onDragStart(event: DragEvent, featureId: string, parentId: string | null): void {
    event.dataTransfer?.setData('text/plain', featureId);
    event.dataTransfer!.effectAllowed = 'move';
    this.draggedItemId.set(featureId);
    this.draggedItemParentId.set(parentId);
  }

  onDragOver(event: DragEvent, featureId: string, parentId: string | null): void {
    event.preventDefault();
    const draggedItemId = this.draggedItemId();
    // Only allow dropping within the same list (same parent)
    if (draggedItemId && draggedItemId !== featureId && this.draggedItemParentId() === parentId) {
        const rect = (event.currentTarget as HTMLElement).getBoundingClientRect();
        // Determine if dragging over top or bottom half of element
        const isAfter = event.clientY > rect.top + rect.height / 2;
        this.dropPosition.set(isAfter ? 'after' : 'before');
        this.dragOverId.set(featureId);
    }
  }

  onDragLeave(event: DragEvent): void {
    event.preventDefault();
    this.dragOverId.set(null);
    this.dropPosition.set(null);
  }

  onDrop(event: DragEvent, targetFeatureId: string, targetParentId: string | null): void {
    event.preventDefault();
    const draggedItemId = this.draggedItemId();
    const draggedItemParentId = this.draggedItemParentId();
    const dropPos = this.dropPosition();

    // Reset drag state immediately
    this.dragOverId.set(null);
    this.dropPosition.set(null);
    this.draggedItemId.set(null);
    this.draggedItemParentId.set(null);

    if (!draggedItemId || draggedItemId === targetFeatureId || draggedItemParentId !== targetParentId) {
      return;
    }

    this.allFeatures.update(currentFeatures => {
      // Deep clone to ensure immutability and trigger change detection
      const newFeatures = JSON.parse(JSON.stringify(currentFeatures));
      
      let parentChildrenList: MenuItem[];
      if (targetParentId === null) {
        parentChildrenList = newFeatures;
      } else {
        const parentFeature = this.findFeatureById(targetParentId, newFeatures);
        if (!parentFeature || !parentFeature.children) {
          return currentFeatures; // Abort if parent not found
        }
        parentChildrenList = parentFeature.children;
      }

      const draggedIndex = parentChildrenList.findIndex(item => item.id === draggedItemId);
      let targetIndex = parentChildrenList.findIndex(item => item.id === targetFeatureId);

      if (draggedIndex === -1 || targetIndex === -1) {
        return currentFeatures; // Abort if items not found
      }

      // Perform the move
      const [draggedItem] = parentChildrenList.splice(draggedIndex, 1);
      if (dropPos === 'after') {
        targetIndex++;
      }
      parentChildrenList.splice(targetIndex, 0, draggedItem);
      
      if (targetParentId === null) {
        return parentChildrenList;
      }
      
      return newFeatures;
    });
  }

  // --- Add/Edit Modal Handlers ---
  onModalLabelChange(value: string) {
    this.menuItemLabel.set(value);
    const validationError = this.validateLabel(value, null, this.menuModalParentId());
    this.menuItemValidationError.set(validationError);
  }

  onModalRouteChange(value: string) {
    this.menuItemRoute.set(value);
    const validationError = this.validateRoute(value, this.menuModalParentId());
    this.menuItemRouteError.set(validationError);
  }

  openNewMenuModal(): void {
    this.menuModalParentId.set(null);
    this.menuItemLabel.set('');
    this.menuItemDescription.set('');
    this.menuItemRoute.set('');
    this.menuItemIcon.set('');
    this.menuItemValidationError.set(null);
    this.menuItemRouteError.set(null);
    this.isMenuModalOpen.set(true);
  }

  openNewSubMenuModal(parentId: string): void {
    this.menuModalParentId.set(parentId);
    this.menuItemLabel.set('');
    this.menuItemDescription.set('');
    this.menuItemRoute.set('');
    this.menuItemIcon.set('');
    this.menuItemValidationError.set(null);
    this.menuItemRouteError.set(null);
    this.isMenuModalOpen.set(true);
  }

  closeMenuModal(): void {
    this.isMenuModalOpen.set(false);
    this.isIconPickerOpen.set(false);
    this.iconSearchTerm.set('');
  }

  selectIcon(iconId: string): void {
    this.menuItemIcon.set(iconId);
    this.isIconPickerOpen.set(false);
  }

  saveMenuItem(): void {
    const label = this.menuItemLabel().trim();
    if (!label || this.menuItemValidationError() || this.menuItemRouteError()) return;

    const newItem: MenuItem = {
      id: label.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') + `-${Date.now()}`,
      label: label,
      description: this.menuItemDescription().trim(),
      route: this.menuItemRoute(),
      icon: this.menuItemIcon(),
      isActive: true,
      children: [],
    };
    
    const parentId = this.menuModalParentId();
    if (parentId) {
      const addAsChild = (items: MenuItem[], pId: string, nItem: MenuItem): MenuItem[] => {
        return items.map(item => {
          if (item.id === pId) {
            return { ...item, children: [...(item.children || []), nItem] };
          }
          if (item.children) {
            return { ...item, children: addAsChild(item.children, pId, nItem) };
          }
          return item;
        });
      };
      this.allFeatures.update(features => addAsChild(features, parentId, newItem));
      this.expandedFeatures.update(current => new Set(current).add(parentId));
    } else {
      this.allFeatures.update(features => [...features, newItem]);
    }

    this.rebuildFlatMap();
    this.closeMenuModal();
  }
  
  // --- Delete Handlers ---
  promptDeleteMenuItem(id: string): void {
    this.itemToDelete.set({ id });
    this.isConfirmDeleteOpen.set(true);
  }

  onConfirmDelete(): void {
    const idToDelete = this.itemToDelete()?.id;
    if (!idToDelete) return;
    
    const removeItemRecursively = (items: MenuItem[], id: string): MenuItem[] => {
      const filtered = items.filter(item => item.id !== id);
      return filtered.map(item => {
        if (item.children) {
          return { ...item, children: removeItemRecursively(item.children, id) };
        }
        return item;
      });
    };
    
    this.allFeatures.update(features => removeItemRecursively(features, idToDelete));
    this.rebuildFlatMap();
    this.onCancelDelete();
  }

  onCancelDelete(): void {
    this.isConfirmDeleteOpen.set(false);
    this.itemToDelete.set(null);
  }

  // --- Local Save/Discard with Confirmation ---
  saveChanges(): void {
    if (!this.isDirty()) return;
    this.isConfirmSaveOpen.set(true);
  }

  discardChanges(): void {
    if (!this.isDirty()) return;
    this.isConfirmDiscardOpen.set(true);
  }

  onConfirmSave(): void {
    this.rbacService.updateFeatures(this.allFeatures());
    this.loadInitialState(); // Reloads and resets dirty state
    this.isConfirmSaveOpen.set(false);
    this.showSuccessMessage('Menu structure changes saved successfully.');
  }

  onCancelSave(): void {
    this.isConfirmSaveOpen.set(false);
  }

  onConfirmDiscard(): void {
    this.resetState();
    this.isConfirmDiscardOpen.set(false);
    this.showSuccessMessage('Unsaved changes to the menu structure have been discarded.');
  }

  onCancelDiscard(): void {
    this.isConfirmDiscardOpen.set(false);
  }

  toggleFeature(featureId: string): void {
    this.expandedFeatures.update(current => {
      const newSet = new Set(current);
      if (newSet.has(featureId)) {
        newSet.delete(featureId);
      } else {
        newSet.add(featureId);
      }
      return newSet;
    });
  }

  isExpanded(featureId: string): boolean {
    return this.expandedFeatures().has(featureId);
  }

  getSelectedIconName(): string {
    const selectedId = this.menuItemIcon();
    if (!selectedId) return 'Select Icon';
    const icon = this.availableIcons.find(i => i.id === selectedId);
    return icon ? icon.name : 'Select Icon';
  }
}