import { ChangeDetectionStrategy, Component, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';

// --- New Data Structures based on user's JSON ---
interface ErrorColumnDetail {
  columnName: string;
  columnValue: string;
  isError: boolean;
  isMandate: boolean;
  maxLength: number;
  dataType: string;
  errorMessage: string;
  detailedError: string | null;
  uiValidationPattern: string | null;
  dbColumnName: string;
  hasError: boolean;
}

interface BulkErrorRecord {
  // Key identifiers
  rowNum: number;
  transId: string;
  uploadType: string;
  contractorId: string;
  
  // State flags
  autoCorrected: boolean;
  fixed: boolean;
  rowDeleted: boolean;

  // Error details
  errorField: string;
  errorColumn: ErrorColumnDetail;
  
  // Flattened reference data
  resourceName: string;
  resourceId: string; // From 'Resource ID'
  personId: string;

  // UI-only unique ID
  id: string; 
}


interface EtlFile {
  etlTransId: string;
  uploadType: string;
  uploadedOn: string;
  totalRecords: number;
  uploadedVersion: number;
  errorRecords: number;
}

interface FieldValidationRules {
    dataType: string;
    maxLength: number;
    uiValidationPattern: string | null;
    isMandate: boolean;
}

type RecordState = 'pending' | 'auto-corrected' | 'corrected' | 'deleted';


@Component({
  selector: 'app-bulk-edit',
  imports: [CommonModule],
  templateUrl: './bulk-edit.component.html',
  styleUrl: './bulk-edit.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class BulkEditComponent {
  // --- Component State ---
  file = signal<EtlFile | null>(null);
  errorRecords = signal<BulkErrorRecord[]>([]);

  // --- UI State Signals ---
  selectedErrorField = signal<string>('');
  correctionValue = signal('');
  correctionValueError = signal<string | null>(null);
  selectedRecordIds = signal<Set<string>>(new Set());
  isApplyingChanges = signal(false);
  
  // Delete confirmation state
  isDeleteConfirmOpen = signal(false);
  recordToDelete = signal<BulkErrorRecord | null>(null);
  
  // Field change confirmation state
  isConfirmFieldChangeOpen = signal(false);
  pendingFieldNameChange = signal<string | null>(null);

  // Page size change confirmation state
  isConfirmPageSizeChangeOpen = signal(false);
  pendingPageSizeChange = signal<number | null>(null);

  // Filter change confirmation state
  isConfirmFilterChangeOpen = signal(false);
  pendingFilterChange = signal<{ filter: 'pending' | 'auto-corrected'; value: boolean } | null>(null);

  // Filters
  showPending = signal(false);
  showAutoCorrected = signal(false);

  // Pagination
  currentPage = signal(1);
  pageSize = signal(8);
  pageSizeOptions = [8, 16, 24, 32];
  
  constructor() {
    // Initialize component with mock data
    const mockFile: EtlFile = { 
      uploadType: 'SP Headcount Monthly',
      etlTransId: '9050',
      uploadedOn: '11/21/2025',
      totalRecords: 2326,
      uploadedVersion: 9,
      errorRecords: 500
    };
    this.file.set(mockFile);
    this.errorRecords.set(this.generateMockErrorRecords(mockFile));
  }

  // --- Computed Signals ---
  errorFieldsForSelection = computed(() => {
    const fields = new Set<string>();
    this.errorRecords().forEach(record => fields.add(record.errorField));
    return Array.from(fields).sort();
  });

  recordsForSelectedField = computed(() => {
    const field = this.selectedErrorField();
    if (!field) return [];

    const showAuto = this.showAutoCorrected();
    const showPend = this.showPending();

    return this.errorRecords().filter(record => {
      if (record.errorField !== field) return false;

      // When both toggles are off, show everything for the field.
      if (!showPend && !showAuto) {
        return true;
      }

      const state = this.getRecordState(record);
      
      // If 'Show Pending' is on, show ONLY pending records
      if (showPend) {
        return state === 'pending';
      }
      
      // If 'Show Auto-Corrected' is on, show ONLY auto-corrected records
      if (showAuto) {
        return state === 'auto-corrected';
      }

      // Fallback for any other case (shouldn't be reached with current logic)
      return false;
    });
  });
  
  sortedAndPaginatedRecords = computed(() => {
    const records = this.recordsForSelectedField();
    
    const sorted = [...records].sort((a, b) => {
        const aStateValue = this.getRecordStateValue(a);
        const bStateValue = this.getRecordStateValue(b);
        if (aStateValue !== bStateValue) return aStateValue - bStateValue;
        
        return a.resourceName.localeCompare(b.resourceName);
    });

    const startIndex = (this.currentPage() - 1) * this.pageSize();
    return sorted.slice(startIndex, startIndex + this.pageSize());
  });

  totalRecordsForPagination = computed(() => this.recordsForSelectedField().length);
  totalPages = computed(() => Math.ceil(this.totalRecordsForPagination() / this.pageSize()));
  paginationPages = computed(() => Array.from({ length: this.totalPages() }, (_, i) => i + 1));
  
  paginationStartIndex = computed(() => {
    const total = this.totalRecordsForPagination();
    if (total === 0) return 0;
    return (this.currentPage() - 1) * this.pageSize() + 1;
  });

  paginationEndIndex = computed(() => {
    return Math.min(this.currentPage() * this.pageSize(), this.totalRecordsForPagination());
  });
  
  selectedFieldValidationRules = computed<FieldValidationRules | null>(() => {
    const field = this.selectedErrorField();
    if (!field) return null;
    const firstRecord = this.recordsForSelectedField()[0];
    if (!firstRecord) return null;
    const rules = firstRecord.errorColumn;
    return {
        dataType: rules.dataType,
        maxLength: rules.maxLength,
        uiValidationPattern: rules.uiValidationPattern,
        isMandate: rules.isMandate
    };
  });

  isAllVisibleSelected = computed(() => {
    const visibleIds = this.sortedAndPaginatedRecords()
        .filter(r => {
          const state = this.getRecordState(r);
          return state === 'pending' || state === 'auto-corrected' || state === 'corrected';
        })
        .map(r => r.id);
    if(visibleIds.length === 0) return false;
    return visibleIds.every(id => this.selectedRecordIds().has(id));
  });

  deleteConfirmationMessage = computed(() => {
     const record = this.recordToDelete();
     if (!record) return 'Are you sure you want to delete this record?';
     return `Are you sure you want to mark the record for "${record.resourceName}" (PID: ${record.personId}) for deletion?`;
   });
  
  // --- Methods ---

  getRecordState(record: BulkErrorRecord): RecordState {
    if (record.rowDeleted) return 'deleted';
    if (record.fixed) return 'corrected';
    if (record.autoCorrected) return 'auto-corrected';
    return 'pending';
  }

  private getRecordStateValue(record: BulkErrorRecord): number {
    const state = this.getRecordState(record);
    switch (state) {
      case 'pending': return 0;
      case 'auto-corrected': return 1;
      case 'corrected': return 2;
      case 'deleted': return 3;
      default: return 99;
    }
  }

  private commitFieldSelectionChange(fieldName: string): void {
    this.selectedErrorField.set(fieldName);
    this.selectedRecordIds.set(new Set());
    this.currentPage.set(1);
    this.correctionValue.set('');
    this.correctionValueError.set(null);
  }

  promptFieldSelectionChange(fieldName: string): void {
    if (this.selectedRecordIds().size > 0) {
      this.pendingFieldNameChange.set(fieldName);
      this.isConfirmFieldChangeOpen.set(true);
    } else {
      this.commitFieldSelectionChange(fieldName);
    }
  }

  confirmFieldSelectionChange(): void {
    const fieldName = this.pendingFieldNameChange();
    if (fieldName) {
      this.commitFieldSelectionChange(fieldName);
    }
    this.cancelFieldSelectionChange();
  }

  cancelFieldSelectionChange(): void {
    this.isConfirmFieldChangeOpen.set(false);
    this.pendingFieldNameChange.set(null);
  }

  private commitFilterChange(filter: 'pending' | 'auto-corrected', value: boolean): void {
    if (value) { // Turning a filter ON
        if (filter === 'pending') {
            this.showPending.set(true);
            this.showAutoCorrected.set(false);
        } else { // filter === 'auto-corrected'
            this.showAutoCorrected.set(true);
            this.showPending.set(false);
        }
    } else { // Turning a filter OFF
        if (filter === 'pending') {
            this.showPending.set(false);
        } else { // filter === 'auto-corrected'
            this.showAutoCorrected.set(false);
        }
    }
    this.currentPage.set(1);
  }

  promptFilterChange(filter: 'pending' | 'auto-corrected', value: boolean): void {
      if (this.selectedRecordIds().size > 0) {
          this.pendingFilterChange.set({ filter, value });
          this.isConfirmFilterChangeOpen.set(true);
      } else {
          this.commitFilterChange(filter, value);
      }
  }

  confirmFilterChange(): void {
      const change = this.pendingFilterChange();
      if (change) {
          this.selectedRecordIds.set(new Set());
          this.commitFilterChange(change.filter, change.value);
      }
      this.cancelFilterChange();
  }

  cancelFilterChange(): void {
      this.isConfirmFilterChangeOpen.set(false);
      this.pendingFilterChange.set(null);
  }
  
  toggleRecordSelection(recordId: string): void {
    const record = this.errorRecords().find(r => r.id === recordId);
    if (!record) return;

    const state = this.getRecordState(record);
    if (state === 'deleted') return;
    
    this.selectedRecordIds.update(currentSet => {
      const newSet = new Set(currentSet);
      newSet.has(recordId) ? newSet.delete(recordId) : newSet.add(recordId);
      return newSet;
    });
  }

  toggleSelectAllVisible(): void {
    const visibleSelectableIds = this.sortedAndPaginatedRecords()
      .filter(r => {
        const state = this.getRecordState(r);
        return state === 'pending' || state === 'auto-corrected' || state === 'corrected';
      })
      .map(r => r.id);
      
    const allSelected = this.isAllVisibleSelected();
    
    this.selectedRecordIds.update(currentSet => {
      const newSet = new Set(currentSet);
      if (allSelected) {
        visibleSelectableIds.forEach(id => newSet.delete(id));
      } else {
        visibleSelectableIds.forEach(id => newSet.add(id));
      }
      return newSet;
    });
  }
  
  promptDelete(record: BulkErrorRecord): void {
    this.recordToDelete.set(record);
    this.isDeleteConfirmOpen.set(true);
  }

  confirmDelete(): void {
    const recordId = this.recordToDelete()?.id;
    if (recordId) {
      this.errorRecords.update(records => records.map(r => r.id === recordId ? { ...r, rowDeleted: true } : r));
      this.selectedRecordIds.update(currentSet => {
        const newSet = new Set(currentSet);
        newSet.delete(recordId);
        return newSet;
      });
    }
    this.cancelDelete();
  }

  cancelDelete(): void {
    this.isDeleteConfirmOpen.set(false);
    this.recordToDelete.set(null);
  }

  undoDelete(recordId: string): void {
    this.errorRecords.update(records => records.map(r => r.id === recordId ? { ...r, rowDeleted: false } : r));
  }

  goToPage(page: number): void {
    if (page >= 1 && page <= this.totalPages()) {
      if (this.selectedRecordIds().size > 0) {
        this.selectedRecordIds.set(new Set());
      }
      this.currentPage.set(page);
    }
  }

  private onPageSizeChange(newPageSize: number): void {
    this.pageSize.set(newPageSize);
    this.currentPage.set(1);
  }

  promptPageSizeChange(newPageSize: number): void {
    if (this.selectedRecordIds().size > 0) {
      this.pendingPageSizeChange.set(newPageSize);
      this.isConfirmPageSizeChangeOpen.set(true);
    } else {
      this.onPageSizeChange(newPageSize);
    }
  }

  confirmPageSizeChange(): void {
    const newSize = this.pendingPageSizeChange();
    if (newSize !== null) {
      this.selectedRecordIds.set(new Set());
      this.onPageSizeChange(newSize);
    }
    this.cancelPageSizeChange();
  }

  cancelPageSizeChange(): void {
    this.isConfirmPageSizeChangeOpen.set(false);
    this.pendingPageSizeChange.set(null);
  }

  onCorrectionValueChange(value: string): void {
    this.correctionValue.set(value);
    this.correctionValueError.set(this.validateCorrectionValue(value));
  }

  private validateCorrectionValue(value: string): string | null {
    const rules = this.selectedFieldValidationRules();
    if (!rules) return null;

    if (rules.isMandate && !value.trim()) {
      return 'This field is mandatory.';
    }
    if (value.length > rules.maxLength) {
      return `Value cannot exceed ${rules.maxLength} characters.`;
    }
    if (rules.uiValidationPattern && value) {
        try {
            const regex = new RegExp(rules.uiValidationPattern);
            if (!regex.test(value)) {
                return 'Value does not match the required pattern.';
            }
        } catch (e) {
            console.error("Invalid regex pattern provided:", rules.uiValidationPattern);
            return "Invalid validation pattern configured.";
        }
    }
    if (rules.dataType.toLowerCase() === 'date' && value && !/^\d{4}-\d{2}-\d{2}$/.test(value)) {
      return 'Please use YYYY-MM-DD format for dates.';
    }

    return null;
  }
  
  applyBulkChanges(): void {
    const newValue = this.correctionValue();
    const idsToUpdate = this.selectedRecordIds();
    
    if (idsToUpdate.size === 0 || this.correctionValueError() || this.isApplyingChanges()) return;
    
    this.isApplyingChanges.set(true);

    // Simulate network delay
    setTimeout(() => {
      this.errorRecords.update(currentRecords => 
        currentRecords.map(record => {
          if (idsToUpdate.has(record.id)) {
            return {
              ...record,
              fixed: true,
              autoCorrected: false, // Manual correction overrides auto
              rowDeleted: false, // Applying a fix should un-delete it if it was marked
              errorColumn: {
                ...record.errorColumn,
                columnValue: newValue,
                hasError: false,
                isError: false,
                errorMessage: ''
              }
            };
          }
          return record;
        })
      );

      this.selectedRecordIds.set(new Set());
      this.correctionValue.set('');
      this.isApplyingChanges.set(false);
    }, 750);
  }
  
  private generateMockErrorRecords(file: EtlFile): BulkErrorRecord[] {
    const records: BulkErrorRecord[] = [];
    const firstNames = ['John', 'Jane', 'Peter', 'Mary', 'David', 'Susan', 'Prabhu', 'Sandhya'];
    const lastNames = ['Doe', 'Smith', 'Jones', 'Williams', 'Brown', 'Davis', 'Kumar', 'Patel'];

    for (let i = 1; i <= 250; i++) {
        const personId = `0975${5500 + i}`;
        const contractorId = `BACGWK${568000 + i}_PR`;
        const resourceName = `${firstNames[i % firstNames.length]} ${lastNames[i % lastNames.length]}`;

        // Create an email error record
        records.push({
            id: `${file.etlTransId}-r${i}-email`,
            rowNum: i, transId: file.etlTransId, uploadType: file.uploadType,
            contractorId,
            resourceName,
            resourceId: contractorId,
            personId,
            autoCorrected: i % 10 === 0, fixed: false, rowDeleted: i % 20 === 0,
            errorField: 'Email',
            errorColumn: {
                columnName: 'Email', columnValue: 'invalid-email@', isError: true, isMandate: true,
                maxLength: 50, dataType: 'String', errorMessage: 'Invalid email format',
                detailedError: 'Email does not match required pattern',
                uiValidationPattern: "^[\\w\\.-]+@([\\w-]+\\.)+[\\w-]{2,4}$",
                dbColumnName: 'EMAIL', hasError: true
            }
        });

        // Create a Cost Center error record
        if (i % 2 === 0) {
            records.push({
                id: `${file.etlTransId}-r${i}-costCenter`,
                rowNum: i, transId: file.etlTransId, uploadType: file.uploadType,
                contractorId,
                resourceName,
                resourceId: contractorId,
                personId,
                autoCorrected: false, fixed: i % 15 === 0, rowDeleted: false,
                errorField: 'Cost Center',
                errorColumn: {
                    columnName: 'Cost Center', columnValue: `US-INVALID-${i}`, isError: true, isMandate: true,
                    maxLength: 6, dataType: 'Alpha Numeric', errorMessage: 'Value does not match pattern',
                    detailedError: 'Expected pattern like US1234',
                    uiValidationPattern: "^[A-Z]{2}[0-9]{4}$",
                    dbColumnName: 'COST_CENTER', hasError: true
                }
            });
        }
        
        // Create a Supplier Logic Error record
        if (i % 3 === 0) {
            records.push({
                id: `${file.etlTransId}-r${i}-supplier`,
                rowNum: i, transId: file.etlTransId, uploadType: file.uploadType,
                contractorId,
                resourceName,
                resourceId: contractorId,
                personId,
                autoCorrected: false, fixed: false, rowDeleted: false,
                errorField: 'Supplier',
                errorColumn: {
                    columnName: 'Supplier', columnValue: 'TCS LTD', isError: true, isMandate: true,
                    maxLength: 80, dataType: 'String', 
                    errorMessage: "Field Logic Error: Vendor name does not match reference table.",
                    detailedError: null, uiValidationPattern: null,
                    dbColumnName: 'SUPPLIER', hasError: true
                }
            });
        }
    }
    return records;
  }
}
