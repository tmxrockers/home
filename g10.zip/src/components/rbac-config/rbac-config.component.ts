import { ChangeDetectionStrategy, Component, inject, signal, effect, OnDestroy, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RbacService, MenuItem, Role, User } from '../../app/services/rbac.service';
import { UserRole } from '../../app.component';
import { Subscription } from 'rxjs';
import { ConfirmationDialogComponent } from '../confirmation-dialog/confirmation-dialog.component';
import { MultiSelectDropdownComponent } from '../multi-select-dropdown/multi-select-dropdown.component';

type PermissionSource = 'none' | 'role' | 'grant' | 'revoke';
interface PermissionState {
  hasPermission: boolean;
  source: PermissionSource;
}
type SortDirection = 'asc' | 'desc';
type UserOverrides = { granted: Set<string>, revoked: Set<string> };

@Component({
  selector: 'app-rbac-config',
  templateUrl: './rbac-config.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, ConfirmationDialogComponent, MultiSelectDropdownComponent],
  host: {
    '(document:click)': 'onDocumentClick()',
  },
})
export class RbacConfigComponent implements OnDestroy {
  rbacService = inject(RbacService);
  private subscriptions = new Subscription();

  // --- COMPONENT STATE ---
  activeTab = signal<'roles' | 'users'>('roles');
  successMessage = signal('');
  private successMessageTimeout: any;
  actionMenuState = signal<{ featureId: string; userId: string } | null>(null);

  // --- DATA SIGNALS ---
  allFeatures = signal<MenuItem[]>([]);
  allRoles = signal<Role[]>([]);
  allUsers = signal<User[]>([]);
  roleOptions = computed(() => this.allRoles().map(r => r.id));

  // --- PENDING CHANGES STATE (ROLES) ---
  private initialRolePermissions = new Map<UserRole, Set<string>>();
  pendingRolePermissions = signal(new Map<UserRole, Set<string>>());

  // --- PENDING CHANGES STATE (USERS) ---
  private initialUserOverrides = new Map<string, UserOverrides>();
  pendingUserOverrides = signal(new Map<string, UserOverrides>());

  // --- UI STATE (ROLES) ---
  featureSearchTerm = signal('');

  // --- UI STATE (USERS) ---
  userSearchTerm = signal('');
  userFeatureSearchTerm = signal('');
  selectedRoleFilters = signal<Set<UserRole>>(new Set());
  currentPage = signal(1);
  pageSize = signal(10); // Page size for user rows
  sortDirection = signal<SortDirection>('asc');

  // --- CONFIRMATION DIALOGS ---
  isConfirmSaveOpen = signal(false);
  isConfirmDiscardOpen = signal(false);

  // --- COMPUTED SIGNALS ---
  isDirty = computed(() => {
    // Check role permissions
    const pendingRoles = this.pendingRolePermissions();
    if (this.initialRolePermissions.size !== pendingRoles.size) return true;
    for (const [roleId, initialPerms] of this.initialRolePermissions.entries()) {
      const pendingPerms = pendingRoles.get(roleId);
      if (!pendingPerms || initialPerms.size !== pendingPerms.size || ![...pendingPerms].every(p => initialPerms.has(p))) {
        return true;
      }
    }

    // Check user overrides
    const pendingUsers = this.pendingUserOverrides();
    const initialUsers = this.initialUserOverrides;
    if (initialUsers.size !== pendingUsers.size) return true;
    for (const [userId, initialO] of initialUsers.entries()) {
        const pendingO = pendingUsers.get(userId);
        if (!pendingO || 
            initialO.granted.size !== pendingO.granted.size || 
            initialO.revoked.size !== pendingO.revoked.size ||
            ![...pendingO.granted].every(p => initialO.granted.has(p)) ||
            ![...pendingO.revoked].every(p => initialO.revoked.has(p))) {
            return true;
        }
    }
    return false;
  });

  filteredFeatures = computed(() => {
    const term = this.featureSearchTerm().toLowerCase().trim();
    if (!term) return this.allFeatures();
    return this.allFeatures().filter(f => f.label.toLowerCase().includes(term) || f.description?.toLowerCase().includes(term));
  });

  filteredAndSortedUsers = computed(() => {
    const term = this.userSearchTerm().toLowerCase();
    const roleFilters = this.selectedRoleFilters();
    let users = this.allUsers();
    if (roleFilters.size > 0) users = users.filter(u => roleFilters.has(u.role));
    if (term) users = users.filter(u => u.name.toLowerCase().includes(term) || u.email.toLowerCase().includes(term));
    return [...users].sort((a, b) => {
      const comparison = a.name.localeCompare(b.name);
      return this.sortDirection() === 'asc' ? comparison : -comparison;
    });
  });

  totalUsers = computed(() => this.filteredAndSortedUsers().length);
  totalPages = computed(() => Math.ceil(this.totalUsers() / this.pageSize()));
  
  paginatedUsers = computed(() => {
    const users = this.filteredAndSortedUsers();
    const startIndex = (this.currentPage() - 1) * this.pageSize();
    return users.slice(startIndex, startIndex + this.pageSize());
  });
  
  paginationPages = computed(() => Array.from({ length: this.totalPages() }, (_, i) => i));

  paginationEndIndex = computed(() => Math.min(this.currentPage() * this.pageSize(), this.totalUsers()));
  
  userFilteredFeatures = computed(() => {
    const term = this.userFeatureSearchTerm().toLowerCase().trim();
    if (!term) return this.allFeatures();
    return this.allFeatures().filter(f => f.label.toLowerCase().includes(term));
  });

  private rolePermissionsMap = computed(() => this.pendingRolePermissions());

  constructor() {
    this.allFeatures.set(this.rbacService.getActiveFeatures());
    this.allRoles.set(this.rbacService.getRoles());
    this.allUsers.set(this.rbacService.getUsers());
    this.initializePermissionsState();

    effect(() => this.rbacService.permissionsDirty.set(this.isDirty()));
    this.subscriptions.add(this.rbacService.discardPermissionsChanges$.subscribe(() => this.discardChanges(true)));
  }
  
  onDocumentClick(): void {
    if (this.actionMenuState()) {
      this.closeActionMenu();
    }
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
    clearTimeout(this.successMessageTimeout);
  }

  private initializePermissionsState(): void {
    // Roles
    const initialRoleMap = new Map<UserRole, Set<string>>();
    for (const role of this.allRoles()) {
        initialRoleMap.set(role.id, new Set<string>(this.rbacService.getRolePermissions(role.id)));
    }
    this.initialRolePermissions = initialRoleMap;
    const pendingRoleMap = new Map<UserRole, Set<string>>();
    for (const [roleId, perms] of initialRoleMap.entries()) {
        pendingRoleMap.set(roleId, new Set(perms));
    }
    this.pendingRolePermissions.set(pendingRoleMap);

    // Users
    const initialUserMap = new Map<string, UserOverrides>();
    const allOverrides = this.rbacService.getAllUserPermissionOverrides();
    for(const userId in allOverrides) {
        initialUserMap.set(userId, {
            granted: new Set(allOverrides[userId].granted),
            revoked: new Set(allOverrides[userId].revoked)
        });
    }
    this.initialUserOverrides = initialUserMap;
    const pendingUserMap = new Map<string, UserOverrides>();
    for (const [userId, overrides] of initialUserMap.entries()) {
        pendingUserMap.set(userId, {
            granted: new Set(overrides.granted),
            revoked: new Set(overrides.revoked),
        });
    }
    this.pendingUserOverrides.set(pendingUserMap);
  }

  // --- Permission Toggling (Roles) ---
  toggleRolePermission(featureId: string, roleId: UserRole): void {
    this.pendingRolePermissions.update(currentMap => {
        const permsForRole = currentMap.get(roleId) || new Set();
        if (permsForRole.has(featureId)) permsForRole.delete(featureId);
        else permsForRole.add(featureId);
        return new Map(currentMap.set(roleId, permsForRole));
    });
  }

  // --- Permission Toggling (Users) ---
  getPermissionState(featureId: string, user: User): PermissionState {
    if (!user) return { hasPermission: false, source: 'none' };
    const overrides = this.pendingUserOverrides().get(user.id);
    if (overrides?.granted.has(featureId)) return { hasPermission: true, source: 'grant' };
    if (overrides?.revoked.has(featureId)) return { hasPermission: false, source: 'revoke' };
    
    const rolePermissions = this.rolePermissionsMap().get(user.role);
    if (rolePermissions?.has(featureId)) return { hasPermission: true, source: 'role' };

    return { hasPermission: false, source: 'none' };
  }
  
  private updatePendingOverrides(userId: string, updateFn: (overrides: UserOverrides) => UserOverrides): void {
    this.pendingUserOverrides.update(currentMap => {
        const userOverrides = currentMap.get(userId) || { granted: new Set(), revoked: new Set() };
        const newOverrides = updateFn({ granted: new Set(userOverrides.granted), revoked: new Set(userOverrides.revoked) });
        if (newOverrides.granted.size === 0 && newOverrides.revoked.size === 0) {
            currentMap.delete(userId);
        } else {
            currentMap.set(userId, newOverrides);
        }
        return new Map(currentMap);
    });
  }

  grantPermission(featureId: string, user: User): void {
    if (!user) return;
    const rolePermissions = this.rolePermissionsMap().get(user.role);
    this.updatePendingOverrides(user.id, ({ granted, revoked }) => {
      revoked.delete(featureId);
      if (!rolePermissions?.has(featureId)) granted.add(featureId);
      return { granted, revoked };
    });
    this.closeActionMenu();
  }

  revokePermission(featureId: string, user: User): void {
    if (!user) return;
    const rolePermissions = this.rolePermissionsMap().get(user.role);
    this.updatePendingOverrides(user.id, ({ granted, revoked }) => {
      granted.delete(featureId);
      if (rolePermissions?.has(featureId)) revoked.add(featureId);
      return { granted, revoked };
    });
    this.closeActionMenu();
  }

  resetPermission(featureId: string, user: User): void {
    if (!user) return;
     this.updatePendingOverrides(user.id, ({ granted, revoked }) => {
      granted.delete(featureId);
      revoked.delete(featureId);
      return { granted, revoked };
    });
    this.closeActionMenu();
  }

  // --- Save/Discard Logic ---
  saveChanges(): void {
    if (!this.isDirty()) return;
    this.isConfirmSaveOpen.set(true);
  }

  onConfirmSave(): void {
    // Save Roles
    for (const [roleId, perms] of this.pendingRolePermissions().entries()) {
        this.rbacService.setPermissionsForRole(roleId, Array.from(perms));
    }
    // Save Users
    const allUserOverrides = this.rbacService.getAllUserPermissionOverrides();
    const pendingUserIds = new Set(this.pendingUserOverrides().keys());
    // Clear overrides for users who are no longer in the pending map
    for (const userId in allUserOverrides) {
        if (!pendingUserIds.has(userId)) {
            this.rbacService.setUserPermissionOverrides(userId, { granted: [], revoked: [] });
        }
    }
    // Set new and updated overrides
    for (const [userId, overrides] of this.pendingUserOverrides().entries()) {
        this.rbacService.setUserPermissionOverrides(userId, {
            granted: Array.from(overrides.granted),
            revoked: Array.from(overrides.revoked)
        });
    }

    this.initializePermissionsState();
    this.isConfirmSaveOpen.set(false);
    this.showSuccessMessage('Permission changes saved successfully.');
  }
  
  discardChanges(isFromParent = false): void {
    if (!this.isDirty()) return;
    if (isFromParent) this.onConfirmDiscard();
    else this.isConfirmDiscardOpen.set(true);
  }
  
  onConfirmDiscard(): void {
    this.initializePermissionsState(); // Resets both role and user pending changes
    this.isConfirmDiscardOpen.set(false);
    this.showSuccessMessage('Unsaved changes have been discarded.');
  }

  // --- UI Helpers ---
  private showSuccessMessage(message: string): void {
    this.successMessage.set(message);
    clearTimeout(this.successMessageTimeout);
    this.successMessageTimeout = setTimeout(() => this.successMessage.set(''), 3000);
  }
  toggleSortDirection(): void { this.sortDirection.update(d => d === 'asc' ? 'desc' : 'asc'); }
  onUserSearch(term: string): void { this.userSearchTerm.set(term); this.currentPage.set(1); }
  onRoleFilterChange(roles: Set<UserRole>): void { this.selectedRoleFilters.set(roles); this.currentPage.set(1); }
  goToPage(page: number): void { if (page >= 1 && page <= this.totalPages()) this.currentPage.set(page); }
  getFormattedRole(role: UserRole): string {
    const roleName = role.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
    return roleName.replace('dataLoader', 'Data Loader').replace('staffingOps', 'Staffing Ops').replace('hrPartner', 'HR Partner').replace('financeAnalyst', 'Finance Analyst').replace('itSupport', 'IT Support');
  }

  toggleActionMenu(event: MouseEvent, featureId: string, userId: string): void {
    event.stopPropagation();
    const current = this.actionMenuState();
    if (current?.featureId === featureId && current?.userId === userId) {
      this.actionMenuState.set(null);
    } else {
      this.actionMenuState.set({ featureId, userId });
    }
  }

  closeActionMenu(): void {
    this.actionMenuState.set(null);
  }
}