import { ChangeDetectionStrategy, Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { HeaderComponent } from './components/header/header.component';
import { AdminHubComponent } from './components/admin-hub/admin-hub.component';
import { FooterComponent } from './components/footer/footer.component';
import { User, UserRole } from './components/confirmation-dialog/app/services/rbac.service';
import { RolesConfigComponent } from './components/roles-config/roles-config.component';
import { ReportingDashboardComponent } from './components/reporting-dashboard/reporting-dashboard.component';
import { EtlGovernanceComponent } from './components/etl-governance/etl-governance.component';
import { BulkEditComponent } from './components/bulk-edit/bulk-edit.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, SidebarComponent, HeaderComponent, AdminHubComponent, FooterComponent, RolesConfigComponent, ReportingDashboardComponent, EtlGovernanceComponent, BulkEditComponent],
})
export class AppComponent {
  isSidebarOpen = signal(false);
  selectedPage = signal<string>('etl');
  
  currentUser = signal<User>({ id: 'u2', name: 'Data Loader User', email: 'dataloader@test.com', role: 'dataLoader' });

  toggleSidebar(): void {
    this.isSidebarOpen.update(v => !v);
  }

  onMenuItemSelected(pageId: string): void {
    this.selectedPage.set(pageId);
  }
}
