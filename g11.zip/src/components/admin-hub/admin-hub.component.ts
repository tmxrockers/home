import { ChangeDetectionStrategy, Component, computed, inject, input, signal, OnDestroy, effect, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConfirmationDialogComponent } from '../confirmation-dialog/confirmation-dialog.component';
import { MultiSelectDropdownComponent } from '../multi-select-dropdown/multi-select-dropdown.component';
import { User, RbacService, MenuItem, Role, UserRole } from '../confirmation-dialog/app/services/rbac.service';
import { Subscription } from 'rxjs';

// --- Types from former child components ---
type PermissionSource = 'none' | 'role' | 'grant' | 'revoke';
interface PermissionState {
  hasPermission: boolean;
  source: PermissionSource;
}
type SortDirection = 'asc' | 'desc';
type UserOverrides = { granted: Set<string>, revoked: Set<string> };
interface AppRoute { path: string; name: string; }
interface AppIcon { name: string; id: string; }
const MAX_LABEL_LENGTH = 50;


@Component({
  selector: 'app-admin-hub',
  templateUrl: './admin-hub.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, ConfirmationDialogComponent, MultiSelectDropdownComponent],
  host: {
    '(document:click)': 'onDocumentClick($event)',
  }
})
export class AdminHubComponent implements OnDestroy {
  // --- Injected Services & Dependencies ---
  private rbacService = inject(RbacService);
  private elementRef = inject(ElementRef);
  private subscriptions = new Subscription();
  
  // --- Component Inputs & Core State ---
  currentUser = input.required<User>();
  activeTab = signal<'roles' | 'users' | 'menu'>('roles');
  successMessage = signal('');
  private successMessageTimeout: any;

  // --- Combined State from RBAC Config ---
  actionMenuState = signal<{ featureId: string; userId: string } | null>(null);
  allRoles = signal<Role[]>([]);
  allUsers = signal<User[]>([]);
  roleOptions = computed(() => this.allRoles().map(r => r.id));
  private initialRolePermissions = new Map<UserRole, Set<string>>();
  pendingRolePermissions = signal(new Map<UserRole, Set<string>>());
  private initialUserOverrides = new Map<string, UserOverrides>();
  pendingUserOverrides = signal(new Map<string, UserOverrides>());
  featureSearchTerm = signal('');
  userSearchTerm = signal('');
  userFeatureSearchTerm = signal('');
  selectedRoleFilters = signal<Set<UserRole>>(new Set());
  currentPage = signal(1);
  pageSize = signal(10);
  sortDirection = signal<SortDirection>('asc');
  isConfirmSavePermissionsOpen = signal(false);
  isConfirmDiscardPermissionsOpen = signal(false);

  // --- Combined State from Feature Config ---
  allFeatures = signal<MenuItem[]>([]);
  featuresSearchTerm = signal<string>('');
  private initialFeatures: MenuItem[] = [];
  isConfirmSaveFeaturesOpen = signal(false);
  isConfirmDiscardFeaturesOpen = signal(false);
  isConfirmDeleteFeatureOpen = signal(false);
  itemToDelete = signal<{ id: string } | null>(null);
  draggedItemId = signal<string | null>(null);
  dragOverId = signal<string | null>(null);
  dropPosition = signal<'before' | 'after' | null>(null);
  editingDescriptionId = signal<string | null>(null);
  editingDescriptionValue = signal<string>('');
  editingLabelId = signal<string | null>(null);
  editingLabelValue = signal<string>('');
  editingLabelError = signal<string | null>(null);
  isMenuModalOpen = signal(false);
  menuItemLabel = signal('');
  menuItemDescription = signal('');
  menuItemRoute = signal<string>('');
  menuItemIcon = signal<string>('');
  menuItemValidationError = signal<string | null>(null);
  menuItemRouteError = signal<string | null>(null);
  maxLabelLength = MAX_LABEL_LENGTH;
  isIconPickerOpen = signal(false);
  iconSearchTerm = signal('');

  availableRoutes: AppRoute[] = [
    { path: '/dashboard', name: 'Dashboard' }, { path: '/user-access', name: 'User Access Management' },
    { path: '/service-desk', name: 'Service Desk' }, { path: '/reports', name: 'Reports' },
    { path: '/file-upload', name: 'File Upload' }, { path: '/config/staffing', name: 'Staffing Ops Config' },
  ];
  availableIcons: AppIcon[] = [
    { name: 'Dashboard', id: 'dashboard' }, { name: 'Users', id: 'group' },
    { name: 'Support', id: 'support_agent' }, { name: 'Settings', id: 'settings' },
    { name: 'Reports', id: 'assessment' }, { name: 'Analytics', id: 'analytics' },
    { name: 'Building', id: 'business' }, { name: 'Briefcase', id: 'work' },
    { name: 'Upload', id: 'upload_file' }, { name: 'Download', id: 'download' },
    { name: 'History', id: 'history' }, { name: 'Security', id: 'security' },
    { name: 'Star', id: 'star' }, { name: 'Globe', id: 'public' }, { name: 'Tasks', id: 'task_alt' },
    { name: 'Megaphone', id: 'campaign' }, { name: 'View Grid', id: 'grid_view' },
  ];

  // --- COMPUTED SIGNALS ---
  
  // Dirty checking for both configurations
  isPermissionsDirty = computed(() => {
    const pendingRoles = this.pendingRolePermissions();
    if (this.initialRolePermissions.size !== pendingRoles.size) return true;
    for (const [roleId, initialPerms] of this.initialRolePermissions.entries()) {
      const pendingPerms = pendingRoles.get(roleId);
      if (!pendingPerms || initialPerms.size !== pendingPerms.size || ![...pendingPerms].every(p => initialPerms.has(p))) return true;
    }
    const pendingUsers = this.pendingUserOverrides();
    const initialUsers = this.initialUserOverrides;
    if (initialUsers.size !== pendingUsers.size) return true;
    for (const [userId, initialO] of initialUsers.entries()) {
        const pendingO = pendingUsers.get(userId);
        if (!pendingO || initialO.granted.size !== pendingO.granted.size || initialO.revoked.size !== pendingO.revoked.size || ![...pendingO.granted].every(p => initialO.granted.has(p)) || ![...pendingO.revoked].every(p => initialO.revoked.has(p))) return true;
    }
    return false;
  });

  isFeaturesDirty = computed(() => JSON.stringify(this.initialFeatures) !== JSON.stringify(this.allFeatures()));
  
  isConfigDirty = computed(() => {
    const active = this.activeTab();
    if (active === 'roles' || active === 'users') {
      return this.isPermissionsDirty();
    }
    if (active === 'menu') {
      return this.isFeaturesDirty();
    }
    return false;
  });

  // Filtered data for RBAC tables
  filteredRbacFeatures = computed(() => {
    const term = this.featureSearchTerm().toLowerCase().trim();
    if (!term) return this.allFeatures();
    return this.allFeatures().filter(f => f.label.toLowerCase().includes(term) || (f.description || '').toLowerCase().includes(term));
  });

  filteredAndSortedUsers = computed(() => {
    const term = this.userSearchTerm().toLowerCase();
    const roleFilters = this.selectedRoleFilters();
    let users = this.allUsers();
    if (roleFilters.size > 0) users = users.filter(u => roleFilters.has(u.role));
    if (term) users = users.filter(u => u.name.toLowerCase().includes(term) || u.email.toLowerCase().includes(term));
    return [...users].sort((a, b) => {
      const comparison = a.name.localeCompare(b.name);
      return this.sortDirection() === 'asc' ? comparison : -comparison;
    });
  });
  
  totalUsers = computed(() => this.filteredAndSortedUsers().length);
  totalPages = computed(() => Math.ceil(this.totalUsers() / this.pageSize()));
  paginatedUsers = computed(() => {
    const users = this.filteredAndSortedUsers();
    const startIndex = (this.currentPage() - 1) * this.pageSize();
    return users.slice(startIndex, startIndex + this.pageSize());
  });
  paginationPages = computed(() => Array.from({ length: this.totalPages() }, (_, i) => i));
  paginationEndIndex = computed(() => Math.min(this.currentPage() * this.pageSize(), this.totalUsers()));
  userFilteredFeatures = computed(() => {
    const term = this.userFeatureSearchTerm().toLowerCase().trim();
    if (!term) return this.allFeatures();
    return this.allFeatures().filter(f => f.label.toLowerCase().includes(term));
  });
  private rolePermissionsMap = computed(() => this.pendingRolePermissions());

  // Filtered data for Features table
  filteredMenuFeatures = computed(() => {
    const term = this.featuresSearchTerm().toLowerCase().trim();
    if (!term) return this.allFeatures();
    return this.allFeatures().filter(feature => feature.label.toLowerCase().includes(term) || (feature.description || '').toLowerCase().includes(term));
  });
  filteredIcons = computed(() => {
    const term = this.iconSearchTerm().toLowerCase();
    if (!term) return this.availableIcons;
    return this.availableIcons.filter(icon => icon.name.toLowerCase().includes(term));
  });

  constructor() {
    this.initializeAllState();

    // Effect to notify service of dirty state (optional now, but good practice)
    effect(() => this.rbacService.permissionsDirty.set(this.isPermissionsDirty()));
    effect(() => this.rbacService.featureDirty.set(this.isFeaturesDirty()));
  }

  private initializeAllState(): void {
    // Load data from service
    const rawFeatures = this.rbacService.getRawFeatures();
    this.allRoles.set(this.rbacService.getRoles());
    this.allUsers.set(this.rbacService.getUsers());

    // --- Initialize Permissions State ---
    const initialRoleMap = new Map<UserRole, Set<string>>();
    for (const role of this.allRoles()) {
        initialRoleMap.set(role.id, new Set<string>(this.rbacService.getRolePermissions(role.id)));
    }
    this.initialRolePermissions = initialRoleMap;
    const pendingRoleMap = new Map<UserRole, Set<string>>();
    for (const [roleId, perms] of initialRoleMap.entries()) {
        pendingRoleMap.set(roleId, new Set(perms));
    }
    this.pendingRolePermissions.set(pendingRoleMap);

    const initialUserMap = new Map<string, UserOverrides>();
    const allOverrides = this.rbacService.getAllUserPermissionOverrides();
    for(const userId in allOverrides) {
        initialUserMap.set(userId, { granted: new Set(allOverrides[userId].granted), revoked: new Set(allOverrides[userId].revoked) });
    }
    this.initialUserOverrides = initialUserMap;
    const pendingUserMap = new Map<string, UserOverrides>();
    for (const [userId, overrides] of initialUserMap.entries()) {
        pendingUserMap.set(userId, { granted: new Set(overrides.granted), revoked: new Set(overrides.revoked) });
    }
    this.pendingUserOverrides.set(pendingUserMap);

    // --- Initialize Features State ---
    this.initialFeatures = JSON.parse(JSON.stringify(rawFeatures));
    this.allFeatures.set(JSON.parse(JSON.stringify(rawFeatures)));
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
    clearTimeout(this.successMessageTimeout);
  }

  onDocumentClick(event: MouseEvent): void {
    if (this.actionMenuState()) this.closeActionMenu();
    if (this.isIconPickerOpen() && !this.elementRef.nativeElement.querySelector('.icon-picker-container')?.contains(event.target)) {
        this.isIconPickerOpen.set(false);
    }
  }
  
  // --- Central Save/Discard Logic ---
  saveChanges(): void {
    const active = this.activeTab();
    if ((active === 'roles' || active === 'users') && this.isPermissionsDirty()) {
      this.isConfirmSavePermissionsOpen.set(true);
    } else if (active === 'menu' && this.isFeaturesDirty()) {
      this.isConfirmSaveFeaturesOpen.set(true);
    }
  }

  discardChanges(): void {
    const active = this.activeTab();
    if ((active === 'roles' || active === 'users') && this.isPermissionsDirty()) {
      this.isConfirmDiscardPermissionsOpen.set(true);
    } else if (active === 'menu' && this.isFeaturesDirty()) {
      this.isConfirmDiscardFeaturesOpen.set(true);
    }
  }

  // --- RBAC Permissions Methods ---
  onConfirmSavePermissions(): void {
    for (const [roleId, perms] of this.pendingRolePermissions().entries()) {
        this.rbacService.setPermissionsForRole(roleId, Array.from(perms));
    }
    const allUserOverrides = this.rbacService.getAllUserPermissionOverrides();
    const pendingUserIds = new Set(this.pendingUserOverrides().keys());
    for (const userId in allUserOverrides) {
        if (!pendingUserIds.has(userId)) this.rbacService.setUserPermissionOverrides(userId, { granted: [], revoked: [] });
    }
    for (const [userId, overrides] of this.pendingUserOverrides().entries()) {
        this.rbacService.setUserPermissionOverrides(userId, { granted: Array.from(overrides.granted), revoked: Array.from(overrides.revoked) });
    }
    this.initializeAllState();
    this.isConfirmSavePermissionsOpen.set(false);
    this.showSuccessMessage('Permission changes saved successfully.');
  }

  onConfirmDiscardPermissions(): void {
    this.initializeAllState();
    this.isConfirmDiscardPermissionsOpen.set(false);
    this.showSuccessMessage('Unsaved permission changes have been discarded.');
  }
  
  toggleRolePermission(featureId: string, roleId: UserRole): void {
    this.pendingRolePermissions.update(currentMap => {
        const permsForRole = currentMap.get(roleId) || new Set();
        if (permsForRole.has(featureId)) permsForRole.delete(featureId);
        else permsForRole.add(featureId);
        return new Map(currentMap.set(roleId, permsForRole));
    });
  }
  
  getPermissionState(featureId: string, user: User): PermissionState {
    if (!user) return { hasPermission: false, source: 'none' };
    const overrides = this.pendingUserOverrides().get(user.id);
    if (overrides?.granted.has(featureId)) return { hasPermission: true, source: 'grant' };
    if (overrides?.revoked.has(featureId)) return { hasPermission: false, source: 'revoke' };
    const rolePermissions = this.rolePermissionsMap().get(user.role);
    if (rolePermissions?.has(featureId)) return { hasPermission: true, source: 'role' };
    return { hasPermission: false, source: 'none' };
  }
  
  private updatePendingOverrides(userId: string, updateFn: (overrides: UserOverrides) => UserOverrides): void {
    this.pendingUserOverrides.update(currentMap => {
        const userOverrides = currentMap.get(userId) || { granted: new Set(), revoked: new Set() };
        const newOverrides = updateFn({ granted: new Set(userOverrides.granted), revoked: new Set(userOverrides.revoked) });
        if (newOverrides.granted.size === 0 && newOverrides.revoked.size === 0) {
            currentMap.delete(userId);
        } else {
            currentMap.set(userId, newOverrides);
        }
        return new Map(currentMap);
    });
  }

  grantPermission(featureId: string, user: User): void {
    if (!user) return;
    const rolePermissions = this.rolePermissionsMap().get(user.role);
    this.updatePendingOverrides(user.id, ({ granted, revoked }) => {
      revoked.delete(featureId);
      if (!rolePermissions?.has(featureId)) granted.add(featureId);
      return { granted, revoked };
    });
    this.closeActionMenu();
  }

  revokePermission(featureId: string, user: User): void {
    if (!user) return;
    const rolePermissions = this.rolePermissionsMap().get(user.role);
    this.updatePendingOverrides(user.id, ({ granted, revoked }) => {
      granted.delete(featureId);
      if (rolePermissions?.has(featureId)) revoked.add(featureId);
      return { granted, revoked };
    });
    this.closeActionMenu();
  }

  resetPermission(featureId: string, user: User): void {
    if (!user) return;
     this.updatePendingOverrides(user.id, ({ granted, revoked }) => {
      granted.delete(featureId);
      revoked.delete(featureId);
      return { granted, revoked };
    });
    this.closeActionMenu();
  }
  
  // --- Feature Config Methods ---
  onConfirmSaveFeatures(): void {
    this.rbacService.updateFeatures(this.allFeatures());
    this.initializeAllState();
    this.isConfirmSaveFeaturesOpen.set(false);
    this.showSuccessMessage('Menu structure changes saved successfully.');
  }

  onConfirmDiscardFeatures(): void {
    this.initializeAllState();
    this.cancelDescriptionEdit();
    this.cancelLabelEdit();
    this.isConfirmDiscardFeaturesOpen.set(false);
    this.showSuccessMessage('Unsaved changes to the menu structure have been discarded.');
  }

  onStatusChange(featureId: string, event: Event): void {
    const isActive = (event.target as HTMLInputElement).checked;
    this.allFeatures.update(features => features.map(item => item.id === featureId ? { ...item, isActive } : item));
  }
  
  startEditingLabel(item: MenuItem): void {
    if (this.editingDescriptionId() !== null) return;
    this.editingLabelId.set(item.id);
    this.editingLabelValue.set(item.label);
    this.editingLabelError.set(null);
  }

  saveLabelEdit(): void {
    const idToUpdate = this.editingLabelId();
    if (!idToUpdate) return;
    const validationError = this.validateLabel(this.editingLabelValue(), idToUpdate);
    if (validationError) {
      this.editingLabelError.set(validationError);
      return;
    }
    const newLabel = this.editingLabelValue().trim();
    if (!newLabel) return;
    this.allFeatures.update(currentFeatures => currentFeatures.map(item => item.id === idToUpdate ? { ...item, label: newLabel } : item));
    this.cancelLabelEdit();
  }

  cancelLabelEdit(): void {
    this.editingLabelId.set(null);
    this.editingLabelValue.set('');
    this.editingLabelError.set(null);
  }

  startEditingDescription(feature: MenuItem): void {
    if (this.editingLabelId() !== null) return;
    this.editingDescriptionId.set(feature.id);
    this.editingDescriptionValue.set(feature.description || '');
  }

  saveDescriptionEdit(): void {
    const idToUpdate = this.editingDescriptionId();
    if (!idToUpdate) return;
    const newDescription = this.editingDescriptionValue();
    this.allFeatures.update(currentFeatures => currentFeatures.map(item => item.id === idToUpdate ? { ...item, description: newDescription } : item));
    this.cancelDescriptionEdit();
  }

  cancelDescriptionEdit(): void {
    this.editingDescriptionId.set(null);
    this.editingDescriptionValue.set('');
  }

  onDragStart(event: DragEvent, featureId: string): void {
    event.dataTransfer?.setData('text/plain', featureId);
    event.dataTransfer!.effectAllowed = 'move';
    this.draggedItemId.set(featureId);
  }

  onDragOver(event: DragEvent, featureId: string): void {
    event.preventDefault();
    const draggedItemId = this.draggedItemId();
    if (draggedItemId && draggedItemId !== featureId) {
        const rect = (event.currentTarget as HTMLElement).getBoundingClientRect();
        const isAfter = event.clientY > rect.top + rect.height / 2;
        this.dropPosition.set(isAfter ? 'after' : 'before');
        this.dragOverId.set(featureId);
    }
  }

  onDragLeave(event: DragEvent): void {
    event.preventDefault();
    this.dragOverId.set(null);
    this.dropPosition.set(null);
  }

  onDrop(event: DragEvent, targetFeatureId: string): void {
    event.preventDefault();
    const draggedItemId = this.draggedItemId();
    const dropPos = this.dropPosition();
    this.dragOverId.set(null);
    this.dropPosition.set(null);
    this.draggedItemId.set(null);
    if (!draggedItemId || draggedItemId === targetFeatureId) return;
    this.allFeatures.update(currentFeatures => {
      const newFeatures = JSON.parse(JSON.stringify(currentFeatures));
      const draggedIndex = newFeatures.findIndex((item: MenuItem) => item.id === draggedItemId);
      let targetIndex = newFeatures.findIndex((item: MenuItem) => item.id === targetFeatureId);
      if (draggedIndex === -1 || targetIndex === -1) return currentFeatures;
      const [draggedItem] = newFeatures.splice(draggedIndex, 1);
      targetIndex = newFeatures.findIndex((item: MenuItem) => item.id === targetFeatureId);
      if (dropPos === 'after') targetIndex++;
      newFeatures.splice(targetIndex, 0, draggedItem);
      return newFeatures;
    });
  }

  openNewMenuModal(): void {
    this.menuItemLabel.set('');
    this.menuItemDescription.set('');
    this.menuItemRoute.set('');
    this.menuItemIcon.set('');
    this.menuItemValidationError.set(null);
    this.menuItemRouteError.set(null);
    this.isMenuModalOpen.set(true);
  }

  closeMenuModal(): void {
    this.isMenuModalOpen.set(false);
    this.isIconPickerOpen.set(false);
    this.iconSearchTerm.set('');
  }
  
  saveMenuItem(): void {
    const label = this.menuItemLabel().trim();
    if (!label || this.menuItemValidationError() || this.menuItemRouteError()) return;
    const newItem: MenuItem = {
      id: label.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') + `-${Date.now()}`,
      label: label,
      description: this.menuItemDescription().trim(),
      route: this.menuItemRoute(),
      icon: this.menuItemIcon(),
      isActive: true,
    };
    this.allFeatures.update(features => [...features, newItem]);
    this.closeMenuModal();
  }
  
  promptDeleteMenuItem(id: string): void {
    this.itemToDelete.set({ id });
    this.isConfirmDeleteFeatureOpen.set(true);
  }

  onConfirmDeleteFeature(): void {
    const idToDelete = this.itemToDelete()?.id;
    if (!idToDelete) return;
    this.allFeatures.update(features => features.filter(item => item.id !== idToDelete));
    this.onCancelDeleteFeature();
  }

  onCancelDeleteFeature(): void {
    this.isConfirmDeleteFeatureOpen.set(false);
    this.itemToDelete.set(null);
  }

  // --- UI & Helper Methods ---
  private showSuccessMessage(message: string): void {
    this.successMessage.set(message);
    clearTimeout(this.successMessageTimeout);
    this.successMessageTimeout = setTimeout(() => this.successMessage.set(''), 3000);
  }

  getPermissionStateTooltip(source: PermissionSource, featureLabel: string, user: User): string {
    switch (source) {
      case 'grant': return `Granted: '${user.name}' has explicit permission for '${featureLabel}'.`;
      case 'revoke': return `Revoked: '${user.name}' is explicitly denied permission for '${featureLabel}', overriding their role.`;
      case 'role': return `Inherited: Permission for '${featureLabel}' is granted via the '${this.getFormattedRole(user.role)}' role.`;
      case 'none': return `Disabled: '${user.name}' does not have permission for '${featureLabel}'.`;
      default: return 'Permission status';
    }
  }

  toggleSortDirection(): void { this.sortDirection.update(d => d === 'asc' ? 'desc' : 'asc'); }
  onUserSearch(term: string): void { this.userSearchTerm.set(term); this.currentPage.set(1); }
  onRoleFilterChange(roles: Set<UserRole>): void { this.selectedRoleFilters.set(roles); this.currentPage.set(1); }
  goToPage(page: number): void { if (page >= 1 && page <= this.totalPages()) this.currentPage.set(page); }
  getFormattedRole(role: UserRole): string {
    const roleName = role.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
    return roleName.replace('dataLoader', 'Data Loader').replace('staffingOps', 'Staffing Ops').replace('hrPartner', 'HR Partner').replace('financeAnalyst', 'Finance Analyst').replace('itSupport', 'IT Support');
  }

  toggleActionMenu(event: MouseEvent, featureId: string, userId: string): void {
    event.stopPropagation();
    const current = this.actionMenuState();
    if (current?.featureId === featureId && current?.userId === userId) {
      this.actionMenuState.set(null);
    } else {
      this.actionMenuState.set({ featureId, userId });
    }
  }

  closeActionMenu(): void { this.actionMenuState.set(null); }
  
  private validateLabel(label: string, idToIgnore: string | null): string | null {
    const trimmedLabel = label.trim();
    if (trimmedLabel.length > MAX_LABEL_LENGTH) return `Label cannot exceed ${MAX_LABEL_LENGTH} characters.`;
    const isDuplicate = this.allFeatures().some(item => item.id !== idToIgnore && item.label.trim().toLowerCase() === trimmedLabel.toLowerCase());
    return isDuplicate ? "Another menu item already has this label." : null;
  }

  private validateRoute(route: string): string | null {
    if (!route) return null;
    return this.allFeatures().some(item => item.route === route) ? "This route is already in use." : null;
  }

  onModalLabelChange(value: string) {
    this.menuItemLabel.set(value);
    this.menuItemValidationError.set(this.validateLabel(value, null));
  }

  onModalRouteChange(value: string) {
    this.menuItemRoute.set(value);
    this.menuItemRouteError.set(this.validateRoute(value));
  }

  selectIcon(iconId: string): void {
    this.menuItemIcon.set(iconId);
    this.isIconPickerOpen.set(false);
  }
  
  getSelectedIconName(): string {
    const selectedId = this.menuItemIcon();
    if (!selectedId) return 'Select Icon';
    const icon = this.availableIcons.find(i => i.id === selectedId);
    return icon ? icon.name : 'Select Icon';
  }
}
