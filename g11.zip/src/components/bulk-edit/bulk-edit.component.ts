import { ChangeDetectionStrategy, Component, signal, computed, input, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GovernanceErrorRow, GovernanceErrorColumn } from '../etl-governance/etl-governance.component';

// This is a subset of the EtlFile interface, only what's needed here.
interface EtlFile {
  uploadType: string;
}

interface FieldValidationRules {
    dataType: string;
    maxLength: number;
    uiValidationPattern: string | null;
    mandate: boolean;
}

@Component({
  selector: 'app-bulk-edit',
  imports: [CommonModule],
  templateUrl: './bulk-edit.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class BulkEditComponent {
  // --- Inputs / Outputs ---
  file = input.required<EtlFile>();
  errorRecords = input.required<GovernanceErrorRow[]>();
  back = output<void>();
  recordsUpdated = output<GovernanceErrorRow[]>();

  // --- State Signals ---
  selectedErrorField = signal<string>('');
  correctionValue = signal('');
  correctionValueError = signal<string | null>(null);
  selectedRecordIds = signal<Set<string>>(new Set());
  currentPage = signal(1);
  pageSize = signal(10);

  // --- Computed Signals ---
  errorFieldsForSelection = computed(() => {
    const fields = new Set<string>();
    this.errorRecords().forEach(record => {
      record.errorColumns.forEach(column => {
        const correspondingColumn = record.allColumns.find(c => c.columnName === column.columnName);
        if (column.error && !correspondingColumn?.isCorrected) {
          fields.add(column.columnName);
        }
      });
    });
    return Array.from(fields).sort();
  });

  recordsForSelectedField = computed(() => {
    const field = this.selectedErrorField();
    if (!field) return [];
    return this.errorRecords().filter(record => 
      record.errorColumns.some(c => {
        const correspondingColumn = record.allColumns.find(ac => ac.columnName === c.columnName);
        return c.columnName === field && c.error && !correspondingColumn?.isCorrected;
      })
    );
  });
  
  selectedFieldValidationRules = computed<FieldValidationRules | null>(() => {
    const field = this.selectedErrorField();
    if (!field) return null;
    const firstRecord = this.recordsForSelectedField()[0];
    const errorColumn = firstRecord?.allColumns.find(c => c.columnName === field);
    if (!errorColumn) return null;
    return {
        dataType: errorColumn.dataType,
        maxLength: errorColumn.maxLength,
        uiValidationPattern: errorColumn.uiValidationPattern,
        mandate: errorColumn.mandate
    };
  });

  totalRecordsForPagination = computed(() => this.recordsForSelectedField().length);
  totalPages = computed(() => Math.ceil(this.totalRecordsForPagination() / this.pageSize()));
  paginationPages = computed(() => Array.from({ length: this.totalPages() }, (_, i) => i + 1));

  paginatedRecords = computed(() => {
    const records = this.recordsForSelectedField();
    const startIndex = (this.currentPage() - 1) * this.pageSize();
    return records.slice(startIndex, startIndex + this.pageSize());
  });

  isAllVisibleSelected = computed(() => {
    const visibleIds = this.paginatedRecords().map(r => r.id);
    if(visibleIds.length === 0) return false;
    return visibleIds.every(id => this.selectedRecordIds().has(id));
  });
  
  // --- Methods ---

  getRefColumnValue(record: GovernanceErrorRow, columnName: string): string {
    switch (columnName) {
      case 'Contractor ID': return record.contractorId ?? 'N/A';
      case 'Resource': return record.resource ?? 'N/A';
      default: return 'N/A';
    }
  }

  getErrorInfoForRecord(record: GovernanceErrorRow, fieldName: string): { value: string; errorMessage: string } {
      const col = record.errorColumns.find(c => c.columnName === fieldName);
      if (!col || !col.errorMessage) return { value: col?.columnValue || '', errorMessage: 'Unknown Error' };

      return { value: col.columnValue, errorMessage: col.errorMessage };
  }

  onFieldSelectionChange(fieldName: string): void {
    this.selectedErrorField.set(fieldName);
    this.selectedRecordIds.set(new Set());
    this.currentPage.set(1);
    this.correctionValue.set('');
    this.correctionValueError.set(null);
  }
  
  toggleRecordSelection(recordId: string): void {
    this.selectedRecordIds.update(currentSet => {
      const newSet = new Set(currentSet);
      newSet.has(recordId) ? newSet.delete(recordId) : newSet.add(recordId);
      return newSet;
    });
  }

  toggleSelectAllVisible(): void {
    const visibleIds = this.paginatedRecords().map(r => r.id);
    const allSelected = this.isAllVisibleSelected();
    this.selectedRecordIds.update(currentSet => {
      const newSet = new Set(currentSet);
      if (allSelected) {
        visibleIds.forEach(id => newSet.delete(id));
      } else {
        visibleIds.forEach(id => newSet.add(id));
      }
      return newSet;
    });
  }
  
  goToPage(page: number): void {
    if (page >= 1 && page <= this.totalPages()) {
      this.currentPage.set(page);
    }
  }

  onCorrectionValueChange(value: string): void {
    this.correctionValue.set(value);
    this.correctionValueError.set(this.validateCorrectionValue(value));
  }

  private validateCorrectionValue(value: string): string | null {
    const rules = this.selectedFieldValidationRules();
    if (!rules) return null;

    if (rules.mandate && !value.trim()) {
      return 'This field is mandatory.';
    }
    if (value.length > rules.maxLength) {
      return `Value cannot exceed ${rules.maxLength} characters.`;
    }
    if (rules.uiValidationPattern && value) {
      const pattern = rules.uiValidationPattern.startsWith('^') ? rules.uiValidationPattern : `^${rules.uiValidationPattern}$`;
      try {
        const regex = new RegExp(pattern);
        if (!regex.test(value)) {
            return 'Value does not match the required pattern.';
        }
      } catch (e) {
          console.error("Invalid regex pattern provided:", rules.uiValidationPattern);
          return "Invalid validation pattern configured.";
      }
    }
    if (rules.dataType.toLowerCase() === 'date' && value && !/^\d{4}-\d{2}-\d{2}$/.test(value)) {
      return 'Please use YYYY-MM-DD format for dates.';
    }

    return null;
  }
  
  applyBulkChanges(): void {
    const field = this.selectedErrorField();
    const newValue = this.correctionValue();
    const idsToUpdate = this.selectedRecordIds();
    
    if (!field || idsToUpdate.size === 0 || this.correctionValueError()) return;
    
    const updatedRecords = this.errorRecords().map(record => {
        if (idsToUpdate.has(record.id)) {
            const newAllColumns = record.allColumns.map(col => {
                if (col.columnName === field) {
                    return { ...col, columnValue: newValue, isCorrected: true, hasError: false, error: false, errorMessage: null };
                }
                return col;
            });

            // Rebuild the other column arrays from the updated source of truth
            const newErrorColumns = record.errorColumns.map(c => newAllColumns.find(ac => ac.columnName === c.columnName && ac.error)!).filter(Boolean);
            const newRefColumns = record.referenceColumns.map(c => newAllColumns.find(ac => ac.columnName === c.columnName)!);

            return { ...record, allColumns: newAllColumns, errorColumns: newErrorColumns, referenceColumns: newRefColumns };
        }
        return record;
    });
    this.recordsUpdated.emit(updatedRecords);

    // Reset UI after applying changes
    this.selectedRecordIds.set(new Set());
    this.correctionValue.set('');
  }
}
