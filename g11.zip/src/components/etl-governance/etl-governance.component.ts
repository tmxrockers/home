import { ChangeDetectionStrategy, Component, signal, computed, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConfirmationDialogComponent } from '../confirmation-dialog/confirmation-dialog.component';
import { BulkEditComponent } from '../bulk-edit/bulk-edit.component';

// --- Data Structures & Types based on API Response ---

type EtlFileStatus = 'PendingReview' | 'error' | 'processed' | 'approved';

type EtlFileType = 
  | 'ITCL_Open_Positions_Report' 
  | 'SP Headcount Monthly' 
  | 'SP_BENCH_REPORT'
  | 'ITCL_HC_Weekly'
  | 'SP_Headcount'
  | string;

interface EtlFile {
  etlTransId: string;
  uploadType: EtlFileType;
  uploadedOn: string;
  totalRecords: number;
  uploadedVersion: number;
  errorRecords: number;
  governanceStatus: EtlFileStatus;
  statusText: string;
  snapshotGeneratedFor: string;
}

// New API-aligned interfaces
export interface GovernanceErrorColumn {
  columnName: string;
  columnValue: string;
  maxLength: number;
  errorMessage: string | null;
  dataType: string;
  detailedError: string | null;
  uiValidationPattern: string | null;
  duplicateColumn: boolean;
  dbColumnName: string;
  hasError: boolean;
  mandate: boolean;
  error: boolean;
  isCorrected?: boolean; // UI-only state
}

export interface GovernanceErrorRow {
  rowNum: number;
  id: string; // UI-only unique ID for tracking
  errorCount: number;
  correctedErrorCount: number;
  action: string | null;
  rowError: string | null;
  errorColumns: GovernanceErrorColumn[];
  referenceColumns: GovernanceErrorColumn[]; // Kept for structured display in UI
  allColumns: GovernanceErrorColumn[];
  transId: number;
  editModeOn: boolean;
  uploadType: string | null;
  personId: string;
  contractorId: string;
  resource: string;
  autoCorrected: boolean;
  errorField: string | null;
  totalActiveRecords: number;
  fixed: boolean;
  rowDeleted: boolean;
  correctedOnPending: boolean;
}


export interface GovernanceErrorReportResponse {
  rows: GovernanceErrorRow[];
  totalPageNumber: number;
  duplicateExists: boolean;
  status: 'Success' | 'Failure';
}


interface SummaryStat {
  label: string;
  value: string | number;
  icon: string;
  colorClass: string;
}

const EDITABLE_FILE_TYPES: EtlFileType[] = [
  'SP Headcount Monthly',
  'SP_Headcount',
  'ITCL_HC_Weekly',
];

@Component({
  selector: 'app-etl-governance',
  imports: [CommonModule, ConfirmationDialogComponent, BulkEditComponent],
  templateUrl: './etl-governance.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class EtlGovernanceComponent {
  // --- State Signals ---
  viewMode = signal<'list' | 'detail' | 'bulkEdit'>('list');
  activeTab = signal<'pending' | 'reviewed' | 'approved'>('pending');
  allFiles = signal<EtlFile[]>([]);
  selectedFile = signal<EtlFile | null>(null);

  // Detail View State
  governanceReport = signal<GovernanceErrorReportResponse | null>(null);
  allErrorRecords = computed(() => this.governanceReport()?.rows ?? []);
  filterSearchTerm = signal('');
  showAutoCorrected = signal(false);
  editingError = signal<{ recordId: string; field: string; originalValue: string } | null>(null);


  // --- Computed Signals ---

  filteredFiles = computed(() => {
    const tab = this.activeTab();
    let statuses: EtlFileStatus[];
    if (tab === 'pending') {
      statuses = ['PendingReview', 'error'];
    } else if (tab === 'reviewed') {
      statuses = ['processed'];
    } else {
      statuses = ['approved'];
    }
    return this.allFiles().filter(file => statuses.includes(file.governanceStatus));
  });

  pendingReviewCount = computed(() => this.allFiles().filter(f => f.governanceStatus === 'PendingReview' || f.governanceStatus === 'error').length);
  reviewedCount = computed(() => this.allFiles().filter(f => f.governanceStatus === 'processed').length);
  approveSnapshotsCount = computed(() => this.allFiles().filter(f => f.governanceStatus === 'approved').length);

  isCurrentFileEditable = computed(() => {
    const file = this.selectedFile();
    return file ? EDITABLE_FILE_TYPES.includes(file.uploadType) : false;
  });

  correctedErrorCount = computed(() => {
    return this.allErrorRecords().reduce((count, record) => {
      const correctedInRecord = record.allColumns.filter(col => col.isCorrected).length;
      return count + correctedInRecord;
    }, 0);
  });
  
  summaryStats = computed<SummaryStat[]>(() => {
    const file = this.selectedFile();
    if (!file) return [];
    return [
      { label: 'File Name', value: file.uploadType, icon: 'description', colorClass: 'bg-secondary' },
      { label: 'Total Records', value: file.totalRecords.toLocaleString(), icon: 'storage', colorClass: 'bg-info' },
      { label: 'Version', value: file.uploadedVersion, icon: 'layers', colorClass: 'bg-primary' },
      { label: 'Total Errors', value: file.errorRecords, icon: 'error', colorClass: 'bg-danger' },
      { label: 'Corrected Errors', value: this.correctedErrorCount(), icon: 'task_alt', colorClass: 'bg-success' },
      { label: 'Status', value: file.statusText, icon: 'flag', colorClass: 'bg-warning' }
    ];
  });
  
  filteredErrorRecords = computed(() => {
    const term = this.filterSearchTerm().toLowerCase();
    const showCorrected = this.showAutoCorrected();
    return this.allErrorRecords().filter(record => {
      const allCorrected = record.errorColumns.every(c => c.isCorrected);
      if (!showCorrected && allCorrected) {
        return false;
      }
      if (term) {
        return record.allColumns.some(c => c.columnValue && c.columnValue.toLowerCase().includes(term));
      }
      return true;
    });
  });

  referenceColumnsForDisplay = computed(() => {
      const firstRecord = this.allErrorRecords()[0];
      if (!firstRecord) return [];
      return firstRecord.referenceColumns.map(c => c.columnName);
  });

  errorColumnsForDisplay = computed(() => {
      const firstRecord = this.allErrorRecords()[0];
      if (!firstRecord) return [];
      return firstRecord.errorColumns.map(c => c.columnName);
  });

  constructor() {
    this.allFiles.set(this.generateMockFiles());
    // When a file is selected, generate its error records.
    effect(() => {
      const file = this.selectedFile();
      if (file && (this.viewMode() === 'detail' || this.viewMode() === 'bulkEdit')) {
        this.governanceReport.set(this.generateMockErrorResponse(file));
      } else {
        this.governanceReport.set(null);
      }
    });
  }

  private generateMockFiles(): EtlFile[] {
    return [
      { etlTransId: '9050', uploadType: 'SP Headcount Monthly', uploadedOn: '11/21/2025', totalRecords: 2326, uploadedVersion: 9, errorRecords: 500, governanceStatus: 'PendingReview', statusText: 'Review Required', snapshotGeneratedFor: 'Oct-2025' },
      { etlTransId: '9048', uploadType: 'SP_Headcount', uploadedOn: '11/20/2025', totalRecords: 800, uploadedVersion: 1, errorRecords: 15, governanceStatus: 'PendingReview', statusText: 'Pending', snapshotGeneratedFor: 'Nov-2025' },
      { etlTransId: '9046', uploadType: 'SP_BENCH_REPORT', uploadedOn: '11/19/2025', totalRecords: 1200, uploadedVersion: 2, errorRecords: 0, governanceStatus: 'processed', statusText: 'Processed', snapshotGeneratedFor: 'N/A' },
      { etlTransId: '8951', uploadType: 'ITCL_HC_Weekly', uploadedOn: '11/18/2025', totalRecords: 11445, uploadedVersion: 3, errorRecords: 5257, governanceStatus: 'error', statusText: 'Review Required', snapshotGeneratedFor: '07/01/2025 - 07/12/2025' },
      { etlTransId: '9035', uploadType: 'ITCL_Open_Positions_Report', uploadedOn: '11/17/2025', totalRecords: 4500, uploadedVersion: 1, errorRecords: 0, governanceStatus: 'approved', statusText: 'Approved', snapshotGeneratedFor: 'N/A' },
    ];
  }

  private generateMockErrorResponse(file: EtlFile): GovernanceErrorReportResponse {
    const errorRows: GovernanceErrorRow[] = [];
    if (!EDITABLE_FILE_TYPES.includes(file.uploadType)) {
        return { rows: [], totalPageNumber: 0, duplicateExists: false, status: 'Success' };
    }
    
    const firstNames = ['John', 'Jane', 'Peter', 'Mary', 'David', 'Susan'];
    const lastNames = ['Doe', 'Smith', 'Jones', 'Williams', 'Brown', 'Davis'];

    for (let i = 1; i <= 500; i++) {
        const personId = (100000 + i).toString();
        const contractorId = `BACGWK${200000 + i}`;
        const resourceName = `${firstNames[i % firstNames.length]} ${lastNames[i % lastNames.length]}`;

        // These columns are for display in the first column of the detail view
        const referenceColumns: GovernanceErrorColumn[] = [
            { columnName: 'Person ID', columnValue: personId, error: false, mandate: true, maxLength: 10, dataType: 'Alpha Numeric', errorMessage: null, uiValidationPattern: '^[0-9]+$', dbColumnName: 'PERSON_ID', hasError: false, duplicateColumn: false, detailedError: null },
            { columnName: 'Contractor ID', columnValue: contractorId, error: false, mandate: true, maxLength: 15, dataType: 'Alpha Numeric', errorMessage: null, uiValidationPattern: '^BACGWK[0-9]+$', dbColumnName: 'CONTRACTOR_ID', hasError: false, duplicateColumn: false, detailedError: null },
            { columnName: 'Resource', columnValue: resourceName, error: false, mandate: true, maxLength: 20, dataType: 'Alpha', errorMessage: null, uiValidationPattern: '^[a-zA-Z ]+$', dbColumnName: 'RESOURCE_NAME', hasError: false, duplicateColumn: false, detailedError: null },
        ];
        
        let initialErrorColumns: GovernanceErrorColumn[] = [
            { columnName: 'Supplier', columnValue: 'TCS', error: false, mandate: true, maxLength: 80, dataType: 'Alpha', errorMessage: null, uiValidationPattern: '^[a-zA-Z0-9 ]+$', dbColumnName: 'SUPPLIER', hasError: false, duplicateColumn: false, detailedError: null },
            { columnName: 'Cost Center', columnValue: `US${1000 + (i % 1000)}`, error: false, mandate: true, maxLength: 6, dataType: 'Alpha Numeric', errorMessage: null, uiValidationPattern: '^[A-Z]{2}[0-9]{4}$', dbColumnName: 'COST_CENTER', hasError: false, duplicateColumn: false, detailedError: null },
            { columnName: 'StartDate', columnValue: '2025-10-21', error: false, mandate: true, maxLength: 10, dataType: 'Date', errorMessage: null, uiValidationPattern: '^\\d{4}-\\d{2}-\\d{2}$', dbColumnName: 'START_DATE', hasError: false, duplicateColumn: false, detailedError: null },
        ];

        const errorType = i % 5;
        let errorField = null;

        switch (errorType) {
            case 0: // Logic Error on Supplier (as per user sample)
                const supplierCol = initialErrorColumns.find(c => c.columnName === 'Supplier')!;
                supplierCol.errorMessage = "Field Logic Error: Vendor name in the headcount data does not match values in the 'Normalized vendor name' reference table, please update table";
                errorField = 'Supplier';
                break;
            case 1: // Mandatory Field Error
                const costCenterCol = initialErrorColumns.find(c => c.columnName === 'Cost Center')!;
                costCenterCol.columnValue = '';
                costCenterCol.errorMessage = 'Field is mandatory and cannot be empty.';
                errorField = 'Cost Center';
                break;
            case 2: // Pattern Mismatch Error
                 const anotherCostCenterCol = initialErrorColumns.find(c => c.columnName === 'Cost Center')!;
                 anotherCostCenterCol.columnValue = `CC-INVALID-${i}`;
                 anotherCostCenterCol.errorMessage = 'Value does not match the required pattern (e.g., US1234).';
                 errorField = 'Cost Center';
                break;
            case 3: // Date Format Error
                const startDateCol = initialErrorColumns.find(c => c.columnName === 'StartDate')!;
                startDateCol.columnValue = `10/21/2025`;
                startDateCol.errorMessage = 'Invalid date format. Expected YYYY-MM-DD.';
                errorField = 'StartDate';
                break;
            case 4: // Max Length Error (moved to error columns)
                 const resourceCol = referenceColumns.find(c => c.columnName === 'Resource')!;
                 resourceCol.columnValue = 'A Very Long Resource Name That Far Exceeds The Limit';
                 resourceCol.errorMessage = 'Value exceeds maximum length of 20 characters.';
                 initialErrorColumns.push(resourceCol); // Add to error columns for display
                 errorField = 'Resource';
                break;
        }
        
        // Set error flags
        initialErrorColumns.forEach(ec => {
            if (ec.errorMessage) {
                ec.error = true;
                ec.hasError = true;
            }
        });

        errorRows.push({
            rowNum: i,
            id: `err-${file.etlTransId}-${i}`,
            errorCount: initialErrorColumns.filter(c => c.hasError).length,
            correctedErrorCount: 0,
            action: null,
            rowError: null,
            errorColumns: initialErrorColumns,
            referenceColumns,
            allColumns: [...referenceColumns, ...initialErrorColumns],
            transId: parseInt(file.etlTransId, 10),
            editModeOn: false,
            uploadType: file.uploadType,
            personId,
            contractorId,
            resource: resourceName,
            autoCorrected: i % 10 === 0, // Mock auto-correction for some rows
            errorField: errorField,
            totalActiveRecords: 0,
            fixed: i % 10 === 0, // Mock fixed for some rows
            rowDeleted: false,
            correctedOnPending: false,
        });
    }
    
    return {
        rows: errorRows,
        totalPageNumber: Math.ceil(errorRows.length / 50),
        duplicateExists: false,
        status: 'Success'
    };
  }
  
  getColumnForRecord(record: GovernanceErrorRow, columnName: string): GovernanceErrorColumn | undefined {
      return record.allColumns.find(c => c.columnName === columnName);
  }

  // --- Methods ---
  changeTab(tab: 'pending' | 'reviewed' | 'approved'): void {
    this.activeTab.set(tab);
  }

  reviewFile(file: EtlFile): void {
    this.selectedFile.set(file);
    this.viewMode.set('detail');
  }

  goBackToList(): void {
    this.viewMode.set('list');
    this.selectedFile.set(null);
  }
  
  goBackToDetailView(): void {
    this.viewMode.set('detail');
  }

  navigateToBulkEdit(): void {
    this.viewMode.set('bulkEdit');
  }

  clearFilters(): void {
    this.filterSearchTerm.set('');
  }

  startEditing(recordId: string, field: string, value: string): void {
    this.editingError.set({ recordId, field, originalValue: value });
  }

  cancelEditing(): void {
    this.editingError.set(null);
  }

  saveEditing(recordId: string, field: string, event: Event): void {
    const newValue = (event.target as HTMLInputElement).value;
    this.governanceReport.update(report => {
        if (!report) return null;
        const newRows = report.rows.map(rec => {
            if (rec.id === recordId) {
                const newAllColumns = rec.allColumns.map(col => {
                    if (col.columnName === field) {
                        return { ...col, columnValue: newValue, isCorrected: true, hasError: false, error: false };
                    }
                    return col;
                });
                // Also update the specific arrays
                const newErrorColumns = rec.errorColumns.map(c => newAllColumns.find(ac => ac.columnName === c.columnName)!);
                const newRefColumns = rec.referenceColumns.map(c => newAllColumns.find(ac => ac.columnName === c.columnName)!);

                return { ...rec, allColumns: newAllColumns, errorColumns: newErrorColumns, referenceColumns: newRefColumns };
            }
            return rec;
        });
        return { ...report, rows: newRows };
    });
    this.cancelEditing();
  }

  onRecordsUpdated(updatedRecords: GovernanceErrorRow[]): void {
    this.governanceReport.update(report => {
        if(!report) return null;
        return { ...report, rows: updatedRecords };
    });
  }
}