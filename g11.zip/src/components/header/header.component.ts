import { ChangeDetectionStrategy, Component, output, signal, input, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { User } from '../confirmation-dialog/app/services/rbac.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule],
  host: {
    '(document:click)': 'onDocumentClick()',
  }
})
export class HeaderComponent {
  isSidebarOpen = input(false);
  user = input.required<User>();
  toggleSidebar = output<void>();
  isProfileDropdownOpen = signal(false);
  appVersion = 'v16.0';

  formattedRole = computed(() => {
    const role = this.user().role;
    const roleName = role.replace('dataLoader', 'Data Loader')
                         .replace('staffingOps', 'Staffing Ops')
                         .replace('hrPartner', 'HR Partner')
                         .replace('financeAnalyst', 'Finance Analyst')
                         .replace('itSupport', 'IT Support');
    return roleName.charAt(0).toUpperCase() + roleName.slice(1);
  });

  toggleProfileDropdown(event: MouseEvent): void {
    event.stopPropagation();
    this.isProfileDropdownOpen.update(v => !v);
  }

  onDocumentClick(): void {
    if (this.isProfileDropdownOpen()) {
      this.isProfileDropdownOpen.set(false);
    }
  }
}