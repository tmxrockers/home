import { ChangeDetectionStrategy, Component, computed, inject, input, output, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RbacService, User, MenuItem } from '../confirmation-dialog/app/services/rbac.service';

interface MenuGroup {
  name: string;
  items: MenuItem[];
}

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule],
})
export class SidebarComponent {
  isOpen = input<boolean>(true);
  user = input.required<User>();
  activeItem = input<string>('dashboard');
  closeSidebar = output<void>();
  itemSelected = output<string>();

  private rbacService = inject(RbacService);
  
  menuGroups = computed((): MenuGroup[] => {
    const allItems = this.rbacService.getFeaturesForUser(this.user());
    const groups: Record<string, MenuItem[]> = {};
    
    for (const item of allItems) {
      const category = item.category || 'Other';
      if (!groups[category]) {
        groups[category] = [];
      }
      groups[category].push(item);
    }

    // Define a specific order for categories to ensure a consistent layout
    const categoryOrder = [
      'Main', 
      'Administration', 
      'Configuration', 
      'Reporting', 
      'Support', 
      'Data Management', 
      'HR & Staffing', 
      'Other'
    ];
    
    return categoryOrder
      .map(name => ({
        name,
        items: groups[name] || []
      }))
      .filter(group => group.items.length > 0);
  });

  formattedRole = computed(() => {
    const role = this.user().role;
    const roleName = role.replace('dataLoader', 'Data Loader')
                         .replace('staffingOps', 'Staffing Ops')
                         .replace('hrPartner', 'HR Partner')
                         .replace('financeAnalyst', 'Finance Analyst')
                         .replace('itSupport', 'IT Support');
    return roleName.charAt(0).toUpperCase() + roleName.slice(1);
  });

  selectItem(id: string): void {
    this.itemSelected.emit(id);
    if (window.innerWidth < 768) { // Close sidebar on mobile after selection
      this.closeSidebar.emit();
    }
  }
}