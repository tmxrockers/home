
import { bootstrapApplication } from '@angular/platform-browser';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';

import { AppComponent } from './src/app.component';

bootstrapApplication(AppComponent, {
  providers: [
    provideAnimationsAsync()
  ]
}).catch(err => console.error(err));

// AI Studio always uses an `index.tsx` file for all project types.