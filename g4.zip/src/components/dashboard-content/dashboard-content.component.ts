import { ChangeDetectionStrategy, Component, signal, Output, EventEmitter, input, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RbacConfigComponent } from '../rbac-config/rbac-config.component';
import { FeatureConfigComponent } from '../feature-config/feature-config.component';
import { RbacService, User } from '../../app/services/rbac.service';
import { ConfirmationDialogComponent, ConfirmDialogData } from '../confirmation-dialog/confirmation-dialog.component';
import { UserModuleMappingComponent } from '../user-module-mapping/user-module-mapping.component';
import { MatTabsModule } from '@angular/material/tabs';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatChipsModule } from '@angular/material/chips';
import { MatDialog } from '@angular/material/dialog';
import { filter } from 'rxjs';
import { MatCardModule } from '@angular/material/card';

interface Requisition {
  wmpId: string;
  cio: string;
  jobTitle: string;
  location: string;
  priority: 'High' | 'Medium' | 'Critical' | 'Low';
  status: 'Open' | 'In Progress' | 'On Hold';
}

@Component({
  selector: 'app-dashboard-content',
  templateUrl: './dashboard-content.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule, 
    RbacConfigComponent, 
    FeatureConfigComponent, 
    UserModuleMappingComponent,
    MatTabsModule,
    MatButtonToggleModule,
    MatTableModule,
    MatButtonModule,
    MatIconModule,
    MatChipsModule,
    MatCardModule
  ],
})
export class DashboardContentComponent {
  @Output() userChanged = new EventEmitter<string>();
  currentUser = input.required<User>();

  rbacService = inject(RbacService);
  dialog = inject(MatDialog);

  activeTab = signal<'rbac' | 'feature' | 'user-module-mapping'>('rbac');
  
  displayedColumns = ['wmpId', 'cio', 'jobTitle', 'location', 'priority', 'status', 'actions'];
  
  requisitions = signal<Requisition[]>([
    { wmpId: 'WMP001234', cio: 'Technology', jobTitle: 'Application Programmer II', location: 'Charlotte, NC', priority: 'High', status: 'Open' },
    { wmpId: 'WMP001235', cio: 'Banking', jobTitle: 'Data Analyst', location: 'New York, NY', priority: 'Medium', status: 'Open' },
    { wmpId: 'WMP001236', cio: 'Technology', jobTitle: 'DevOps Engineer', location: 'San Francisco, CA', priority: 'Critical', status: 'In Progress' },
    { wmpId: 'WMP001237', cio: 'Finance', jobTitle: 'Financial Analyst', location: 'Chicago, IL', priority: 'High', status: 'Open' },
    { wmpId: 'WMP001238', cio: 'Technology', jobTitle: 'UI/UX Designer', location: 'Remote', priority: 'Medium', status: 'Open' },
    { wmpId: 'WMP001239', cio: 'Operations', jobTitle: 'Project Manager', location: 'Boston, MA', priority: 'High', status: 'In Progress' },
    { wmpId: 'WMP001240', cio: 'Technology', jobTitle: 'Business Analyst', location: 'Atlanta, GA', priority: 'Low', status: 'On Hold' },
    { wmpId: 'WMP001241', cio: 'Quality Assurance', jobTitle: 'QA Engineer', location: 'Dallas, TX', priority: 'Medium', status: 'Open' },
  ]);
  
  dataSource = new MatTableDataSource<Requisition>(this.requisitions());

  getPriorityChip(priority: 'High' | 'Medium' | 'Critical' | 'Low'): {color: 'warn' | 'accent' | undefined, text: string} {
    switch (priority) {
      case 'Critical': return { color: 'warn', text: 'Critical' };
      case 'High': return { color: 'accent', text: 'High' };
      default: return { color: undefined, text: priority };
    }
  }

  getStatusChip(status: 'Open' | 'In Progress' | 'On Hold'): {color: 'primary' | 'accent' | undefined, text: string, selected: boolean} {
    switch (status) {
      case 'In Progress': return { color: 'accent', text: 'In Progress', selected: true };
      case 'On Hold': return { color: undefined, text: 'On Hold', selected: true };
      default: return { color: 'primary', text: status, selected: true };
    }
  }

  selectTab(event: { index: number }): void {
    const currentTab = this.activeTab();
    const newTab = this.getTabNameByIndex(event.index);

    if (newTab === currentTab) return;

    let isCurrentTabDirty = false;
    switch(currentTab) {
        case 'rbac': isCurrentTabDirty = this.rbacService.rbacDirty(); break;
        case 'feature': isCurrentTabDirty = this.rbacService.featureDirty(); break;
        case 'user-module-mapping': isCurrentTabDirty = this.rbacService.userModuleMappingDirty(); break;
    }

    if (isCurrentTabDirty) {
      const dialogRef = this.dialog.open<ConfirmationDialogComponent, ConfirmDialogData, boolean>(ConfirmationDialogComponent, {
        data: {
          title: 'Unsaved Changes',
          message: 'You have unsaved changes in the current tab. Do you want to discard them and switch tabs?',
          confirmText: 'Discard and Switch'
        }
      });

      dialogRef.afterClosed().pipe(filter(result => !!result)).subscribe(() => {
        this.confirmSwitchTab();
        this.activeTab.set(newTab);
      });
    } else {
      this.activeTab.set(newTab);
    }
  }
  
  private getTabNameByIndex(index: number): 'rbac' | 'feature' | 'user-module-mapping' {
      switch(index) {
          case 0: return 'rbac';
          case 1: return 'user-module-mapping';
          case 2: return 'feature';
          default: return 'rbac';
      }
  }

  private confirmSwitchTab(): void {
    const currentTab = this.activeTab();
    switch(currentTab) {
        case 'rbac': this.rbacService.discardRbacChanges$.next(); break;
        case 'feature': this.rbacService.discardFeatureChanges$.next(); break;
        case 'user-module-mapping': this.rbacService.discardUserModuleMappingChanges$.next(); break;
    }
  }
}
