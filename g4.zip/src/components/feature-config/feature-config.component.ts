import { ChangeDetectionStrategy, Component, computed, effect, inject, OnDestroy, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RbacService, MenuItem } from '../../app/services/rbac.service';
import { Subscription, filter } from 'rxjs';
import { ConfirmationDialogComponent, ConfirmDialogData } from '../confirmation-dialog/confirmation-dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { CdkDragDrop, DragDropModule, moveItemInArray } from '@angular/cdk/drag-drop';
import { FeatureEditDialogComponent, FeatureEditDialogData } from '../feature-edit-dialog/feature-edit-dialog.component';

import { MatExpansionModule } from '@angular/material/expansion';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatTooltipModule } from '@angular/material/tooltip';


@Component({
  selector: 'app-feature-config',
  standalone: true,
  templateUrl: './feature-config.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule, 
    DragDropModule,
    MatExpansionModule,
    MatButtonModule,
    MatIconModule,
    MatSlideToggleModule,
    MatFormFieldModule,
    MatInputModule,
    MatTooltipModule
  ],
})
export class FeatureConfigComponent implements OnDestroy {
  private rbacService = inject(RbacService);
  private dialog = inject(MatDialog);
  private subscriptions = new Subscription();

  allFeatures = signal<MenuItem[]>([]);
  searchTerm = signal<string>('');
  
  private initialFeatures: MenuItem[] = [];
  private allFeaturesFlat = new Map<string, { item: MenuItem, parentId: string | null }>();

  successMessage = signal('');
  private successMessageTimeout: any;

  isDirty = computed(() => {
    return JSON.stringify(this.initialFeatures) !== JSON.stringify(this.allFeatures());
  });

  filteredFeatures = computed(() => {
    const term = this.searchTerm().toLowerCase().trim();
    if (!term) {
      return this.allFeatures();
    }

    const results: MenuItem[] = [];
    for (const feature of this.allFeatures()) {
      const matchingChildren = feature.children?.filter(child => 
        child.label.toLowerCase().includes(term) || child.description?.toLowerCase().includes(term)
      ) ?? [];

      const featureMatch = feature.label.toLowerCase().includes(term) || feature.description?.toLowerCase().includes(term);

      if (featureMatch || matchingChildren.length > 0) {
        const newFeature = { ...feature };
        if (featureMatch) {
          newFeature.children = feature.children;
        } else {
          newFeature.children = matchingChildren;
        }
        results.push(newFeature);
      }
    }
    return results;
  });

  constructor() {
    this.loadInitialState();
    
    effect(() => {
      this.rbacService.featureDirty.set(this.isDirty());
    });

    this.subscriptions.add(
      this.rbacService.discardFeatureChanges$.subscribe(() => {
        this.resetState();
      })
    );
  }
  
  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  private showSuccessMessage(message: string): void {
    this.successMessage.set(message);
    clearTimeout(this.successMessageTimeout);
    this.successMessageTimeout = setTimeout(() => this.successMessage.set(''), 3000);
  }

  private loadInitialState(): void {
    const features = this.rbacService.getRawFeatures();
    this.initialFeatures = JSON.parse(JSON.stringify(features));
    this.allFeatures.set(JSON.parse(JSON.stringify(features)));
    this.rebuildFlatMap();
  }

  private rebuildFlatMap(): void {
    this.allFeaturesFlat.clear();
    const processFeatures = (items: MenuItem[], parentId: string | null = null) => {
      for (const item of items) {
        this.allFeaturesFlat.set(item.id, { item, parentId });
        if (item.children) {
          processFeatures(item.children, item.id);
        }
      }
    };
    processFeatures(this.allFeatures());
  }

  private resetState(): void {
    this.allFeatures.set(JSON.parse(JSON.stringify(this.initialFeatures)));
    this.rebuildFlatMap();
  }
  
  private findFeatureById(id: string, features: MenuItem[]): MenuItem | undefined {
    for (const feature of features) {
        if (feature.id === id) return feature;
        if (feature.children) {
            const found = this.findFeatureById(id, feature.children);
            if (found) return found;
        }
    }
    return undefined;
  }

  onSearchTermChange(event: Event): void {
    this.searchTerm.set((event.target as HTMLInputElement).value);
  }

  onStatusChange(featureId: string, isActive: boolean): void {
    const updateStatusesRecursively = (items: MenuItem[], targetId: string, newStatus: boolean): MenuItem[] => {
      return items.map(item => {
        let newItem = { ...item };
        if (newItem.id === targetId) {
          newItem.isActive = newStatus;
          if (!newStatus && newItem.children) {
            const deactivateChildren = (children: MenuItem[]): MenuItem[] => {
              return children.map(child => ({
                ...child,
                isActive: false,
                children: child.children ? deactivateChildren(child.children) : undefined,
              }));
            };
            newItem.children = deactivateChildren(newItem.children);
          }
        } else if (item.children) {
          newItem.children = updateStatusesRecursively(item.children, targetId, newStatus);
        }
        return newItem;
      });
    };

    this.allFeatures.update(features => {
      let updatedFeatures = updateStatusesRecursively(features, featureId, isActive);

      if (isActive) {
        const activateParents = (childId: string, currentFeatures: MenuItem[]) => {
          let parentId = this.allFeaturesFlat.get(childId)?.parentId;
          while (parentId) {
            const parentToActivate = this.findFeatureById(parentId, currentFeatures);
            if (parentToActivate) parentToActivate.isActive = true;
            parentId = this.allFeaturesFlat.get(parentId)?.parentId;
          }
        };
        activateParents(featureId, updatedFeatures);
      }
      return updatedFeatures;
    });
  }

  onDrop(event: CdkDragDrop<MenuItem[]>) {
    moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    this.allFeatures.update(features => [...features]);
  }

  openEditDialog(item: MenuItem | null, parentId: string | null): void {
    const dialogRef = this.dialog.open<FeatureEditDialogComponent, FeatureEditDialogData, MenuItem>(FeatureEditDialogComponent, {
      width: '500px',
      data: {
        item,
        parentId,
        allFeatures: this.allFeatures()
      }
    });

    dialogRef.afterClosed().pipe(filter(result => !!result)).subscribe(result => {
        if(item) { // Editing
             this.allFeatures.update(features => {
                const updateItem = (items: MenuItem[]): MenuItem[] => {
                    return items.map(i => {
                        if (i.id === item.id) return { ...i, ...result };
                        if (i.children) return { ...i, children: updateItem(i.children) };
                        return i;
                    });
                };
                return updateItem(features);
            });
        } else { // Adding
            if(parentId) {
                this.allFeatures.update(features => {
                    const addItem = (items: MenuItem[]): MenuItem[] => {
                        return items.map(i => {
                           if (i.id === parentId) {
                               const children = i.children ? [...i.children, result!] : [result!];
                               return { ...i, children };
                           }
                           if (i.children) return { ...i, children: addItem(i.children) };
                           return i;
                        });
                    };
                    return addItem(features);
                });
            } else {
                 this.allFeatures.update(features => [...features, result!]);
            }
        }
        this.rebuildFlatMap();
    });
  }
  
  promptDeleteMenuItem(id: string, name: string): void {
    const dialogRef = this.dialog.open<ConfirmationDialogComponent, ConfirmDialogData, boolean>(ConfirmationDialogComponent, {
      data: {
        title: 'Confirm Deletion',
        message: `Are you sure you want to delete '${name}'? If it has children, they will also be deleted.`,
        confirmText: 'Delete'
      }
    });

    dialogRef.afterClosed().pipe(filter(r => !!r)).subscribe(() => {
      this.deleteMenuItem(id);
    });
  }

  private deleteMenuItem(idToDelete: string): void {
      const removeItemRecursively = (items: MenuItem[], id: string): MenuItem[] => {
        const filtered = items.filter(item => item.id !== id);
        return filtered.map(item => {
          if (item.children) {
            return { ...item, children: removeItemRecursively(item.children, id) };
          }
          return item;
        });
      };
      this.allFeatures.update(features => removeItemRecursively(features, idToDelete));
      this.rebuildFlatMap();
  }

  saveChanges(): void {
    if (!this.isDirty()) return;
    const dialogRef = this.dialog.open<ConfirmationDialogComponent, ConfirmDialogData, boolean>(ConfirmationDialogComponent, {
        data: { title: 'Confirm Save', message: 'Are you sure you want to save the changes to the menu structure?', confirmText: 'Save'}
    });
    dialogRef.afterClosed().pipe(filter(r => !!r)).subscribe(() => {
        this.rbacService.updateFeatures(this.allFeatures());
        this.loadInitialState();
        this.showSuccessMessage('Menu structure changes saved successfully.');
    });
  }

  discardChanges(): void {
    if (!this.isDirty()) return;
    const dialogRef = this.dialog.open<ConfirmationDialogComponent, ConfirmDialogData, boolean>(ConfirmationDialogComponent, {
        data: { title: 'Confirm Discard', message: 'Are you sure you want to discard your unsaved changes?', confirmText: 'Discard'}
    });

    dialogRef.afterClosed().pipe(filter(r => !!r)).subscribe(() => {
        this.resetState();
        this.showSuccessMessage('Unsaved changes have been discarded.');
    });
  }
}
