import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { RbacService, MenuItem } from '../../app/services/rbac.service';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';

export interface FeatureEditDialogData {
    item: MenuItem | null;
    parentId: string | null;
    allFeatures: MenuItem[];
}

interface AppRoute {
  path: string;
  name: string;
}

interface AppIcon {
  name: string;
  id: string;
}

const MAX_LABEL_LENGTH = 50;

@Component({
  selector: 'app-feature-edit-dialog',
  standalone: true,
  imports: [
    CommonModule, 
    ReactiveFormsModule, 
    MatDialogModule, 
    MatFormFieldModule, 
    MatInputModule, 
    MatButtonModule,
    MatSelectModule,
    MatIconModule,
    MatMenuModule
  ],
  templateUrl: './feature-edit-dialog.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FeatureEditDialogComponent {
  private fb = inject(FormBuilder);
  public dialogRef = inject(MatDialogRef<FeatureEditDialogComponent>);
  public data: FeatureEditDialogData = inject(MAT_DIALOG_DATA);

  form = this.fb.group({
    label: ['', [Validators.required, Validators.maxLength(MAX_LABEL_LENGTH), this.duplicateNameValidator.bind(this)]],
    icon: [''],
    route: ['']
  });
  
  maxLabelLength = MAX_LABEL_LENGTH;

  availableRoutes: AppRoute[] = [
    { path: '/dashboard', name: 'Dashboard' }, { path: '/user-access', name: 'User Access Management' }, { path: '/service-desk', name: 'Service Desk' }, { path: '/reports', name: 'Reports' }, { path: '/file-upload', name: 'File Upload' }, { path: '/config/staffing', name: 'Staffing Ops Config' },
  ];

  availableIcons: AppIcon[] = [
    { name: 'Dashboard', id: 'dashboard' }, { name: 'Users', id: 'group' }, { name: 'Support', id: 'support_agent' }, { name: 'Settings', id: 'settings' }, { name: 'Reports', id: 'assessment' }, { name: 'Analytics', id: 'analytics' }, { name: 'Building', id: 'business' }, { name: 'Briefcase', id: 'work' }, { name: 'Upload', id: 'upload_file' }, { name: 'Download', id: 'download' }, { name: 'History', id: 'history' }, { name: 'Security', id: 'security' }, { name: 'Star', id: 'star' }, { name: 'Globe', id: 'public' }, { name: 'Tasks', id: 'task_alt' }, { name: 'Megaphone', id: 'campaign' }, { name: 'View Grid', id: 'grid_view' },
  ];
  
  constructor() {
    if(this.data.item) {
        this.form.patchValue(this.data.item);
    }
  }

  private findFeatureById(id: string, features: MenuItem[]): MenuItem | undefined {
    for (const feature of features) {
        if (feature.id === id) return feature;
        if (feature.children) {
            const found = this.findFeatureById(id, feature.children);
            if (found) return found;
        }
    }
    return undefined;
  }

  private duplicateNameValidator(control: any) {
    const label = control.value?.trim().toLowerCase();
    if (!label) return null;
    
    let siblings: MenuItem[] = [];
    if(this.data.parentId) {
        const parent = this.findFeatureById(this.data.parentId, this.data.allFeatures);
        siblings = parent?.children || [];
    } else {
        siblings = this.data.allFeatures;
    }
    
    const isDuplicate = siblings.some(item => item.label.toLowerCase() === label && item.id !== this.data.item?.id);

    return isDuplicate ? { duplicateName: true } : null;
  }

  save(): void {
    if (this.form.invalid) {
      return;
    }
    
    const formValue = this.form.value;
    const result: Partial<MenuItem> = {
        label: formValue.label!,
        icon: formValue.icon!,
        route: formValue.route!,
    };

    if(!this.data.item) { // New item
        result.id = formValue.label!.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') + `-${Date.now()}`;
        result.isActive = true;
        result.children = [];
    }

    this.dialogRef.close(result);
  }

  close(): void {
    this.dialogRef.close();
  }
}
