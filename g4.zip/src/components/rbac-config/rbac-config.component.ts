import { ChangeDetectionStrategy, Component, inject, signal, effect, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RbacService, MenuItem } from '../../app/services/rbac.service';
import { UserRole } from '../../app.component';
import { Subscription } from 'rxjs';
import { ConfirmationDialogComponent, ConfirmDialogData } from '../confirmation-dialog/confirmation-dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { MatTreeModule, MatTreeNestedDataSource } from '@angular/material/tree';
import { NestedTreeControl } from '@angular/cdk/tree';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatListModule } from '@angular/material/list';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { SelectionModel } from '@angular/cdk/collections';
import { filter } from 'rxjs/operators';

interface RoleDisplay {
  id: UserRole;
  name: string;
  icon: string;
}

@Component({
  selector: 'app-rbac-config',
  templateUrl: './rbac-config.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule, 
    ConfirmationDialogComponent,
    MatTreeModule,
    MatCheckboxModule,
    MatIconModule,
    MatButtonModule,
    MatListModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule
  ],
})
export class RbacConfigComponent implements OnDestroy {
  rbacService = inject(RbacService);
  dialog = inject(MatDialog);
  private subscriptions = new Subscription();

  roles: RoleDisplay[] = [
    { id: 'admin', name: 'Admin', icon: 'admin_panel_settings' },
    { id: 'dataLoader', name: 'Data Loader', icon: 'upload' },
    { id: 'staffingOps', name: 'Staffing Ops', icon: 'group' }
  ];
  selectedRole = signal<UserRole>('admin');
  
  allFeatures: MenuItem[] = [];
  searchTerm = signal<string>('');
  
  treeControl = new NestedTreeControl<MenuItem>(node => node.children);
  dataSource = new MatTreeNestedDataSource<MenuItem>();
  checklistSelection = new SelectionModel<MenuItem>(true);

  private initialPermissions = new Map<UserRole, Set<string>>();
  
  successMessage = signal('');
  private successMessageTimeout: any;

  selectedRoleDetails = signal<RoleDisplay | undefined>(this.roles[0]);

  hasChild = (_: number, node: MenuItem) => !!node.children && node.children.length > 0;

  constructor() {
    this.allFeatures = this.rbacService.getActiveFeatures();
    this.dataSource.data = this.allFeatures;
    this.initializePermissionsState();
    
    effect(() => {
        const roleId = this.selectedRole();
        this.selectedRoleDetails.set(this.roles.find(r => r.id === roleId));
        this.updateSelectionForRole(roleId);
        const isDirty = this.calculateIsDirty();
        this.rbacService.rbacDirty.set(isDirty);
    });

    this.subscriptions.add(
      this.rbacService.discardRbacChanges$.subscribe(() => this.resetState())
    );
  }
  
  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  private showSuccessMessage(message: string): void {
    this.successMessage.set(message);
    clearTimeout(this.successMessageTimeout);
    this.successMessageTimeout = setTimeout(() => this.successMessage.set(''), 3000);
  }

  private initializePermissionsState(): void {
    this.initialPermissions.clear();
    for (const role of this.roles) {
        const permissions = new Set<string>(this.rbacService.getRolePermissions(role.id));
        this.initialPermissions.set(role.id, new Set<string>(permissions));
    }
    this.updateSelectionForRole(this.selectedRole());
  }
  
  private updateSelectionForRole(role: UserRole): void {
    this.checklistSelection.clear();
    const permissions = this.rbacService.getRolePermissions(role);
    const nodesToSelect = this.getNodesFromIds(permissions);
    this.checklistSelection.select(...nodesToSelect);
  }

  private resetState(): void {
    // Revert rolePermissions in service to initial state
    for (const [role, permissions] of this.initialPermissions.entries()) {
      this.rbacService.setPermissionsForRole(role, Array.from(permissions));
    }
    this.updateSelectionForRole(this.selectedRole());
  }

  private calculateIsDirty(): boolean {
    for (const role of this.roles) {
      const initialSet = this.initialPermissions.get(role.id);
      const currentSet = new Set(this.rbacService.getRolePermissions(role.id));

      if (!initialSet) continue;
      if (initialSet.size !== currentSet.size) return true;
      for (const perm of currentSet) {
        // FIX: Explicitly cast `perm` to a string. The compiler was incorrectly inferring its type as 'unknown', causing an error with the `Set.has()` method which expects a string.
        if (!initialSet.has(perm as string)) return true;
      }
    }
    return false;
  }

  onSearchTermChange(event: Event): void {
    // FIX: Safely access the input value by checking if event.target is an HTMLInputElement.
    // This avoids potential runtime errors and satisfies TypeScript's strict type checking.
    const target = event.target;
    if (target instanceof HTMLInputElement) {
      const term = target.value;
      this.searchTerm.set(term);
      this.filterTree(term);
    }
  }

  filterTree(filterText: string): void {
    if (!filterText) {
      this.dataSource.data = this.allFeatures;
      return;
    }
    const filteredData: MenuItem[] = [];
    const filter = (item: MenuItem): boolean => {
      let selfMatch = item.label.toLowerCase().includes(filterText.toLowerCase());
      if (item.children) {
        const childMatches = item.children.filter(filter);
        if (childMatches.length > 0) {
          const newItem = {...item, children: childMatches};
          filteredData.push(newItem);
          return true;
        }
      }
      if(selfMatch && !item.children) {
        filteredData.push(item);
        return true;
      }
      return false;
    }
    this.allFeatures.forEach(filter);
    this.dataSource.data = filteredData;
    this.treeControl.expandAll();
  }
  
  saveChanges(): void {
    if (!this.rbacService.rbacDirty()) return;
    const dialogRef = this.dialog.open<ConfirmationDialogComponent, ConfirmDialogData, boolean>(ConfirmationDialogComponent, {
        data: {
          title: 'Confirm Save',
          message: 'Are you sure you want to save the permission changes for all roles?',
          confirmText: 'Save'
        }
    });
    dialogRef.afterClosed().pipe(filter(r => !!r)).subscribe(() => {
        this.initializePermissionsState();
        this.showSuccessMessage('Permission changes saved successfully.');
    });
  }

  discardChanges(): void {
    if (!this.rbacService.rbacDirty()) return;
     const dialogRef = this.dialog.open<ConfirmationDialogComponent, ConfirmDialogData, boolean>(ConfirmationDialogComponent, {
        data: {
          title: 'Confirm Discard',
          message: 'Are you sure you want to discard your unsaved permission changes?',
          confirmText: 'Discard'
        }
    });
    dialogRef.afterClosed().pipe(filter(r => !!r)).subscribe(() => {
        this.resetState();
        this.showSuccessMessage('Unsaved changes have been discarded.');
    });
  }

  descendantsPartiallySelected(node: MenuItem): boolean {
    const descendants = this.treeControl.getDescendants(node);
    const result = descendants.some(child => this.checklistSelection.isSelected(child));
    return result && !this.checklistSelection.isSelected(node);
  }
  
  itemSelectionToggle(node: MenuItem): void {
    this.checklistSelection.toggle(node);
    const descendants = this.treeControl.getDescendants(node);
    this.checklistSelection.isSelected(node)
      ? this.checklistSelection.select(...descendants)
      : this.checklistSelection.deselect(...descendants);
    
    descendants.forEach(child => this.checklistSelection.isSelected(child));
    this.checkAllParentsSelection(node);
    this.updateServicePermissions();
  }

  checkAllParentsSelection(node: MenuItem): void {
    let parent: MenuItem | null = this.getParentNode(node);
    while (parent) {
      this.checkRootNodeSelection(parent);
      parent = this.getParentNode(parent);
    }
  }

  checkRootNodeSelection(node: MenuItem): void {
    const nodeSelected = this.checklistSelection.isSelected(node);
    const descendants = this.treeControl.getDescendants(node);
    const descTotal = descendants.length;
    const descSelected = descendants.filter(child => this.checklistSelection.isSelected(child)).length;
    if (nodeSelected && descSelected < descTotal) {
      this.checklistSelection.deselect(node);
    } else if (!nodeSelected && descSelected === descTotal && descTotal > 0) {
      this.checklistSelection.select(node);
    }
  }
  
  getParentNode(node: MenuItem): MenuItem | null {
    const findParent = (items: MenuItem[], target: MenuItem): MenuItem | null => {
        for (const item of items) {
            if (item.children?.includes(target)) {
                return item;
            }
            if (item.children) {
                const parent = findParent(item.children, target);
                if (parent) return parent;
            }
        }
        return null;
    };
    return findParent(this.allFeatures, node);
  }

  private updateServicePermissions(): void {
    const role = this.selectedRole();
    const permissions = this.checklistSelection.selected.map(node => node.id);
    this.rbacService.setPermissionsForRole(role, permissions);
    this.rbacService.rbacDirty.set(this.calculateIsDirty());
  }

  private getNodesFromIds(ids: string[]): MenuItem[] {
    const nodes: MenuItem[] = [];
    const findNodes = (items: MenuItem[]) => {
      for (const item of items) {
        if (ids.includes(item.id)) {
          nodes.push(item);
        }
        if (item.children) {
          findNodes(item.children);
        }
      }
    };
    findNodes(this.allFeatures);
    return nodes;
  }
}