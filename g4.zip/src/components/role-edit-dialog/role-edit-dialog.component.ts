import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { RbacService, Role } from '../../app/services/rbac.service';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { UserRole } from '../../app.component';

export interface RoleEditDialogData {
    role: Role | null;
    allRoles: Role[];
}

@Component({
  selector: 'app-role-edit-dialog',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, MatDialogModule, MatFormFieldModule, MatInputModule, MatButtonModule],
  templateUrl: './role-edit-dialog.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class RoleEditDialogComponent {
  private fb = inject(FormBuilder);
  private rbacService = inject(RbacService);
  public dialogRef = inject(MatDialogRef<RoleEditDialogComponent>);
  public data: RoleEditDialogData = inject(MAT_DIALOG_DATA);

  form = this.fb.group({
    name: ['', [Validators.required, this.duplicateNameValidator.bind(this)]],
    description: ['']
  });

  constructor() {
    if(this.data.role) {
        this.form.patchValue(this.data.role);
        if(this.data.role.isCore) {
            this.form.get('name')?.disable();
        }
    }
  }
  
  private duplicateNameValidator(control: any) {
    const name = control.value?.trim().toLowerCase();
    if (!name) return null;
    const isDuplicate = this.data.allRoles.some(r => r.name.toLowerCase() === name && r.id !== this.data.role?.id);
    return isDuplicate ? { duplicateName: true } : null;
  }
  
  private toCamelCase(str: string): string {
    return str.replace(/(?:^\w|[A-Z]|\b\w)/g, (word, index) => index === 0 ? word.toLowerCase() : word.toUpperCase()).replace(/\s+/g, '');
  }

  save(): void {
    if (this.form.invalid) {
      return;
    }

    const formValue = this.form.getRawValue();
    const newName = formValue.name!.trim();
    const newDescription = formValue.description!.trim();
    const existingRole = this.data.role;

    if (existingRole) {
      const newId = existingRole.isCore ? existingRole.id : this.toCamelCase(newName) as UserRole;
      this.rbacService.updateRole(existingRole.id, { id: newId, name: newName, description: newDescription });
    } else {
      const newId = this.toCamelCase(newName) as UserRole;
      this.rbacService.addRole({ id: newId, name: newName, description: newDescription });
    }
    
    this.dialogRef.close(true);
  }

  close(): void {
    this.dialogRef.close();
  }
}
