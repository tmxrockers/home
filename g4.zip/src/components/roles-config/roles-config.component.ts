import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RbacService, Role } from '../../app/services/rbac.service';
import { UserRole } from '../../app.component';
import { ConfirmationDialogComponent, ConfirmDialogData } from '../confirmation-dialog/confirmation-dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { filter } from 'rxjs';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatChipsModule } from '@angular/material/chips';
import { MatTooltipModule } from '@angular/material/tooltip';
import { RoleEditDialogComponent, RoleEditDialogData } from '../role-edit-dialog/role-edit-dialog.component';

@Component({
  selector: 'app-roles-config',
  standalone: true,
  templateUrl: './roles-config.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule, 
    MatTableModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatCardModule,
    MatChipsModule,
    MatTooltipModule
  ],
})
export class RolesConfigComponent {
  rbacService = inject(RbacService);
  dialog = inject(MatDialog);

  roles = signal<Role[]>([]);
  userCounts = signal<Map<UserRole, number>>(new Map());
  
  dataSource = new MatTableDataSource<Role>();
  displayedColumns = ['name', 'description', 'users', 'actions'];
  
  successMessage = signal('');
  private successMessageTimeout: any;

  constructor() {
    this.loadRolesAndCounts();
  }

  private loadRolesAndCounts(): void {
    const allRoles = this.rbacService.getRoles();
    this.roles.set(allRoles);
    this.dataSource.data = allRoles;

    const counts = new Map<UserRole, number>();
    for (const role of allRoles) {
      counts.set(role.id, this.rbacService.getUserCountForRole(role.id));
    }
    this.userCounts.set(counts);
  }
  
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  private showSuccessMessage(message: string): void {
    this.successMessage.set(message);
    clearTimeout(this.successMessageTimeout);
    this.successMessageTimeout = setTimeout(() => this.successMessage.set(''), 3000);
  }

  openRoleDialog(role: Role | null): void {
    const dialogRef = this.dialog.open<RoleEditDialogComponent, RoleEditDialogData, boolean>(RoleEditDialogComponent, {
      width: '500px',
      data: { role, allRoles: this.roles() }
    });

    dialogRef.afterClosed().pipe(filter(result => !!result)).subscribe(() => {
        this.loadRolesAndCounts();
        this.showSuccessMessage(`Role ${role ? 'updated' : 'created'} successfully.`);
    });
  }

  promptDeleteRole(role: Role): void {
    const dialogRef = this.dialog.open<ConfirmationDialogComponent, ConfirmDialogData, boolean>(ConfirmationDialogComponent, {
      data: {
        title: 'Confirm Deletion',
        message: `Are you sure you want to delete the '${role.name}' role? This action cannot be undone.`,
        confirmText: 'Delete'
      }
    });

    dialogRef.afterClosed().pipe(filter(r => !!r)).subscribe(() => {
      this.rbacService.deleteRole(role.id);
      this.loadRolesAndCounts();
      this.showSuccessMessage(`Role '${role.name}' has been deleted.`);
    });
  }
}
