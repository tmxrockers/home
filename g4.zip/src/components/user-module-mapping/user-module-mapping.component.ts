import { ChangeDetectionStrategy, Component, inject, signal, effect, computed, OnDestroy, ViewChild, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RbacService, MenuItem, User } from '../../app/services/rbac.service';
import { UserRole } from '../../app.component';
import { Subscription, filter } from 'rxjs';
import { ConfirmationDialogComponent, ConfirmDialogData } from '../confirmation-dialog/confirmation-dialog.component';
import { AvatarComponent } from '../avatar/avatar.component';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatTreeModule, MatTreeNestedDataSource } from '@angular/material/tree';
import { NestedTreeControl } from '@angular/cdk/tree';
import { MatChipsModule } from '@angular/material/chips';
import { MatListModule } from '@angular/material/list';
import { MatTooltipModule } from '@angular/material/tooltip';
import { FormsModule } from '@angular/forms';

type PermissionSource = 'none' | 'role' | 'grant' | 'revoke';
interface PermissionState {
  hasPermission: boolean;
  source: PermissionSource;
}

@Component({
  selector: 'app-user-module-mapping',
  standalone: true,
  templateUrl: './user-module-mapping.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule, 
    FormsModule,
    AvatarComponent,
    MatPaginatorModule,
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatCardModule,
    MatTreeModule,
    MatChipsModule,
    MatListModule,
    MatTooltipModule
  ],
})
export class UserModuleMappingComponent implements OnDestroy, AfterViewInit {
  rbacService = inject(RbacService);
  dialog = inject(MatDialog);
  private subscriptions = new Subscription();

  allUsers = signal<User[]>([]);
  allFeatures = signal<MenuItem[]>([]);
  allAppRoles = signal<UserRole[]>([]);
  
  selectedUser = signal<User | null>(null);
  userSearchTerm = signal('');
  featureSearchTerm = signal('');

  selectedRoleFilters = signal<UserRole[]>([]);
  sortDirection = signal<'asc' | 'desc'>('asc');
  
  @ViewChild(MatPaginator) paginator!: MatPaginator;

  treeControl = new NestedTreeControl<MenuItem>(node => node.children);
  dataSource = new MatTreeNestedDataSource<MenuItem>();

  private initialOverrides: { granted: Set<string>, revoked: Set<string> } = { granted: new Set(), revoked: new Set() };
  pendingOverrides = signal<{ granted: Set<string>, revoked: Set<string> }>({ granted: new Set(), revoked: new Set() });
  private rolePermissions = signal<Set<string>>(new Set());

  successMessage = signal('');
  private successMessageTimeout: any;

  filteredAndSortedUsers = computed(() => {
    const term = this.userSearchTerm().toLowerCase();
    const roleFilters = this.selectedRoleFilters();
    const direction = this.sortDirection();
    
    let users = this.allUsers();

    if (roleFilters.length > 0) {
      const roleFilterSet = new Set(roleFilters);
      users = users.filter(u => roleFilterSet.has(u.role));
    }

    if (term) {
      users = users.filter(u => u.name.toLowerCase().includes(term) || u.email.toLowerCase().includes(term));
    }
    
    return [...users].sort((a, b) => {
      const comparison = a.name.localeCompare(b.name);
      return direction === 'asc' ? comparison : -comparison;
    });
  });

  paginatedUsers = signal<User[]>([]);

  hasOverrides = computed(() => {
    const { granted, revoked } = this.pendingOverrides();
    return granted.size > 0 || revoked.size > 0;
  });
  
  hasChild = (_: number, node: MenuItem) => !!node.children && node.children.length > 0;

  constructor() {
    const users = this.rbacService.getUsers();
    this.allUsers.set(users);
    this.allFeatures.set(this.rbacService.getActiveFeatures());
    this.dataSource.data = this.allFeatures();
    this.allAppRoles.set(this.rbacService.getRoles().map(role => role.id));

    if (users.length > 0) {
      this.performUserSwitch(users[0]);
    }
    
    effect(() => {
      this.updatePaginatedUsers();
    });

    effect(() => {
      this.filterTree(this.featureSearchTerm());
    });
    
    effect(() => {
      const initial = this.initialOverrides;
      const pending = this.pendingOverrides();
      const isDirty = initial.granted.size !== pending.granted.size || initial.revoked.size !== pending.revoked.size ||
                      ![...pending.granted].every(p => initial.granted.has(p)) ||
                      ![...pending.revoked].every(p => initial.revoked.has(p));
      this.rbacService.userModuleMappingDirty.set(isDirty);
    });

    this.subscriptions.add(
      this.rbacService.discardUserModuleMappingChanges$.subscribe(() => this.resetState())
    );
  }

  ngAfterViewInit() {
    this.updatePaginatedUsers();
    this.paginator.page.subscribe(() => this.updatePaginatedUsers());
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }
  
  private updatePaginatedUsers(): void {
    if (!this.paginator) return;
    const users = this.filteredAndSortedUsers();
    const startIndex = this.paginator.pageIndex * this.paginator.pageSize;
    const endIndex = startIndex + this.paginator.pageSize;
    this.paginatedUsers.set(users.slice(startIndex, endIndex));
  }

  private showSuccessMessage(message: string): void {
    this.successMessage.set(message);
    clearTimeout(this.successMessageTimeout);
    this.successMessageTimeout = setTimeout(() => this.successMessage.set(''), 3000);
  }
  
  onUserSearch(event: Event): void {
    const term = (event.target as HTMLInputElement).value;
    this.userSearchTerm.set(term);
    this.paginator?.firstPage();
  }
  
  onFeatureSearch(event: Event): void {
    const term = (event.target as HTMLInputElement).value;
    this.featureSearchTerm.set(term);
  }

  onRoleFilterChange(): void {
    this.paginator?.firstPage();
  }
  
  getFormattedRole(roleId: UserRole): string {
    return roleId.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
  }

  selectUser(user: User): void {
    if (this.selectedUser()?.id === user.id) return;

    if (this.rbacService.userModuleMappingDirty()) {
      const dialogRef = this.dialog.open<ConfirmationDialogComponent, ConfirmDialogData, boolean>(ConfirmationDialogComponent, {
        data: {
          title: 'Unsaved Changes',
          message: 'You have unsaved permission overrides. Do you want to discard them and switch users?',
          confirmText: 'Discard and Switch'
        }
      });

      dialogRef.afterClosed().pipe(filter(result => !!result)).subscribe(() => {
        this.performUserSwitch(user);
      });
    } else {
      this.performUserSwitch(user);
    }
  }

  private performUserSwitch(user: User): void {
    this.selectedUser.set(user);
    const userOverrides = this.rbacService.getUserPermissionOverrides(user.id);
    this.initialOverrides = {
      granted: new Set(userOverrides.granted),
      revoked: new Set(userOverrides.revoked)
    };
    this.pendingOverrides.set({
      granted: new Set(userOverrides.granted),
      revoked: new Set(userOverrides.revoked)
    });
    this.rolePermissions.set(new Set(this.rbacService.getRolePermissions(user.role)));
    this.featureSearchTerm.set('');
  }
  
  private resetState(): void {
    const user = this.selectedUser();
    if (user) {
      this.performUserSwitch(user);
    }
  }

  filterTree(filterText: string): void {
    const term = filterText.toLowerCase().trim();
    if (!term) {
      this.dataSource.data = this.allFeatures();
      this.treeControl.collapseAll();
      return;
    }

    const filterNode = (node: MenuItem): MenuItem | null => {
      const selfMatch = node.label.toLowerCase().includes(term);
      if (node.children) {
        const matchingChildren = node.children.map(filterNode).filter((n): n is MenuItem => n !== null);
        if (matchingChildren.length > 0 || selfMatch) {
          return { ...node, children: matchingChildren.length > 0 ? matchingChildren : undefined };
        }
      }
      return selfMatch ? { ...node, children: undefined } : null;
    };
    
    this.dataSource.data = this.allFeatures().map(filterNode).filter((n): n is MenuItem => n !== null);
    this.treeControl.expandAll();
  }
  
  getPermissionState(featureId: string): PermissionState {
    const overrides = this.pendingOverrides();
    if (overrides.granted.has(featureId)) {
      return { hasPermission: true, source: 'grant' };
    }
    if (overrides.revoked.has(featureId)) {
      return { hasPermission: false, source: 'revoke' };
    }
    if (this.rolePermissions().has(featureId)) {
      return { hasPermission: true, source: 'role' };
    }
    return { hasPermission: false, source: 'none' };
  }

  isIndeterminate(node: MenuItem): boolean {
    const descendants = this.treeControl.getDescendants(node);
    if (!descendants.length) return false;

    const state = this.getPermissionState(node.id);
    const descendantStates = descendants.map(d => this.getPermissionState(d.id));

    return descendantStates.some(s => s.hasPermission !== state.hasPermission);
  }

  togglePermission(node: MenuItem): void {
    const state = this.getPermissionState(node.id);
    const isChecked = !state.hasPermission;

    this.pendingOverrides.update(overrides => {
      const newGranted = new Set(overrides.granted);
      const newRevoked = new Set(overrides.revoked);

      const processNode = (n: MenuItem) => {
        const isRolePermission = this.rolePermissions().has(n.id);
        
        if (isChecked) { // Granting permission
          newRevoked.delete(n.id);
          if (!isRolePermission) {
            newGranted.add(n.id);
          }
        } else { // Revoking permission
          newGranted.delete(n.id);
          if (isRolePermission) {
            newRevoked.add(n.id);
          }
        }
      };

      processNode(node);
      this.treeControl.getDescendants(node).forEach(processNode);
      return { granted: newGranted, revoked: newRevoked };
    });
  }

  promptResetAllOverrides(): void {
    const dialogRef = this.dialog.open<ConfirmationDialogComponent, ConfirmDialogData, boolean>(ConfirmationDialogComponent, {
      data: {
        title: 'Reset Overrides',
        message: 'Are you sure you want to remove all custom permission overrides for this user?',
        confirmText: 'Reset'
      }
    });

    dialogRef.afterClosed().pipe(filter(result => !!result)).subscribe(() => {
      this.pendingOverrides.set({ granted: new Set(), revoked: new Set() });
    });
  }
  
  saveChanges(): void {
    const user = this.selectedUser();
    if (!user || !this.rbacService.userModuleMappingDirty()) return;

    const dialogRef = this.dialog.open<ConfirmationDialogComponent, ConfirmDialogData, boolean>(ConfirmationDialogComponent, {
        data: {
          title: 'Confirm Save',
          message: `Are you sure you want to save the permission overrides for ${user.name}?`,
          confirmText: 'Save'
        }
    });

    dialogRef.afterClosed().pipe(filter(r => !!r)).subscribe(() => {
        const overrides = this.pendingOverrides();
        this.rbacService.setUserPermissionOverrides(user.id, {
          granted: Array.from(overrides.granted),
          revoked: Array.from(overrides.revoked)
        });
        this.performUserSwitch(user); // This resets dirty state
        this.showSuccessMessage('Permission overrides saved successfully.');
    });
  }

  discardChanges(): void {
    if (!this.rbacService.userModuleMappingDirty()) return;
    const dialogRef = this.dialog.open<ConfirmationDialogComponent, ConfirmDialogData, boolean>(ConfirmationDialogComponent, {
        data: {
          title: 'Confirm Discard',
          message: 'Are you sure you want to discard your unsaved permission overrides?',
          confirmText: 'Discard'
        }
    });

    dialogRef.afterClosed().pipe(filter(r => !!r)).subscribe(() => {
        this.resetState();
        this.showSuccessMessage('Unsaved changes have been discarded.');
    });
  }
}
