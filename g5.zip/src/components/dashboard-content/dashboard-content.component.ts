import { ChangeDetectionStrategy, Component, signal, Output, EventEmitter, input, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserRole } from '../../app.component';
import { RbacConfigComponent } from '../rbac-config/rbac-config.component';
import { FeatureConfigComponent } from '../feature-config/feature-config.component';
import { RbacService, User } from '../../app/services/rbac.service';
import { ConfirmationDialogComponent } from '../confirmation-dialog/confirmation-dialog.component';
import { UserModuleMappingComponent } from '../user-module-mapping/user-module-mapping.component';

interface Requisition {
  wmpId: string;
  cio: string;
  jobTitle: string;
  location: string;
  priority: 'High' | 'Medium' | 'Critical' | 'Low';
  status: 'Open' | 'In Progress' | 'On Hold';
}


@Component({
  selector: 'app-dashboard-content',
  templateUrl: './dashboard-content.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, RbacConfigComponent, FeatureConfigComponent, ConfirmationDialogComponent, UserModuleMappingComponent],
})
export class DashboardContentComponent {
  @Output() userChanged = new EventEmitter<string>();
  currentUser = input.required<User>();

  rbacService = inject(RbacService);

  activeTab = signal<'rbac' | 'feature' | 'user-module-mapping'>('rbac');
  
  // For tab switching confirmation
  isSwitchTabConfirmOpen = signal(false);
  private targetTab = signal<'rbac' | 'feature' | 'user-module-mapping'>('rbac');

  // State for main save/discard actions
  isSaveConfirmOpen = signal(false);
  isDiscardConfirmOpen = signal(false);

  // Computed signal for dirty state of the current tab
  isCurrentTabDirty = computed(() => {
    switch (this.activeTab()) {
      case 'rbac': return this.rbacService.rbacDirty();
      case 'feature': return this.rbacService.featureDirty();
      case 'user-module-mapping': return this.rbacService.userModuleMappingDirty();
      default: return false;
    }
  });

  displayedColumns = ['WMP Id', 'CIO', 'Job Title', 'Location', 'Priority', 'Status', 'Actions'];
  
  requisitions = signal<Requisition[]>([
    { wmpId: 'WMP001234', cio: 'Technology', jobTitle: 'Application Programmer II', location: 'Charlotte, NC', priority: 'High', status: 'Open' },
    { wmpId: 'WMP001235', cio: 'Banking', jobTitle: 'Data Analyst', location: 'New York, NY', priority: 'Medium', status: 'Open' },
    { wmpId: 'WMP001236', cio: 'Technology', jobTitle: 'DevOps Engineer', location: 'San Francisco, CA', priority: 'Critical', status: 'In Progress' },
    { wmpId: 'WMP001237', cio: 'Finance', jobTitle: 'Financial Analyst', location: 'Chicago, IL', priority: 'High', status: 'Open' },
    { wmpId: 'WMP001238', cio: 'Technology', jobTitle: 'UI/UX Designer', location: 'Remote', priority: 'Medium', status: 'Open' },
    { wmpId: 'WMP001239', cio: 'Operations', jobTitle: 'Project Manager', location: 'Boston, MA', priority: 'High', status: 'In Progress' },
    { wmpId: 'WMP001240', cio: 'Technology', jobTitle: 'Business Analyst', location: 'Atlanta, GA', priority: 'Low', status: 'On Hold' },
    { wmpId: 'WMP001241', cio: 'Quality Assurance', jobTitle: 'QA Engineer', location: 'Dallas, TX', priority: 'Medium', status: 'Open' },
  ]);

  getPriorityClass(priority: 'High' | 'Medium' | 'Critical' | 'Low'): string {
    switch (priority) {
      case 'Critical':
        return 'bg-red-600 text-white';
      case 'High':
        return 'bg-orange-200 text-orange-800';
      case 'Medium':
        return 'bg-gray-200 text-gray-800';
      case 'Low':
        return 'bg-blue-200 text-blue-900';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  }

  getStatusClass(status: 'Open' | 'In Progress' | 'On Hold'): string {
    switch (status) {
      case 'Open':
        return 'bg-sky-200 text-sky-800';
      case 'In Progress':
        return 'bg-amber-200 text-amber-800';
      case 'On Hold':
        return 'bg-red-200 text-red-700';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  }

  selectTab(newTab: 'rbac' | 'feature' | 'user-module-mapping'): void {
    const currentTab = this.activeTab();
    if (newTab === currentTab) {
      return;
    }

    let isCurrentTabDirty = false;
    switch(currentTab) {
        case 'rbac': isCurrentTabDirty = this.rbacService.rbacDirty(); break;
        case 'feature': isCurrentTabDirty = this.rbacService.featureDirty(); break;
        case 'user-module-mapping': isCurrentTabDirty = this.rbacService.userModuleMappingDirty(); break;
    }

    if (isCurrentTabDirty) {
      this.targetTab.set(newTab);
      this.isSwitchTabConfirmOpen.set(true);
    } else {
      this.activeTab.set(newTab);
    }
  }

  confirmSwitchTab(): void {
    const currentTab = this.activeTab();
    switch(currentTab) {
        case 'rbac': this.rbacService.discardRbacChanges$.next(); break;
        case 'feature': this.rbacService.discardFeatureChanges$.next(); break;
        case 'user-module-mapping': this.rbacService.discardUserModuleMappingChanges$.next(); break;
    }
    this.activeTab.set(this.targetTab());
    this.isSwitchTabConfirmOpen.set(false);
  }

  cancelSwitchTab(): void {
    this.isSwitchTabConfirmOpen.set(false);
  }
  
  // Methods for the new footer
  saveChanges(): void {
    if (!this.isCurrentTabDirty()) return;
    this.isSaveConfirmOpen.set(true);
  }

  discardChanges(): void {
    if (!this.isCurrentTabDirty()) return;
    this.isDiscardConfirmOpen.set(true);
  }

  confirmSave(): void {
    switch(this.activeTab()) {
      case 'rbac': this.rbacService.saveRbacChanges$.next(); break;
      case 'feature': this.rbacService.saveFeatureChanges$.next(); break;
      case 'user-module-mapping': this.rbacService.saveUserModuleMappingChanges$.next(); break;
    }
    this.isSaveConfirmOpen.set(false);
  }

  cancelSave(): void {
    this.isSaveConfirmOpen.set(false);
  }

  confirmDiscard(): void {
    switch(this.activeTab()) {
      case 'rbac': this.rbacService.discardRbacChanges$.next(); break;
      case 'feature': this.rbacService.discardFeatureChanges$.next(); break;
      case 'user-module-mapping': this.rbacService.discardUserModuleMappingChanges$.next(); break;
    }
    this.isDiscardConfirmOpen.set(false);
  }

  cancelDiscard(): void {
    this.isDiscardConfirmOpen.set(false);
  }
}