import { ChangeDetectionStrategy, Component, inject, signal, effect, computed, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RbacService, MenuItem } from '../../app/services/rbac.service';
import { UserRole } from '../../app.component';
import { Subscription } from 'rxjs';
import { ConfirmationDialogComponent } from '../confirmation-dialog/confirmation-dialog.component';

@Component({
  selector: 'app-rbac-config',
  templateUrl: './rbac-config.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, ConfirmationDialogComponent],
})
export class RbacConfigComponent implements OnDestroy {
  rbacService = inject(RbacService);
  private subscriptions = new Subscription();

  roles: UserRole[] = ['admin', 'dataLoader', 'staffingOps'];
  selectedRole = signal<UserRole>('admin');
  
  allFeatures = signal<MenuItem[]>([]);
  searchTerm = signal<string>('');
  expandedFeatures = signal<Set<string>>(new Set<string>());

  // State for multi-role pending changes
  private initialPermissions = new Map<UserRole, Set<string>>();
  pendingPermissionsByRole = signal<Map<UserRole, Set<string>>>(new Map<UserRole, Set<string>>());

  successMessage = signal('');
  private successMessageTimeout: any;

  // Computed signal for the currently selected role's permissions
  currentPendingPermissions = computed(() => {
    return this.pendingPermissionsByRole().get(this.selectedRole()) ?? new Set<string>();
  });
  
  filteredFeatures = computed(() => {
    const term = this.searchTerm().toLowerCase().trim();
    if (!term) {
      return this.allFeatures();
    }

    const results: MenuItem[] = [];
    for (const feature of this.allFeatures()) {
      const matchingChildren = feature.children?.filter(child => 
        child.label.toLowerCase().includes(term)
      ) ?? [];

      if (feature.label.toLowerCase().includes(term) || matchingChildren.length > 0) {
        const newFeature = { ...feature };
        if (feature.label.toLowerCase().includes(term)) {
          newFeature.children = feature.children;
        } else {
          newFeature.children = matchingChildren;
        }
        results.push(newFeature);
      }
    }
    return results;
  });

  constructor() {
    this.allFeatures.set(this.rbacService.getActiveFeatures());
    this.initializePermissionsState();
    
    // Effect to calculate and set the global dirty state
    effect(() => {
      const isDirty = this.calculateIsDirty();
      this.rbacService.rbacDirty.set(isDirty);
    });

    this.subscriptions.add(
      this.rbacService.discardRbacChanges$.subscribe(() => {
        this.onConfirmDiscard();
      })
    );
    
    this.subscriptions.add(
      this.rbacService.saveRbacChanges$.subscribe(() => {
        this.onConfirmSave();
      })
    );
  }
  
  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  private showSuccessMessage(message: string): void {
    this.successMessage.set(message);
    clearTimeout(this.successMessageTimeout);
    this.successMessageTimeout = setTimeout(() => this.successMessage.set(''), 3000);
  }

  private initializePermissionsState(): void {
    const pendingMap = new Map<UserRole, Set<string>>();
    this.initialPermissions.clear();
    for (const role of this.roles) {
        const permissions = new Set<string>(this.rbacService.getRolePermissions(role));
        this.initialPermissions.set(role, new Set<string>(permissions)); // Store pristine state
        pendingMap.set(role, permissions); // Set initial pending state
    }
    this.pendingPermissionsByRole.set(pendingMap);
  }

  private resetState(): void {
    this.initializePermissionsState();
  }

  private calculateIsDirty(): boolean {
    const pendingMap = this.pendingPermissionsByRole();
    for (const role of this.roles) {
      const initialSet = this.initialPermissions.get(role);
      const pendingSet = pendingMap.get(role);

      if (!initialSet || !pendingSet) continue;
      if (initialSet.size !== pendingSet.size) return true;
      for (const perm of pendingSet) {
        if (!initialSet.has(perm)) return true;
      }
    }
    return false;
  }

  onSearchTermChange(event: Event): void {
    this.searchTerm.set((event.target as HTMLInputElement).value);
  }

  toggleFeature(featureId: string): void {
    this.expandedFeatures.update((current: Set<string>) => {
      const newSet = new Set<string>(current);
      if (newSet.has(featureId)) {
        newSet.delete(featureId);
      } else {
        newSet.add(featureId);
      }
      return newSet;
    });
  }

  isExpanded(featureId: string): boolean {
    return this.expandedFeatures().has(featureId);
  }

  expandAll(): void {
    const allParentIds = this.filteredFeatures()
      .filter(f => f.children && f.children.length > 0)
      .map(f => f.id);
    this.expandedFeatures.set(new Set<string>(allParentIds));
  }

  collapseAll(): void {
    this.expandedFeatures.set(new Set<string>());
  }

  onConfirmSave(): void {
    const pendingMap = this.pendingPermissionsByRole();
    for (const [role, permissions] of pendingMap.entries()) {
      this.rbacService.setPermissionsForRole(role, Array.from(permissions));
    }
    this.resetState(); // Reset state after saving
    this.showSuccessMessage('Permission changes saved successfully.');
  }

  onConfirmDiscard(): void {
    this.resetState(); // Revert to initial state
    this.showSuccessMessage('Unsaved changes have been discarded.');
  }

  onPermissionChange(featureId: string, event: Event): void {
    const isChecked = (event.target as HTMLInputElement).checked;
    const role = this.selectedRole();

    this.pendingPermissionsByRole.update(currentMap => {
        const newMap = new Map<UserRole, Set<string>>(currentMap);
        const perms = new Set<string>(newMap.get(role) || []);
        
        // Update permissions for the feature and its descendants
        this.updatePermissionsRecursively(featureId, isChecked, perms);

        // Sync parent states upwards from the changed feature
        this.syncParentsState(featureId, perms);

        newMap.set(role, perms);
        return newMap;
    });
  }
  
  private updatePermissionsRecursively(featureId: string, isSelected: boolean, perms: Set<string>): void {
    const feature = this.findFeatureById(featureId, this.allFeatures());
    if (!feature) return;

    if (isSelected) {
        perms.add(feature.id);
    } else {
        perms.delete(feature.id);
    }

    if (feature.children) {
        for (const child of feature.children) {
            this.updatePermissionsRecursively(child.id, isSelected, perms);
        }
    }
  }

  private syncParentsState(featureId: string, perms: Set<string>): void {
    let parent = this.findParent(featureId, this.allFeatures());
    while (parent) {
      const allChildrenSelected = parent.children?.every(child => perms.has(child.id)) ?? false;
      
      if (allChildrenSelected) {
        perms.add(parent.id);
      } else {
        perms.delete(parent.id);
      }
      parent = this.findParent(parent.id, this.allFeatures());
    }
  }

  private findFeatureById(id: string, features: MenuItem[]): MenuItem | null {
    for (const feature of features) {
      if (feature.id === id) return feature;
      if (feature.children) {
        const found = this.findFeatureById(id, feature.children);
        if (found) return found;
      }
    }
    return null;
  }

  private findParent(childId: string, features: MenuItem[]): MenuItem | null {
    for (const feature of features) {
      if (feature.children?.some(child => child.id === childId)) {
        return feature;
      }
      if (feature.children) {
        const parent = this.findParent(childId, feature.children);
        if (parent) return parent;
      }
    }
    return null;
  }

  private getAllDescendantIds(items: MenuItem[]): string[] {
    return items.flatMap(item => [item.id, ...(item.children ? this.getAllDescendantIds(item.children) : [])]);
  }

  isIndeterminate(feature: MenuItem): boolean {
    if (!feature.children || feature.children.length === 0) {
      return false;
    }

    const perms = this.currentPendingPermissions();
    // A parent's checkbox can't be indeterminate if it's already checked (which implies all children are checked).
    if (perms.has(feature.id)) {
      return false;
    }

    // It is indeterminate if it's not checked, but at least one of its descendants is.
    const descendantIds = this.getAllDescendantIds(feature.children);
    return descendantIds.some(id => perms.has(id));
  }
}