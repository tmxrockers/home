import { ChangeDetectionStrategy, Component, computed, effect, inject, OnDestroy, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RbacService, MenuItem } from '../../app/services/rbac.service';
import { Subscription } from 'rxjs';
import { ConfirmationDialogComponent } from '../confirmation-dialog/confirmation-dialog.component';

@Component({
  selector: 'app-feature-config',
  templateUrl: './feature-config.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, ConfirmationDialogComponent],
})
export class FeatureConfigComponent implements OnDestroy {
  private rbacService = inject(RbacService);
  private subscriptions = new Subscription();

  allFeatures = signal<MenuItem[]>([]);
  searchTerm = signal<string>('');
  
  private initialFeatures: MenuItem[] = [];
  private allFeaturesFlat = new Map<string, { item: MenuItem, parentId: string | null }>();

  // D&D State
  draggedItemInfo = signal<{ id: string, parentId: string | null } | null>(null);
  dragOverItemId = signal<string | null>(null);
  draggedItemId = computed(() => this.draggedItemInfo()?.id ?? null);

  // Local state for confirmation dialogs
  isConfirmSaveOpen = signal(false);
  isConfirmDiscardOpen = signal(false);
  isConfirmDeleteOpen = signal(false);
  itemToDelete = signal<{ id: string } | null>(null);

  successMessage = signal('');
  private successMessageTimeout: any;

  // For card accordion
  expandedFeatures = signal<Set<string>>(new Set());

  isDirty = computed(() => {
    return JSON.stringify(this.initialFeatures) !== JSON.stringify(this.allFeatures());
  });

  filteredFeatures = computed(() => {
    const term = this.searchTerm().toLowerCase().trim();
    if (!term) {
      return this.allFeatures();
    }

    const results: MenuItem[] = [];
    for (const feature of this.allFeatures()) {
      const matchingChildren = feature.children?.filter(child => 
        child.label.toLowerCase().includes(term) || child.description?.toLowerCase().includes(term)
      ) ?? [];

      const featureMatch = feature.label.toLowerCase().includes(term) || feature.description?.toLowerCase().includes(term);

      if (featureMatch || matchingChildren.length > 0) {
        const newFeature = { ...feature };
        if (featureMatch) {
          newFeature.children = feature.children;
        } else {
          newFeature.children = matchingChildren;
        }
        results.push(newFeature);
      }
    }
    return results;
  });

  constructor() {
    this.loadInitialState();
    
    effect(() => {
      this.rbacService.featureDirty.set(this.isDirty());
    });

    this.subscriptions.add(
      this.rbacService.discardFeatureChanges$.subscribe(() => {
        this.resetState();
      })
    );
  }
  
  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  private showSuccessMessage(message: string): void {
    this.successMessage.set(message);
    clearTimeout(this.successMessageTimeout);
    this.successMessageTimeout = setTimeout(() => this.successMessage.set(''), 3000);
  }

  private loadInitialState(): void {
    const features = this.rbacService.getRawFeatures();
    // Deep copy for pristine state
    this.initialFeatures = JSON.parse(JSON.stringify(features));
    this.allFeatures.set(JSON.parse(JSON.stringify(features)));
    this.rebuildFlatMap();
  }

  private rebuildFlatMap(): void {
    this.allFeaturesFlat.clear();
    const processFeatures = (items: MenuItem[], parentId: string | null = null) => {
      for (const item of items) {
        this.allFeaturesFlat.set(item.id, { item, parentId });
        if (item.children) {
          processFeatures(item.children, item.id);
        }
      }
    };
    processFeatures(this.allFeatures());
  }

  private resetState(): void {
    this.allFeatures.set(JSON.parse(JSON.stringify(this.initialFeatures)));
    this.rebuildFlatMap();
  }
  
  private findFeatureById(id: string, features: MenuItem[]): MenuItem | undefined {
    for (const feature of features) {
        if (feature.id === id) return feature;
        if (feature.children) {
            const found = this.findFeatureById(id, feature.children);
            if (found) return found;
        }
    }
    return undefined;
  }

  onSearchTermChange(event: Event): void {
    this.searchTerm.set((event.target as HTMLInputElement).value);
  }

  onStatusChange(featureId: string, event: Event): void {
    const isActive = (event.target as HTMLInputElement).checked;

    const updateStatusesRecursively = (items: MenuItem[], targetId: string, newStatus: boolean): MenuItem[] => {
      return items.map(item => {
        let newItem = { ...item };
        if (newItem.id === targetId) {
          newItem.isActive = newStatus;
          // If a parent is deactivated, deactivate all children recursively
          if (!newStatus && newItem.children) {
            const deactivateChildren = (children: MenuItem[]): MenuItem[] => {
              return children.map(child => ({
                ...child,
                isActive: false,
                children: child.children ? deactivateChildren(child.children) : child.children,
              }));
            };
            newItem.children = deactivateChildren(newItem.children);
          }
        } else if (item.children) {
          // Recurse on children if this isn't the target item
          newItem.children = updateStatusesRecursively(item.children, targetId, newStatus);
        }
        return newItem;
      });
    };

    this.allFeatures.update(features => {
      let updatedFeatures = updateStatusesRecursively(features, featureId, isActive);

      // If activating a child, ensure all its parents are also activated
      if (isActive) {
        const activateParents = (childId: string, currentFeatures: MenuItem[]) => {
          let parentId = this.allFeaturesFlat.get(childId)?.parentId;
          while (parentId) {
            const parentToActivate = this.findFeatureById(parentId, currentFeatures);
            if (parentToActivate) {
              parentToActivate.isActive = true;
            }
            parentId = this.allFeaturesFlat.get(parentId)?.parentId;
          }
        };
        activateParents(featureId, updatedFeatures);
      }
      
      return updatedFeatures;
    });
  }

  // --- D&D Handlers ---
  onDragStart(event: DragEvent, id: string, parentId: string | null): void {
    event.dataTransfer!.effectAllowed = 'move';
    this.draggedItemInfo.set({ id, parentId });
  }

  onDragOver(event: DragEvent, targetId: string, targetParentId: string | null): void {
    event.preventDefault();
    const dragged = this.draggedItemInfo();
    if (dragged && dragged.parentId === targetParentId && dragged.id !== targetId) {
      this.dragOverItemId.set(targetId);
      event.dataTransfer!.dropEffect = 'move';
    } else {
      this.dragOverItemId.set(null);
      event.dataTransfer!.dropEffect = 'none';
    }
  }
  
  onDragLeave(): void {
    this.dragOverItemId.set(null);
  }

  onDrop(event: DragEvent, targetId: string, targetParentId: string | null): void {
    event.preventDefault();
    const dragged = this.draggedItemInfo();
    
    if (!dragged || dragged.parentId !== targetParentId || dragged.id === targetId) {
      this.cleanupDragState();
      return;
    }

    this.allFeatures.update(currentFeatures => {
      const featuresCopy = JSON.parse(JSON.stringify(currentFeatures));
      
      let list: MenuItem[];
      if (targetParentId === null) {
        list = featuresCopy;
      } else {
        const parent = this.findFeatureById(targetParentId, featuresCopy);
        if (!parent || !parent.children) return currentFeatures;
        list = parent.children;
      }

      const draggedIndex = list.findIndex(item => item.id === dragged.id);
      if (draggedIndex === -1) return currentFeatures;

      const [draggedItem] = list.splice(draggedIndex, 1);
      
      if (targetId.startsWith('end-of-list')) {
        list.push(draggedItem);
      } else {
        const targetIndex = list.findIndex(item => item.id === targetId);
        list.splice(targetIndex, 0, draggedItem);
      }
      
      return featuresCopy;
    });

    this.cleanupDragState();
  }

  onDragEnd(): void {
    this.cleanupDragState();
  }

  private cleanupDragState(): void {
    this.draggedItemInfo.set(null);
    this.dragOverItemId.set(null);
  }
  
  // --- Delete Handlers ---
  promptDeleteMenuItem(id: string): void {
    this.itemToDelete.set({ id });
    this.isConfirmDeleteOpen.set(true);
  }

  onConfirmDelete(): void {
    const idToDelete = this.itemToDelete()?.id;
    if (!idToDelete) return;
    
    const removeItemRecursively = (items: MenuItem[], id: string): MenuItem[] => {
      const filtered = items.filter(item => item.id !== id);
      return filtered.map(item => {
        if (item.children) {
          return { ...item, children: removeItemRecursively(item.children, id) };
        }
        return item;
      });
    };
    
    this.allFeatures.update(features => removeItemRecursively(features, idToDelete));
    this.rebuildFlatMap();
    this.onCancelDelete();
  }

  onCancelDelete(): void {
    this.isConfirmDeleteOpen.set(false);
    this.itemToDelete.set(null);
  }

  // --- Local Save/Discard with Confirmation ---
  saveChanges(): void {
    if (!this.isDirty()) return;
    this.isConfirmSaveOpen.set(true);
  }

  discardChanges(): void {
    if (!this.isDirty()) return;
    this.isConfirmDiscardOpen.set(true);
  }

  onConfirmSave(): void {
    this.rbacService.updateFeatures(this.allFeatures());
    this.loadInitialState(); // Reloads and resets dirty state
    this.isConfirmSaveOpen.set(false);
    this.showSuccessMessage('Menu structure changes saved successfully.');
  }

  onCancelSave(): void {
    this.isConfirmSaveOpen.set(false);
  }

  onConfirmDiscard(): void {
    this.resetState();
    this.isConfirmDiscardOpen.set(false);
    this.showSuccessMessage('Unsaved changes to the menu structure have been discarded.');
  }

  onCancelDiscard(): void {
    this.isConfirmDiscardOpen.set(false);
  }

  toggleFeature(featureId: string): void {
    this.expandedFeatures.update(current => {
      const newSet = new Set(current);
      if (newSet.has(featureId)) {
        newSet.delete(featureId);
      } else {
        newSet.add(featureId);
      }
      return newSet;
    });
  }

  isExpanded(featureId: string): boolean {
    return this.expandedFeatures().has(featureId);
  }
}