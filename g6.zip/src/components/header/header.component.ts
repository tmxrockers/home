import { ChangeDetectionStrategy, Component, output, signal, input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AvatarComponent } from '../avatar/avatar.component';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, AvatarComponent],
  host: {
    '(document:click)': 'onDocumentClick()',
  }
})
export class HeaderComponent {
  isSidebarOpen = input(false);
  toggleSidebar = output<void>();
  isProfileDropdownOpen = signal(false);
  appVersion = 'v1.2.3';

  toggleProfileDropdown(event: MouseEvent): void {
    event.stopPropagation();
    this.isProfileDropdownOpen.update(v => !v);
  }

  onDocumentClick(): void {
    if (this.isProfileDropdownOpen()) {
      this.isProfileDropdownOpen.set(false);
    }
  }
}
