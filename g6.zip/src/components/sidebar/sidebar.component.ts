import { ChangeDetectionStrategy, Component, computed, inject, input, output, signal } from '@angular/core';
import { CommonModule, NgOptimizedImage } from '@angular/common';
import { RbacService, User, MenuItem } from '../../app/services/rbac.service';
import { AvatarComponent } from '../avatar/avatar.component';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, NgOptimizedImage, AvatarComponent],
})
export class SidebarComponent {
  isOpen = input<boolean>(true);
  user = input.required<User>();
  activeItem = input<string>('dashboard');
  closeSidebar = output<void>();
  itemSelected = output<string>();

  openSubMenus = signal<Set<string>>(new Set(['service-desk']));
  menuSearchTerm = signal('');

  private rbacService = inject(RbacService);
  
  menuItems = computed(() => {
    const allItems = this.rbacService.getFeaturesForUser(this.user());
    const term = this.menuSearchTerm().toLowerCase().trim();

    if (!term) {
      return allItems;
    }

    const filtered: MenuItem[] = [];

    for (const item of allItems) {
      // Create a deep copy to safely modify children array for filtering
      const itemCopy = JSON.parse(JSON.stringify(item));

      const matchingChildren = itemCopy.children?.filter((child: MenuItem) => 
        child.label.toLowerCase().includes(term)
      );

      const parentMatches = itemCopy.label.toLowerCase().includes(term);

      if (parentMatches || (matchingChildren && matchingChildren.length > 0)) {
        if (!parentMatches) {
            // If only children matched, replace the children array with only the matching ones
            itemCopy.children = matchingChildren;
        }
        filtered.push(itemCopy);
      }
    }
    return filtered;
  });

  onMenuSearch(event: Event): void {
    const term = (event.target as HTMLInputElement).value.toLowerCase().trim();
    this.menuSearchTerm.set(term);

    if (!term) {
        return; // Exit if search is cleared
    }
    
    // Auto-expand parents of matching sub-menu items
    const allItems = this.rbacService.getFeaturesForUser(this.user());
    const parentsToExpand = new Set<string>();
    for (const item of allItems) {
        if (item.children?.some(child => child.label.toLowerCase().includes(term))) {
            parentsToExpand.add(item.id);
        }
    }

    if (parentsToExpand.size > 0) {
        this.openSubMenus.update(current => {
            const newSet = new Set(current);
            parentsToExpand.forEach(id => newSet.add(id));
            return newSet;
        });
    }
  }

  selectItem(id: string): void {
    this.itemSelected.emit(id);
  }

  toggleSubMenu(itemId: string): void {
    this.openSubMenus.update(currentSet => {
        const newSet = new Set(currentSet);
        if (newSet.has(itemId)) {
            newSet.delete(itemId);
        } else {
            newSet.add(itemId);
        }
        return newSet;
    });
  }

  isSubMenuOpen(itemId: string): boolean {
    return this.openSubMenus().has(itemId);
  }
}
