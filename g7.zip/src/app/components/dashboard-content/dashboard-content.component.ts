import { ChangeDetectionStrategy, Component, signal, input, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserRole } from '../../app.component';
import { RbacConfigComponent } from '../rbac-config/rbac-config.component';
import { FeatureConfigComponent } from '../feature-config/feature-config.component';
import { RbacService, User } from '../../services/rbac.service';
import { ConfirmationDialogComponent } from '../confirmation-dialog/confirmation-dialog.component';
import { UserModuleMappingComponent } from '../user-module-mapping/user-module-mapping.component';

@Component({
  selector: 'app-dashboard-content',
  templateUrl: './dashboard-content.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, RbacConfigComponent, FeatureConfigComponent, ConfirmationDialogComponent, UserModuleMappingComponent],
})
export class DashboardContentComponent {
  currentUser = input.required<User>();

  rbacService = inject(RbacService);

  activeTab = signal<'rbac' | 'feature' | 'user-module-mapping'>('rbac');
  
  // For tab switching confirmation
  isSwitchTabConfirmOpen = signal(false);
  private targetTab = signal<'rbac' | 'feature' | 'user-module-mapping'>('rbac');

  selectTab(newTab: 'rbac' | 'feature' | 'user-module-mapping'): void {
    const currentTab = this.activeTab();
    if (newTab === currentTab) {
      return;
    }

    let isCurrentTabDirty = false;
    switch(currentTab) {
        case 'rbac': isCurrentTabDirty = this.rbacService.rbacDirty(); break;
        case 'feature': isCurrentTabDirty = this.rbacService.featureDirty(); break;
        case 'user-module-mapping': isCurrentTabDirty = this.rbacService.userModuleMappingDirty(); break;
    }

    if (isCurrentTabDirty) {
      this.targetTab.set(newTab);
      this.isSwitchTabConfirmOpen.set(true);
    } else {
      this.activeTab.set(newTab);
    }
  }

  confirmSwitchTab(): void {
    const currentTab = this.activeTab();
    switch(currentTab) {
        case 'rbac': this.rbacService.discardRbacChanges$.next(); break;
        case 'feature': this.rbacService.discardFeatureChanges$.next(); break;
        case 'user-module-mapping': this.rbacService.discardUserModuleMappingChanges$.next(); break;
    }
    this.activeTab.set(this.targetTab());
    this.isSwitchTabConfirmOpen.set(false);
  }

  cancelSwitchTab(): void {
    this.isSwitchTabConfirmOpen.set(false);
  }
}