import { ChangeDetectionStrategy, Component, computed, effect, ElementRef, inject, OnDestroy, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RbacService, MenuItem } from '../../services/rbac.service';
import { Subscription } from 'rxjs';
import { ConfirmationDialogComponent } from '../confirmation-dialog/confirmation-dialog.component';

interface AppRoute {
  path: string;
  name: string;
}

interface AppIcon {
  name: string;
  id: string;
}

const MAX_LABEL_LENGTH = 50;

@Component({
  selector: 'app-feature-config',
  templateUrl: './feature-config.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, ConfirmationDialogComponent],
  host: {
    '(document:click)': 'onDocumentClick($event)',
  }
})
export class FeatureConfigComponent implements OnDestroy {
  private rbacService = inject(RbacService);
  private subscriptions = new Subscription();
  private elementRef = inject(ElementRef);

  allFeatures = signal<MenuItem[]>([]);
  searchTerm = signal<string>('');
  
  private initialFeatures: MenuItem[] = [];

  // Local state for confirmation dialogs
  isConfirmSaveOpen = signal(false);
  isConfirmDiscardOpen = signal(false);
  isConfirmDeleteOpen = signal(false);
  itemToDelete = signal<{ id: string } | null>(null);

  successMessage = signal('');
  private successMessageTimeout: any;
  
  // For drag and drop
  draggedItemId = signal<string | null>(null);
  dragOverId = signal<string | null>(null);
  dropPosition = signal<'before' | 'after' | null>(null);

  // For inline description editing
  editingDescriptionId = signal<string | null>(null);
  editingDescriptionValue = signal<string>('');

  // For inline label editing
  editingLabelId = signal<string | null>(null);
  editingLabelValue = signal<string>('');
  editingLabelError = signal<string | null>(null);

  // For Add/Edit Menu Item Modal
  isMenuModalOpen = signal(false);
  menuItemLabel = signal('');
  menuItemDescription = signal('');
  menuItemRoute = signal<string>('');
  menuItemIcon = signal<string>('');
  menuItemValidationError = signal<string | null>(null);
  menuItemRouteError = signal<string | null>(null);
  maxLabelLength = MAX_LABEL_LENGTH;

  isIconPickerOpen = signal(false);
  iconSearchTerm = signal('');

  availableRoutes: AppRoute[] = [
    { path: '/dashboard', name: 'Dashboard' },
    { path: '/user-access', name: 'User Access Management' },
    { path: '/service-desk', name: 'Service Desk' },
    { path: '/reports', name: 'Reports' },
    { path: '/file-upload', name: 'File Upload' },
    { path: '/config/staffing', name: 'Staffing Ops Config' },
  ];

  availableIcons: AppIcon[] = [
    { name: 'Dashboard', id: 'dashboard' },
    { name: 'Users', id: 'group' },
    { name: 'Support', id: 'support_agent' },
    { name: 'Settings', id: 'settings' },
    { name: 'Reports', id: 'assessment' },
    { name: 'Analytics', id: 'analytics' },
    { name: 'Building', id: 'business' },
    { name: 'Briefcase', id: 'work' },
    { name: 'Upload', id: 'upload_file' },
    { name: 'Download', id: 'download' },
    { name: 'History', id: 'history' },
    { name: 'Security', id: 'security' },
    { name: 'Star', id: 'star' },
    { name: 'Globe', id: 'public' },
    { name: 'Tasks', id: 'task_alt' },
    { name: 'Megaphone', id: 'campaign' },
    { name: 'View Grid', id: 'grid_view' },
  ];

  filteredIcons = computed(() => {
    const term = this.iconSearchTerm().toLowerCase();
    if (!term) return this.availableIcons;
    return this.availableIcons.filter(icon => icon.name.toLowerCase().includes(term));
  });

  isDirty = computed(() => {
    return JSON.stringify(this.initialFeatures) !== JSON.stringify(this.allFeatures());
  });

  filteredFeatures = computed(() => {
    const term = this.searchTerm().toLowerCase().trim();
    if (!term) {
      return this.allFeatures();
    }

    return this.allFeatures().filter(feature => 
      feature.label.toLowerCase().includes(term) || feature.description?.toLowerCase().includes(term)
    );
  });

  constructor() {
    this.loadInitialState();
    
    effect(() => {
      this.rbacService.featureDirty.set(this.isDirty());
    });

    this.subscriptions.add(
      this.rbacService.discardFeatureChanges$.subscribe(() => {
        this.resetState();
      })
    );
  }
  
  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  private showSuccessMessage(message: string): void {
    this.successMessage.set(message);
    clearTimeout(this.successMessageTimeout);
    this.successMessageTimeout = setTimeout(() => this.successMessage.set(''), 3000);
  }

  onDocumentClick(event: MouseEvent): void {
    if (this.isIconPickerOpen() && !this.elementRef.nativeElement.querySelector('.icon-picker-container')?.contains(event.target)) {
        this.isIconPickerOpen.set(false);
    }
  }

  private loadInitialState(): void {
    const features = this.rbacService.getRawFeatures();
    // Deep copy for pristine state
    this.initialFeatures = JSON.parse(JSON.stringify(features));
    this.allFeatures.set(JSON.parse(JSON.stringify(features)));
  }

  private resetState(): void {
    this.allFeatures.set(JSON.parse(JSON.stringify(this.initialFeatures)));
    this.cancelDescriptionEdit();
    this.cancelLabelEdit();
  }

  onSearchTermChange(event: Event): void {
    this.searchTerm.set((event.target as HTMLInputElement).value);
  }

  onStatusChange(featureId: string, event: Event): void {
    const isActive = (event.target as HTMLInputElement).checked;

    this.allFeatures.update(features => {
      return features.map(item => {
        if (item.id === featureId) {
          return { ...item, isActive };
        }
        return item;
      });
    });
  }
  
  private validateLabel(label: string, idToIgnore: string | null): string | null {
    const trimmedLabel = label.trim();
    if (trimmedLabel.length > MAX_LABEL_LENGTH) {
      return `Label cannot exceed ${MAX_LABEL_LENGTH} characters.`;
    }
    
    const isDuplicate = this.allFeatures().some(item => 
      item.id !== idToIgnore && item.label.trim().toLowerCase() === trimmedLabel.toLowerCase()
    );

    if (isDuplicate) {
      return "Another menu item already has this label.";
    }

    return null;
  }

  private validateRoute(route: string): string | null {
    if (!route) {
        return null; // No route selected, so no error.
    }

    const isDuplicate = this.allFeatures().some(item => item.route === route);

    if (isDuplicate) {
        return "This route is already in use.";
    }

    return null;
  }

  // --- Label Edit Handlers ---
  startEditingLabel(item: MenuItem): void {
    if (this.editingDescriptionId() !== null) return; // Prevent simultaneous editing
    this.editingLabelId.set(item.id);
    this.editingLabelValue.set(item.label);
    this.editingLabelError.set(null);
  }

  saveLabelEdit(): void {
    const idToUpdate = this.editingLabelId();
    if (!idToUpdate) return;
    
    const validationError = this.validateLabel(this.editingLabelValue(), idToUpdate);

    if (validationError) {
      this.editingLabelError.set(validationError);
      return;
    }

    const newLabel = this.editingLabelValue().trim();
    if (!newLabel) return;

    this.allFeatures.update(currentFeatures => currentFeatures.map(item => {
        if (item.id === idToUpdate) {
            return { ...item, label: newLabel };
        }
        return item;
    }));
    this.cancelLabelEdit();
  }

  cancelLabelEdit(): void {
    this.editingLabelId.set(null);
    this.editingLabelValue.set('');
    this.editingLabelError.set(null);
  }


  // --- Description Edit Handlers ---
  startEditingDescription(feature: MenuItem): void {
    if (this.editingLabelId() !== null) return; // Prevent simultaneous editing
    this.editingDescriptionId.set(feature.id);
    this.editingDescriptionValue.set(feature.description || '');
  }

  saveDescriptionEdit(): void {
    const idToUpdate = this.editingDescriptionId();
    if (!idToUpdate) return;
    
    const newDescription = this.editingDescriptionValue();

    this.allFeatures.update(currentFeatures => currentFeatures.map(item => {
        if (item.id === idToUpdate) {
            return { ...item, description: newDescription };
        }
        return item;
    }));
    this.cancelDescriptionEdit();
  }

  cancelDescriptionEdit(): void {
    this.editingDescriptionId.set(null);
    this.editingDescriptionValue.set('');
  }

  // --- Drag and Drop Handlers ---
  onDragStart(event: DragEvent, featureId: string): void {
    event.dataTransfer?.setData('text/plain', featureId);
    event.dataTransfer!.effectAllowed = 'move';
    this.draggedItemId.set(featureId);
  }

  onDragOver(event: DragEvent, featureId: string): void {
    event.preventDefault();
    const draggedItemId = this.draggedItemId();
    if (draggedItemId && draggedItemId !== featureId) {
        const rect = (event.currentTarget as HTMLElement).getBoundingClientRect();
        const isAfter = event.clientY > rect.top + rect.height / 2;
        this.dropPosition.set(isAfter ? 'after' : 'before');
        this.dragOverId.set(featureId);
    }
  }

  onDragLeave(event: DragEvent): void {
    event.preventDefault();
    this.dragOverId.set(null);
    this.dropPosition.set(null);
  }

  onDrop(event: DragEvent, targetFeatureId: string): void {
    event.preventDefault();
    const draggedItemId = this.draggedItemId();
    const dropPos = this.dropPosition();

    // Reset drag state immediately
    this.dragOverId.set(null);
    this.dropPosition.set(null);
    this.draggedItemId.set(null);

    if (!draggedItemId || draggedItemId === targetFeatureId) {
      return;
    }

    this.allFeatures.update(currentFeatures => {
      const newFeatures = JSON.parse(JSON.stringify(currentFeatures));
      
      const draggedIndex = newFeatures.findIndex((item: MenuItem) => item.id === draggedItemId);
      let targetIndex = newFeatures.findIndex((item: MenuItem) => item.id === targetFeatureId);

      if (draggedIndex === -1 || targetIndex === -1) {
        return currentFeatures;
      }
      
      const [draggedItem] = newFeatures.splice(draggedIndex, 1);
      
      // Adjust target index if item was moved from before the target
      targetIndex = newFeatures.findIndex((item: MenuItem) => item.id === targetFeatureId);

      if (dropPos === 'after') {
        targetIndex++;
      }
      newFeatures.splice(targetIndex, 0, draggedItem);
      
      return newFeatures;
    });
  }

  // --- Add/Edit Modal Handlers ---
  onModalLabelChange(value: string) {
    this.menuItemLabel.set(value);
    const validationError = this.validateLabel(value, null);
    this.menuItemValidationError.set(validationError);
  }

  onModalRouteChange(value: string) {
    this.menuItemRoute.set(value);
    const validationError = this.validateRoute(value);
    this.menuItemRouteError.set(validationError);
  }

  openNewMenuModal(): void {
    this.menuItemLabel.set('');
    this.menuItemDescription.set('');
    this.menuItemRoute.set('');
    this.menuItemIcon.set('');
    this.menuItemValidationError.set(null);
    this.menuItemRouteError.set(null);
    this.isMenuModalOpen.set(true);
  }

  closeMenuModal(): void {
    this.isMenuModalOpen.set(false);
    this.isIconPickerOpen.set(false);
    this.iconSearchTerm.set('');
  }

  selectIcon(iconId: string): void {
    this.menuItemIcon.set(iconId);
    this.isIconPickerOpen.set(false);
  }

  saveMenuItem(): void {
    const label = this.menuItemLabel().trim();
    if (!label || this.menuItemValidationError() || this.menuItemRouteError()) return;

    const newItem: MenuItem = {
      id: label.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') + `-${Date.now()}`,
      label: label,
      description: this.menuItemDescription().trim(),
      route: this.menuItemRoute(),
      icon: this.menuItemIcon(),
      isActive: true,
    };
    
    this.allFeatures.update(features => [...features, newItem]);
    this.closeMenuModal();
  }
  
  // --- Delete Handlers ---
  promptDeleteMenuItem(id: string): void {
    this.itemToDelete.set({ id });
    this.isConfirmDeleteOpen.set(true);
  }

  onConfirmDelete(): void {
    const idToDelete = this.itemToDelete()?.id;
    if (!idToDelete) return;
    
    this.allFeatures.update(features => features.filter(item => item.id !== idToDelete));
    this.onCancelDelete();
  }

  onCancelDelete(): void {
    this.isConfirmDeleteOpen.set(false);
    this.itemToDelete.set(null);
  }

  // --- Local Save/Discard with Confirmation ---
  saveChanges(): void {
    if (!this.isDirty()) return;
    this.isConfirmSaveOpen.set(true);
  }

  discardChanges(): void {
    if (!this.isDirty()) return;
    this.isConfirmDiscardOpen.set(true);
  }

  onConfirmSave(): void {
    this.rbacService.updateFeatures(this.allFeatures());
    this.loadInitialState(); // Reloads and resets dirty state
    this.isConfirmSaveOpen.set(false);
    this.showSuccessMessage('Menu structure changes saved successfully.');
  }

  onCancelSave(): void {
    this.isConfirmSaveOpen.set(false);
  }

  onConfirmDiscard(): void {
    this.resetState();
    this.isConfirmDiscardOpen.set(false);
    this.showSuccessMessage('Unsaved changes to the menu structure have been discarded.');
  }

  onCancelDiscard(): void {
    this.isConfirmDiscardOpen.set(false);
  }

  getSelectedIconName(): string {
    const selectedId = this.menuItemIcon();
    if (!selectedId) return 'Select Icon';
    const icon = this.availableIcons.find(i => i.id === selectedId);
    return icon ? icon.name : 'Select Icon';
  }
}
