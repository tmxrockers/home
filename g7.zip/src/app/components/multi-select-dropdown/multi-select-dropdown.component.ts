import { ChangeDetectionStrategy, Component, computed, ElementRef, inject, input, output, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-multi-select-dropdown',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './multi-select-dropdown.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: {
    '(document:click)': 'onDocumentClick($event)',
  }
})
export class MultiSelectDropdownComponent {
  private elementRef = inject(ElementRef);

  options = input.required<string[]>();
  label = input<string>('Select Options');
  selectedOptions = input<Set<string>>(new Set());
  selectionChange = output<Set<string>>();
  
  isOpen = signal(false);
  searchTerm = signal('');

  filteredOptions = computed(() => {
    const term = this.searchTerm().toLowerCase();
    if (!term) {
      return this.options();
    }
    return this.options().filter(opt => this.formatOption(opt).toLowerCase().includes(term));
  });

  toggleDropdown(event: MouseEvent): void {
    event.stopPropagation();
    this.isOpen.update(v => !v);
  }

  onDocumentClick(event: Event): void {
    if (this.isOpen() && !this.elementRef.nativeElement.contains(event.target)) {
      this.isOpen.set(false);
    }
  }

  onOptionToggle(option: string): void {
    const newSelection = new Set(this.selectedOptions());
    if (newSelection.has(option)) {
      newSelection.delete(option);
    } else {
      newSelection.add(option);
    }
    this.selectionChange.emit(newSelection);
  }

  onSearchChange(event: Event): void {
    this.searchTerm.set((event.target as HTMLInputElement).value);
  }

  clearSelection(event: MouseEvent): void {
    event.stopPropagation();
    if (this.selectedOptions().size > 0) {
      this.selectionChange.emit(new Set());
    }
  }
  
  formatOption(option: string): string {
    const roleName = option.replace('dataLoader', 'Data Loader')
                         .replace('staffingOps', 'Staffing Ops')
                         .replace('hrPartner', 'HR Partner')
                         .replace('financeAnalyst', 'Finance Analyst')
                         .replace('itSupport', 'IT Support');
    return roleName.charAt(0).toUpperCase() + roleName.slice(1);
  }
}