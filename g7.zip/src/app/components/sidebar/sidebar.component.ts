import { ChangeDetectionStrategy, Component, computed, inject, input, output, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RbacService, User, MenuItem } from '../../services/rbac.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule],
})
export class SidebarComponent {
  isOpen = input<boolean>(true);
  user = input.required<User>();
  activeItem = input<string>('dashboard');
  closeSidebar = output<void>();
  itemSelected = output<string>();

  menuSearchTerm = signal('');

  private rbacService = inject(RbacService);
  
  menuItems = computed(() => {
    const allItems = this.rbacService.getFeaturesForUser(this.user());
    const term = this.menuSearchTerm().toLowerCase().trim();

    if (!term) {
      return allItems;
    }
    
    return allItems.filter(item => item.label.toLowerCase().includes(term));
  });

  formattedRole = computed(() => {
    const role = this.user().role;
    const roleName = role.replace('dataLoader', 'Data Loader')
                         .replace('staffingOps', 'Staffing Ops')
                         .replace('hrPartner', 'HR Partner')
                         .replace('financeAnalyst', 'Finance Analyst')
                         .replace('itSupport', 'IT Support');
    return roleName.charAt(0).toUpperCase() + roleName.slice(1);
  });

  onMenuSearch(event: Event): void {
    const term = (event.target as HTMLInputElement).value;
    this.menuSearchTerm.set(term);
  }

  selectItem(id: string): void {
    this.itemSelected.emit(id);
  }
}
