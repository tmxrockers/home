import { ChangeDetectionStrategy, Component, inject, signal, effect, computed, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RbacService, MenuItem, User } from '../../services/rbac.service';
import { UserRole } from '../../app.component';
import { Subscription } from 'rxjs';
import { ConfirmationDialogComponent } from '../confirmation-dialog/confirmation-dialog.component';
import { MultiSelectDropdownComponent } from '../multi-select-dropdown/multi-select-dropdown.component';

type PermissionSource = 'none' | 'role' | 'grant' | 'revoke';
interface PermissionState {
  hasPermission: boolean;
  source: PermissionSource;
}

type SortDirection = 'asc' | 'desc';

@Component({
  selector: 'app-user-module-mapping',
  templateUrl: './user-module-mapping.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, ConfirmationDialogComponent, MultiSelectDropdownComponent],
})
export class UserModuleMappingComponent implements OnDestroy {
  rbacService = inject(RbacService);
  private subscriptions = new Subscription();

  allUsers = signal<User[]>([]);
  allFeatures = signal<MenuItem[]>([]);
  allAppRoles = signal<UserRole[]>([]);
  
  selectedUser = signal<User | null>(null);
  userSearchTerm = signal('');
  featureSearchTerm = signal('');

  // --- New state for pagination and filtering ---
  selectedRoleFilters = signal<Set<UserRole>>(new Set());
  currentPage = signal(1);
  pageSize = signal(15);
  sortDirection = signal<SortDirection>('asc');

  // State for pending changes for the selected user
  private initialOverrides: { granted: Set<string>, revoked: Set<string> } = { granted: new Set(), revoked: new Set() };
  pendingOverrides = signal<{ granted: Set<string>, revoked: Set<string> }>({ granted: new Set(), revoked: new Set() });
  
  private rolePermissions = signal<Set<string>>(new Set());

  // Local state for confirmation dialogs
  isConfirmSaveOpen = signal(false);
  isConfirmDiscardOpen = signal(false);
  isSwitchUserConfirmOpen = signal(false);
  isResetConfirmOpen = signal(false);
  private targetUser = signal<User | null>(null);
  
  successMessage = signal('');
  private successMessageTimeout: any;

  // --- Computed signals for user list management ---
  filteredAndSortedUsers = computed(() => {
    const term = this.userSearchTerm().toLowerCase();
    const roleFilters = this.selectedRoleFilters();
    const direction = this.sortDirection();
    
    let users = this.allUsers();

    if (roleFilters.size > 0) {
      users = users.filter(u => roleFilters.has(u.role));
    }

    if (term) {
      users = users.filter(u => u.name.toLowerCase().includes(term) || u.email.toLowerCase().includes(term));
    }
    
    return [...users].sort((a, b) => {
      const valA = a.name.toLowerCase();
      const valB = b.name.toLowerCase();
      const comparison = valA.localeCompare(valB);
      return direction === 'asc' ? comparison : -comparison;
    });
  });

  totalUsers = computed(() => this.filteredAndSortedUsers().length);
  totalPages = computed(() => Math.ceil(this.totalUsers() / this.pageSize()));

  paginatedUsers = computed(() => {
      const users = this.filteredAndSortedUsers();
      const page = this.currentPage();
      const size = this.pageSize();
      const startIndex = (page - 1) * size;
      return users.slice(startIndex, startIndex + size);
  });

  paginationEndIndex = computed(() => {
    return Math.min(this.currentPage() * this.pageSize(), this.totalUsers());
  });

  filteredFeatures = computed(() => {
    const term = this.featureSearchTerm().toLowerCase().trim();
    if (!term) return this.allFeatures();

    return this.allFeatures().filter(feature => feature.label.toLowerCase().includes(term));
  });

  hasOverrides = computed(() => {
    const { granted, revoked } = this.pendingOverrides();
    return granted.size > 0 || revoked.size > 0;
  });

  constructor() {
    const users = this.rbacService.getUsers();
    this.allUsers.set(users);
    this.allFeatures.set(this.rbacService.getActiveFeatures());
    this.allAppRoles.set(this.rbacService.getRoles().map(role => role.id));

    if (users.length > 0) {
      this.performUserSwitch(users[0]);
    }
    
    effect(() => {
      const initial = this.initialOverrides;
      const pending = this.pendingOverrides();
      const isDirty = initial.granted.size !== pending.granted.size || initial.revoked.size !== pending.revoked.size ||
                      ![...pending.granted].every(p => initial.granted.has(p)) ||
                      ![...pending.revoked].every(p => initial.revoked.has(p));
      this.rbacService.userModuleMappingDirty.set(isDirty);
    });

    this.subscriptions.add(
      this.rbacService.discardUserModuleMappingChanges$.subscribe(() => this.resetState())
    );
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  private showSuccessMessage(message: string): void {
    this.successMessage.set(message);
    clearTimeout(this.successMessageTimeout);
    this.successMessageTimeout = setTimeout(() => this.successMessage.set(''), 3000);
  }

  toggleSortDirection(): void {
    this.sortDirection.update(dir => (dir === 'asc' ? 'desc' : 'asc'));
    this.currentPage.set(1);
  }

  onUserSearch(term: string): void {
    this.userSearchTerm.set(term);
    this.currentPage.set(1);
  }

  onRoleFilterChange(selectedRoles: Set<UserRole>): void {
    this.selectedRoleFilters.set(selectedRoles);
    this.currentPage.set(1);
  }

  goToPage(page: number): void {
    if (page >= 1 && page <= this.totalPages()) {
        this.currentPage.set(page);
    }
  }

  selectUser(user: User): void {
    if (this.selectedUser()?.id === user.id) {
      return;
    }

    if (this.rbacService.userModuleMappingDirty()) {
      this.targetUser.set(user);
      this.isSwitchUserConfirmOpen.set(true);
    } else {
      this.performUserSwitch(user);
    }
  }

  private performUserSwitch(user: User): void {
    this.selectedUser.set(user);
    this.rolePermissions.set(new Set(this.rbacService.getRolePermissions(user.role)));
    this.resetState();
  }

  private resetState(): void {
    const user = this.selectedUser();
    if (!user) return;
    const overrides = this.rbacService.getUserPermissionOverrides(user.id);
    this.initialOverrides = { granted: new Set(overrides.granted), revoked: new Set(overrides.revoked) };
    this.pendingOverrides.set({ granted: new Set(overrides.granted), revoked: new Set(overrides.revoked) });
  }

  getPermissionState(featureId: string): PermissionState {
    const rolePerms = this.rolePermissions();
    const overrides = this.pendingOverrides();
    const isGranted = overrides.granted.has(featureId);
    const isRevoked = overrides.revoked.has(featureId);
    const isFromRole = rolePerms.has(featureId);

    if (isGranted) return { hasPermission: true, source: 'grant' };
    if (isRevoked) return { hasPermission: false, source: 'revoke' };
    if (isFromRole) return { hasPermission: true, source: 'role' };
    return { hasPermission: false, source: 'none' };
  }

  onTogglePermission(featureId: string): void {
    const state = this.getPermissionState(featureId);
    // Flip the effective permission state
    this.togglePermission(featureId, !state.hasPermission);
  }

  private togglePermission(featureId: string, isChecked: boolean): void {
    const rolePerms = this.rolePermissions();
    this.pendingOverrides.update(({ granted, revoked }) => {
      const newGranted = new Set(granted);
      const newRevoked = new Set(revoked);
      const isFromRole = rolePerms.has(featureId);

      if (isChecked) { // Granting permission
        newRevoked.delete(featureId);
        if (!isFromRole) newGranted.add(featureId);
      } else { // Revoking permission
        newGranted.delete(featureId);
        if (isFromRole) newRevoked.add(featureId);
      }
      return { granted: newGranted, revoked: newRevoked };
    });
  }

  private saveCurrentUserChanges(): void {
    const user = this.selectedUser();
    if (!user) return;
    const { granted, revoked } = this.pendingOverrides();
    this.rbacService.setUserPermissionOverrides(user.id, {
      granted: Array.from(granted),
      revoked: Array.from(revoked),
    });
    this.resetState();
  }

  saveChanges(): void {
    if (!this.rbacService.userModuleMappingDirty()) return;
    this.isConfirmSaveOpen.set(true);
  }

  discardChanges(): void {
    if (!this.rbacService.userModuleMappingDirty()) return;
    this.isConfirmDiscardOpen.set(true);
  }

  onConfirmSave(): void {
    this.saveCurrentUserChanges();
    this.isConfirmSaveOpen.set(false);
    this.showSuccessMessage('Permission overrides saved successfully.');
  }
  
  onCancelSave = () => this.isConfirmSaveOpen.set(false);
  onConfirmDiscard = () => {
    this.resetState();
    this.isConfirmDiscardOpen.set(false);
    this.showSuccessMessage('Unsaved changes have been discarded.');
  }
  onCancelDiscard = () => this.isConfirmDiscardOpen.set(false);

  // --- Bulk Reset Logic ---
  promptResetAllOverrides(): void {
    if (!this.hasOverrides()) return;
    this.isResetConfirmOpen.set(true);
  }

  onConfirmResetAll(): void {
    this.pendingOverrides.set({ granted: new Set(), revoked: new Set() });
    this.isResetConfirmOpen.set(false);
  }

  onCancelResetAll(): void {
    this.isResetConfirmOpen.set(false);
  }

  // Handlers for the user switch confirmation dialog
  confirmSaveAndSwitch(): void {
    this.saveCurrentUserChanges();
    const userToSwitchTo = this.targetUser();
    if (userToSwitchTo) {
      this.performUserSwitch(userToSwitchTo);
    }
    this.isSwitchUserConfirmOpen.set(false);
    this.targetUser.set(null);
    this.showSuccessMessage('Permission overrides saved successfully.');
  }

  confirmDiscardAndSwitch(): void {
    this.resetState(); // Discard changes for current user.
    const userToSwitchTo = this.targetUser();
    if (userToSwitchTo) {
      this.performUserSwitch(userToSwitchTo);
    }
    this.isSwitchUserConfirmOpen.set(false);
    this.targetUser.set(null);
    this.showSuccessMessage('Unsaved changes have been discarded.');
  }

  cancelSwitchUser(): void {
    this.isSwitchUserConfirmOpen.set(false);
    this.targetUser.set(null);
  }

  getFormattedRole(role: UserRole): string {
    const roleName = role.replace('dataLoader', 'Data Loader')
                         .replace('staffingOps', 'Staffing Ops')
                         .replace('hrPartner', 'HR Partner')
                         .replace('financeAnalyst', 'Finance Analyst')
                         .replace('itSupport', 'IT Support');
    return roleName.charAt(0).toUpperCase() + roleName.slice(1);
  }

  getRoleClass(role: UserRole): string {
    switch (role) {
      case 'admin': return 'bg-purple-200 text-purple-800';
      case 'dataLoader': return 'bg-green-200 text-green-800';
      case 'staffingOps': return 'bg-yellow-200 text-yellow-800';
      case 'auditor': return 'bg-indigo-200 text-indigo-800';
      case 'manager': return 'bg-sky-200 text-sky-800';
      case 'hrPartner': return 'bg-rose-200 text-rose-800';
      case 'financeAnalyst': return 'bg-teal-200 text-teal-800';
      case 'itSupport': return 'bg-slate-200 text-slate-800';
      default: return 'bg-gray-200 text-gray-800';
    }
  }

  getToggleBgClass(state: PermissionState): string {
    if (state.source === 'grant') return 'bg-green-600';
    if (state.source === 'revoke') return 'bg-red-600';
    if (state.source === 'role') return 'bg-blue-600';
    return 'bg-gray-300';
  }

  getPermissionBarClass(state: PermissionState): string {
    switch (state.source) {
      case 'grant': return 'bg-green-500';
      case 'revoke': return 'bg-red-500';
      case 'role': return 'bg-blue-500';
      default: return 'bg-gray-300';
    }
  }

  resetPermission(featureId: string): void {
    this.pendingOverrides.update(({ granted, revoked }) => {
      const newGranted = new Set(granted);
      const newRevoked = new Set(revoked);
      
      newGranted.delete(featureId);
      newRevoked.delete(featureId);
      
      return { granted: newGranted, revoked: newRevoked };
    });
  }
}
