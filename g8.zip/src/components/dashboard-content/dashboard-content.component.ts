import { ChangeDetectionStrategy, Component, signal, input, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RbacConfigComponent } from '../rbac-config/rbac-config.component';
import { FeatureConfigComponent } from '../feature-config/feature-config.component';
import { RbacService, User } from '../../app/services/rbac.service';
import { ConfirmationDialogComponent } from '../confirmation-dialog/confirmation-dialog.component';

@Component({
  selector: 'app-dashboard-content',
  templateUrl: './dashboard-content.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, RbacConfigComponent, FeatureConfigComponent, ConfirmationDialogComponent],
})
export class DashboardContentComponent {
  currentUser = input.required<User>();

  rbacService = inject(RbacService);

  activeTab = signal<'rbac' | 'feature'>('rbac');
  
  // For tab switching confirmation
  isSwitchTabConfirmOpen = signal(false);
  private targetTab = signal<'rbac' | 'feature'>('rbac');

  selectTab(newTab: 'rbac' | 'feature'): void {
    const currentTab = this.activeTab();
    if (newTab === currentTab) {
      return;
    }

    let isCurrentTabDirty = false;
    switch(currentTab) {
        case 'rbac': isCurrentTabDirty = this.rbacService.permissionsDirty(); break;
        case 'feature': isCurrentTabDirty = this.rbacService.featureDirty(); break;
    }

    if (isCurrentTabDirty) {
      this.targetTab.set(newTab);
      this.isSwitchTabConfirmOpen.set(true);
    } else {
      this.activeTab.set(newTab);
    }
  }

  confirmSwitchTab(): void {
    const currentTab = this.activeTab();
    switch(currentTab) {
        case 'rbac': this.rbacService.discardPermissionsChanges$.next(); break;
        case 'feature': this.rbacService.discardFeatureChanges$.next(); break;
    }
    this.activeTab.set(this.targetTab());
    this.isSwitchTabConfirmOpen.set(false);
  }

  cancelSwitchTab(): void {
    this.isSwitchTabConfirmOpen.set(false);
  }
}
