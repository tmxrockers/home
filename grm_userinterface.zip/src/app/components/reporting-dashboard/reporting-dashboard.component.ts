import { ChangeDetectionStrategy, Component, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';

interface Report {
  id: string;
  categoryId: string;
  name: string;
  description: string;
  icon: string;
}
interface ReportCategory {
  id: string;
  name: string;
  description: string;
  count: number;
  reports: Report[];
}

@Component({
  selector: 'app-reporting-dashboard',
  imports: [CommonModule],
  templateUrl: './reporting-dashboard.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ReportingDashboardComponent {
  activeView = signal<'grid' | 'list'>('grid');
  reportCategories = signal<ReportCategory[]>([]);
  expandedCategories = signal<Set<string>>(new Set());
  searchTerm = signal<string>('');
  
  // State for report detail view
  activeReport = signal<Report | null>(null);
  reportLoading = signal<boolean>(false);

  filteredReportCategories = computed(() => {
    const term = this.searchTerm().toLowerCase().trim();
    if (!term) {
      return this.reportCategories();
    }

    const filtered: ReportCategory[] = [];
    for (const category of this.reportCategories()) {
      const categoryNameMatches = category.name.toLowerCase().includes(term) || category.description.toLowerCase().includes(term);

      const matchingReports = category.reports.filter(report =>
        report.name.toLowerCase().includes(term)
      );

      if (categoryNameMatches || matchingReports.length > 0) {
        filtered.push({
          ...category,
          // If the category name matches, show all its reports, otherwise show only matching reports
          reports: categoryNameMatches ? category.reports : matchingReports,
          count: categoryNameMatches ? category.reports.length : matchingReports.length,
        });
      }
    }
    return filtered;
  });
  
  // Navigation computed properties based on active category
  activeCategory = computed(() => {
    const active = this.activeReport();
    if (!active) return null;
    return this.filteredReportCategories().find(cat => cat.id === active.categoryId) ?? null;
  });

  activeCategoryReports = computed(() => {
    return this.activeCategory()?.reports ?? [];
  });

  currentReportIndexInCategory = computed(() => {
    const active = this.activeReport();
    if (!active) return -1;
    return this.activeCategoryReports().findIndex(report => report.id === active.id);
  });

  previousReport = computed(() => {
    const index = this.currentReportIndexInCategory();
    if (index > 0) {
      return this.activeCategoryReports()[index - 1];
    }
    return null;
  });

  nextReport = computed(() => {
    const index = this.currentReportIndexInCategory();
    const reports = this.activeCategoryReports();
    if (index > -1 && index < reports.length - 1) {
      return this.activeCategoryReports()[index + 1];
    }
    return null;
  });

  constructor() {
    this.reportCategories.set([
      {
        id: 'attrition',
        name: 'Attrition',
        description: 'Monitor and analyze employee turnover rates and trends.',
        count: 2,
        reports: [
          { id: 'sp-attrition', categoryId: 'attrition', name: 'SP Attrition', description: 'Tracks service provider attrition rates over various time periods.', icon: 'trending_down' },
          { id: 'attrition-trends', categoryId: 'attrition', name: 'Attrition Trend Analysis', description: 'Provides in-depth analysis of attrition patterns and predictive trends.', icon: 'show_chart' },
        ]
      },
      {
        id: 'data-quality',
        name: 'Data Quality',
        description: 'Ensure the accuracy and completeness of service provider data.',
        count: 1,
        reports: [
          { id: 'data-quality-sp', categoryId: 'data-quality', name: 'Data Quality - SP', description: 'Dashboard for assessing and improving the quality of service provider data.', icon: 'playlist_add_check' }
        ]
      },
      {
        id: 'financial',
        name: 'Financial',
        description: 'Track financial forecasts, projections, and performance.',
        count: 3,
        reports: [
          { id: 'financial-forecast', categoryId: 'financial', name: 'Financial Forecast', description: 'Displays the current financial forecast based on headcount and cost projections.', icon: 'attach_money' },
          { id: 'financial-forecast-analysis', categoryId: 'financial', name: 'Financial Forecast Analysis', description: 'Analyzes variances and trends in financial forecasting data.', icon: 'bar_chart' },
          { id: 'forecast-vs-projection', categoryId: 'financial', name: 'Forecast Vs Projection', description: 'Compares financial forecasts against original projections to identify discrepancies.', icon: 'show_chart' }
        ]
      },
      {
        id: 'headcount',
        name: 'Headcount',
        description: 'Reports on employee numbers, distribution, and monthly changes.',
        count: 2,
        reports: [
          { id: 'monthly-combined-headcount', categoryId: 'headcount', name: 'Monthly Combined Headcount', description: 'Aggregated monthly headcount report for all departments and roles.', icon: 'groups' },
          { id: 'headcount-by-location', categoryId: 'headcount', name: 'Headcount by Location', description: 'Visualizes workforce distribution across different geographical locations.', icon: 'map' },
        ]
      },
      {
        id: 'operations',
        name: 'Operations',
        description: 'Dashboards for tracking operational efficiency and compliance.',
        count: 2,
        reports: [
            { id: 'daily-throughput', categoryId: 'operations', name: 'Daily Throughput', description: 'Measures the daily volume of operational tasks and processes.', icon: 'arrow_forward' },
            { id: 'sla-compliance', categoryId: 'operations', name: 'SLA Compliance Dashboard', description: 'Monitors adherence to Service Level Agreements for key operations.', icon: 'schedule' },
        ]
      },
      {
        id: 'compliance',
        name: 'Compliance',
        description: 'Monitor regulatory compliance and internal training metrics.',
        count: 2,
        reports: [
          { id: 'quarterly-compliance', categoryId: 'compliance', name: 'Quarterly Compliance Summary', description: 'Summarizes compliance status and key metrics for the last quarter.', icon: 'verified_user' },
          { id: 'training-completion', categoryId: 'compliance', name: 'Training Completion Rates', description: 'Tracks the completion rates of mandatory and optional training programs.', icon: 'school' }
        ]
      },
       {
        id: 'workforce',
        name: 'Workforce Planning',
        description: 'Analyze workforce capacity, demand, and skill distribution.',
        count: 2,
        reports: [
            { id: 'capacity-vs-demand', categoryId: 'workforce', name: 'Capacity vs Demand', description: 'Analyzes workforce capacity against project and operational demand.', icon: 'pie_chart' },
            { id: 'skills-gap-analysis', categoryId: 'workforce', name: 'Skills Gap Analysis', description: 'Identifies gaps between required skills and the current workforce\'s skill set.', icon: 'extension' },
        ]
      }
    ]);

    // Expand all categories by default for list view
    this.expandAllCategories();
  }

  isCategoryExpanded(categoryName: string): boolean {
    return this.expandedCategories().has(categoryName);
  }

  expandAllCategories(): void {
    const allCategoryNames = this.reportCategories().map(c => c.name);
    this.expandedCategories.set(new Set(allCategoryNames));
  }
  
  collapseAllCategories(): void {
    this.expandedCategories.set(new Set());
  }

  selectReport(report: Report): void {
    this.activeReport.set(report);
    this.reportLoading.set(true);
    // Simulate loading time for the Tableau report
    setTimeout(() => this.reportLoading.set(false), 1500);
  }

  goBackToDashboard(): void {
    this.activeReport.set(null);
  }

  goToPreviousReport(): void {
    const prev = this.previousReport();
    if (prev) {
      this.selectReport(prev);
    }
  }

  goToNextReport(): void {
    const next = this.nextReport();
    if (next) {
      this.selectReport(next);
    }
  }

  onSearchChange(event: Event): void {
    const newTerm = (event.target as HTMLInputElement).value;
    const oldTerm = this.searchTerm();

    this.searchTerm.set(newTerm);

    if (!oldTerm && newTerm) { // Starting a new search
      setTimeout(() => { // Defer to allow filtered list to update
          this.expandAllCategories();
      }, 0);
    } else if (oldTerm && !newTerm) { // Clearing a search
      this.expandAllCategories();
    }
  }
  
  toggleCategory(categoryName: string): void {
    this.expandedCategories.update(current => {
      const newSet = new Set(current);
      if (newSet.has(categoryName)) {
        newSet.delete(categoryName);
      } else {
        newSet.add(categoryName);
      }
      return newSet;
    });
  }
}