import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RbacService, Role } from '../../services/rbac.service';
import { ConfirmationDialogComponent } from '../confirmation-dialog/confirmation-dialog.component';
import { UserRole } from '../../app';

@Component({
  selector: 'app-roles-config',
  templateUrl: './roles-config.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, ConfirmationDialogComponent],
})
export class RolesConfigComponent {
  rbacService = inject(RbacService);

  roles = signal<Role[]>([]);
  userCounts = signal<Map<UserRole, number>>(new Map());
  searchTerm = signal('');

  isRoleModalOpen = signal(false);
  roleInEdit = signal<Role | null>(null);
  roleName = signal('');
  roleDescription = signal('');
  roleNameError = signal<string | null>(null);

  isDeleteConfirmOpen = signal(false);
  roleToDelete = signal<Role | null>(null);

  successMessage = signal('');
  private successMessageTimeout: any;

  filteredRoles = computed(() => {
    const term = this.searchTerm().toLowerCase();
    if (!term) {
      return this.roles();
    }
    return this.roles().filter(role => 
      role.name.toLowerCase().includes(term) ||
      role.description.toLowerCase().includes(term)
    );
  });

  deleteConfirmationMessage = computed(() => {
    const role = this.roleToDelete();
    if (!role) {
      return 'Are you sure you want to delete this role? This action cannot be undone.';
    }
    return `Are you sure you want to delete the '${role.name}' role? This action cannot be undone.`;
  });

  constructor() {
    this.loadRolesAndCounts();
  }

  private loadRolesAndCounts(): void {
    const allRoles = this.rbacService.getRoles();
    this.roles.set(allRoles);
    const counts = new Map<UserRole, number>();
    for (const role of allRoles) {
      counts.set(role.id, this.rbacService.getUserCountForRole(role.id));
    }
    this.userCounts.set(counts);
  }

  private showSuccessMessage(message: string): void {
    this.successMessage.set(message);
    clearTimeout(this.successMessageTimeout);
    this.successMessageTimeout = setTimeout(() => this.successMessage.set(''), 3000);
  }

  openNewRoleModal(): void {
    this.roleInEdit.set(null);
    this.roleName.set('');
    this.roleDescription.set('');
    this.roleNameError.set(null);
    this.isRoleModalOpen.set(true);
  }

  openEditRoleModal(role: Role): void {
    this.roleInEdit.set(role);
    this.roleName.set(role.name);
    this.roleDescription.set(role.description);
    this.roleNameError.set(null);
    this.isRoleModalOpen.set(true);
  }

  closeRoleModal(): void {
    this.isRoleModalOpen.set(false);
  }
  
  private toCamelCase(str: string): string {
    return str
      .replace(/(?:^\w|[A-Z]|\b\w)/g, (word, index) => 
          index === 0 ? word.toLowerCase() : word.toUpperCase()
      )
      .replace(/\s+/g, '');
  }

  saveRole(): void {
    const newName = this.roleName().trim();
    const newDescription = this.roleDescription().trim();
    if (!newName) {
      this.roleNameError.set('Role name cannot be empty.');
      return;
    }

    const newId = this.toCamelCase(newName) as UserRole;
    const existingRole = this.roleInEdit();

    // Check for duplicate names by comparing the name property directly, case-insensitively.
    if (this.roles().some(r => r.name.trim().toLowerCase() === newName.toLowerCase() && r.id !== existingRole?.id)) {
      this.roleNameError.set('A role with this name already exists.');
      return;
    }
    
    if (existingRole) { // Editing
      const newRoleData = {
        id: existingRole.isCore ? existingRole.id : newId,
        name: newName,
        description: newDescription
      };
      this.rbacService.updateRole(existingRole.id, newRoleData);
      this.showSuccessMessage(`Role '${newName}' updated successfully.`);
    } else { // Creating
      const newRoleData = { id: newId, name: newName, description: newDescription };
      this.rbacService.addRole(newRoleData);
      this.showSuccessMessage(`Role '${newName}' created successfully.`);
    }
    
    this.loadRolesAndCounts();
    this.closeRoleModal();
  }

  promptDeleteRole(role: Role): void {
    this.roleToDelete.set(role);
    this.isDeleteConfirmOpen.set(true);
  }

  confirmDeleteRole(): void {
    const role = this.roleToDelete();
    if (role) {
      if (role.isCore) {
          alert('This is a core role and cannot be deleted.');
      } else {
        this.rbacService.deleteRole(role.id);
        this.loadRolesAndCounts();
        this.showSuccessMessage(`Role '${role.name}' has been deleted.`);
      }
    }
    this.cancelDeleteRole();
  }

  cancelDeleteRole(): void {
    this.isDeleteConfirmOpen.set(false);
    this.roleToDelete.set(null);
  }
}