import { Injectable, signal, WritableSignal, computed } from '@angular/core';
import { UserRole } from '../app';
import { Subject } from 'rxjs';

export interface MenuItem {
  id: string;
  label: string;
  description?: string;
  icon?: string;
  route?: string;
  children?: MenuItem[];
  badge?: number;
  isActive: boolean;
  category?: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
}

export interface Role {
  id: UserRole;
  name: string;
  description: string;
  isCore: boolean;
  icon?: string;
}


@Injectable({ providedIn: 'root' })
export class RbacService {
  // State management for unsaved changes, managed by child components
  permissionsDirty = signal(false);
  featureDirty = signal(false);

  // Subjects for broadcasting actions from parent
  discardPermissionsChanges$ = new Subject<void>();
  discardFeatureChanges$ = new Subject<void>();
  savePermissionsChanges$ = new Subject<void>();
  saveFeatureChanges$ = new Subject<void>();

  // New state for user-specific overrides
  private userPermissionOverrides = signal<Record<string, { granted: string[], revoked: string[] }>>({
     'u2': { granted: ['dashboard'], revoked: ['vu-point'] }
  });

  private allFeatures = signal<MenuItem[]>([
    { id: 'dashboard', label: 'Dashboard', route: '/dashboard', description: 'Main dashboard view.', icon: 'dashboard', isActive: true, category: 'Main' },
    { id: 'user-access', label: 'User Access Management', route: '/user-access', description: 'Configure user roles and permissions.', icon: 'manage_accounts', isActive: true, category: 'Administration' },
    { id: 'roles', label: 'Roles', route: '/config/roles', description: 'Define user roles.', badge: 20, icon: 'shield_person', isActive: true, category: 'Administration' },
    { id: 'staffing-ops', label: 'Staffing Ops Config', route: '/config/staffing', description: 'Configuration for staffing operations.', icon: 'engineering', isActive: true, category: 'Configuration' },
    { id: 'bench-report', label: 'Bench Report Configuration', route: '/config/bench-report', description: 'Configure reports for bench resources.', icon: 'person_search', isActive: true, category: 'Configuration' },
    { id: 'job-title', label: 'Job Title', route: '/config/job-titles', description: 'Manage job titles.', badge: 44, icon: 'work', isActive: true, category: 'Configuration' },
    { id: 'skills', label: 'Skills', route: '/config/skills', description: 'Manage skills taxonomy.', badge: 622, icon: 'psychology', isActive: true, category: 'Configuration' },
    { id: 'tech-vendor', label: 'Tech Vendor/Employee Classification', route: '/config/classification', description: 'Classify tech vendors and employees.', badge: 19, icon: 'business_center', isActive: true, category: 'Configuration' },
    { id: 'announcement', label: 'Announcement Configuration', route: '/config/announcements', description: 'Manage system-wide announcements.', icon: 'campaign', isActive: true, category: 'Configuration' },
    { id: 'rdr2', label: 'RDR 2 Dot Alignment', route: '/tools/rdr2', description: 'Align RDR 2 data points.', badge: 281, icon: 'hub', isActive: true, category: 'Configuration' },
    { id: 'std-view', label: 'Standard View Configuration', route: '/config/standard-view', description: 'Configure standard views.', icon: 'view_quilt', isActive: true, category: 'Configuration' },
    { id: 'grm-config', label: 'GRM Configuration', route: '/config/grm', description: 'General GRM settings.', icon: 'tune', isActive: true, category: 'Configuration' },
    { id: 'gdr-config', label: 'GDR Configuration', route: '/config/gdr', description: 'Configure Global Data Repository.', icon: 'dataset', isActive: true, category: 'Configuration' },
    { id: 'domain', label: 'Domain', route: '/config/domain', description: 'Manage business domains.', badge: 99, icon: 'domain', isActive: true, category: 'Configuration' },
    { id: 'reports', label: 'Reports', route: '/reports', description: 'Access various reports.', icon: 'assessment', isActive: true, category: 'Reporting'},
    { id: 'report-config', label: 'Report Configuration', route: '/reports/config', description: 'Configure report parameters.', icon: 'settings_applications', isActive: true, category: 'Reporting' },
    { id: 'reports-view', label: 'View Reports', route: '/reports/view', description: 'View generated reports.', icon: 'pageview', isActive: true, category: 'Reporting' },
    { id: 'report-usage', label: 'Report Usage', route: '/reports/usage', description: 'Track report usage statistics.', icon: 'query_stats', isActive: true, category: 'Reporting' },
    { id: 'service-desk', label: 'Service Desk', route: '/service-desk', description: 'Access helpdesk tools and resources.', icon: 'support_agent', isActive: true, category: 'Support'},
    { id: 'vu-point', label: 'VU Point', route: '/service-desk/vu-point', description: 'Main service desk interface.', icon: 'desktop_windows', isActive: true, category: 'Support'},
    { id: 'view-favorites', label: 'View Favorites', route: '/service-desk/favorites', description: 'Access your saved items.', icon: 'star', isActive: true, category: 'Support'},
    { id: 'faq', label: 'FAQ', route: '/service-desk/faq', description: 'Frequently asked questions.', icon: 'quiz', isActive: true, category: 'Support'},
    { id: 'service-desk-jira', label: 'Service Desk Jira', route: '/jira', description: 'Jira integration for service desk.', icon: 'view_kanban', isActive: true, category: 'Support' },
    { id: 'grm-extracts', label: 'GRM Extracts', route: '/extracts', description: 'Extract data from GRM.', icon: 'database', isActive: true, category: 'Data Management'},
    { id: 'admin-config', label: 'AdminConfig Dropdown', route: '/extracts/admin-config', description: 'Configure admin dropdowns.', icon: 'arrow_drop_down_circle', badge: 7, isActive: true, category: 'Data Management' },
    { id: 'etl', label: 'ETL Governance', route: '/etl', description: 'Govern ETL processes.', icon: 'sync_alt', isActive: true, category: 'Data Management' },
    { id: 'file-upload', label: 'File Upload', route: '/file-upload', description: 'Upload files to the system.', icon: 'upload_file', isActive: true, category: 'Data Management' },
    { id: 'file-history', label: 'File History', route: '/file-history', description: 'View file upload history.', icon: 'history', isActive: true, category: 'Data Management' },
    { id: 'redeployment', label: 'Redeployment', route: '/redeployment', description: 'Manage employee redeployment.', icon: 'transfer_within_a_station', isActive: true, category: 'HR & Staffing' },
    { id: 'staffing-metrics', label: 'Staffing Metrics', route: '/metrics/staffing', description: 'View staffing related metrics.', icon: 'monitoring', isActive: true, category: 'HR & Staffing' },
  ]);

  private allAppRoles = signal<Role[]>([
    { id: 'admin', name: 'Admin', description: 'Has full access to all system features and configurations.', isCore: true, icon: 'admin_panel_settings' },
    { id: 'dataLoader', name: 'Data Loader', description: 'Can upload and manage data files.', isCore: true, icon: 'upload_file' },
    { id: 'staffingOps', name: 'Staffing Ops', description: 'Manages staffing operations and related configurations.', isCore: true, icon: 'engineering' },
    { id: 'auditor', name: 'Auditor', description: 'Has read-only access to reports and histories for auditing purposes.', isCore: false, icon: 'gavel' },
    { id: 'manager', name: 'Manager', description: 'Can view dashboards, reports, and staffing metrics for their teams.', isCore: false, icon: 'supervisor_account' },
    { id: 'hrPartner', name: 'HR Partner', description: 'Manages HR-related configurations like job titles and skills.', isCore: false, icon: 'handshake' },
    { id: 'financeAnalyst', name: 'Finance Analyst', description: 'Access to financial reports and data extracts.', isCore: false, icon: 'monitoring' },
    { id: 'itSupport', name: 'IT Support', description: 'Access to service desk and support-related tools.', isCore: false, icon: 'support_agent' },
  ]);

  private rolePermissions: WritableSignal<Record<UserRole, string[]>> = signal({
    'admin': ['user-access', 'service-desk', 'vu-point', 'view-favorites', 'faq', 'service-desk-jira', 'staffing-ops', 'bench-report', 'job-title', 'skills', 'tech-vendor', 'roles', 'reports', 'report-config', 'reports-view', 'report-usage', 'announcement', 'rdr2', 'grm-extracts', 'admin-config', 'std-view', 'grm-config', 'gdr-config', 'domain', 'etl', 'file-upload', 'file-history', 'redeployment', 'dashboard', 'staffing-metrics'],
    'dataLoader': ['vu-point', 'reports-view', 'etl', 'file-upload', 'file-history', 'gdr-config', 'redeployment', 'view-favorites'],
    'staffingOps': ['vu-point', 'dashboard', 'reports-view', 'staffing-metrics', 'view-favorites'],
    'auditor': ['reports', 'reports-view', 'report-usage', 'file-history'],
    'manager': ['dashboard', 'reports', 'staffing-metrics', 'vu-point', 'view-favorites'],
    'hrPartner': ['staffing-ops', 'bench-report', 'job-title', 'skills', 'redeployment'],
    'financeAnalyst': ['reports', 'grm-extracts', 'reports-view'],
    'itSupport': ['service-desk', 'vu-point', 'faq', 'service-desk-jira'],
  });

  private users: WritableSignal<User[]>;

  constructor() {
    this.users = signal(this.generateMockUsers());
  }

  getRoles(): Role[] {
    return [...this.allAppRoles()];
  }

  getUserCountForRole(roleId: UserRole): number {
    return this.users().filter(u => u.role === roleId).length;
  }

  addRole(roleData: { id: UserRole; name: string; description: string }): void {
    this.allAppRoles.update(roles => [...roles, { ...roleData, isCore: false, icon: 'shield_person' }]);
    this.setPermissionsForRole(roleData.id, []);
  }

  updateRole(oldId: UserRole, newRoleData: { id: UserRole; name: string; description: string }): void {
    this.allAppRoles.update(roles => 
        roles.map(r => r.id === oldId ? { ...r, id: newRoleData.id, name: newRoleData.name, description: newRoleData.description } : r)
    );
    
    // If ID changed, migrate permissions and users
    if (oldId !== newRoleData.id) {
        const perms = this.getRolePermissions(oldId);
        this.setPermissionsForRole(newRoleData.id, perms);
        this.rolePermissions.update(currentPermissions => {
            const newPerms = {...currentPermissions};
            delete newPerms[oldId];
            return newPerms;
        });

        this.users.update(users => users.map(u => u.role === oldId ? {...u, role: newRoleData.id} : u));
    }
  }

  deleteRole(roleToDelete: UserRole): void {
    this.allAppRoles.update(roles => roles.filter(r => r.id !== roleToDelete));
    this.rolePermissions.update(currentPermissions => {
      const newPerms = {...currentPermissions};
      delete newPerms[roleToDelete];
      return newPerms;
    });
    console.warn(`Role "${roleToDelete}" deleted. Users with this role may need to be reassigned.`);
  }
  
  private generateMockUsers(): User[] {
    const firstNames = ['Samantha', 'John', 'Jane', 'Peter', 'Mary', 'David', 'Susan', 'Michael', 'Linda', 'James', 'Patricia', 'Robert', 'Jennifer', 'William', 'Elizabeth', 'Richard', 'Jessica', 'Joseph', 'Sarah', 'Charles', 'Karen'];
    const lastNames = ['Rogers', 'Doe', 'Smith', 'Jones', 'Williams', 'Brown', 'Davis', 'Miller', 'Wilson', 'Moore', 'Taylor', 'Anderson', 'Thomas', 'Jackson', 'White', 'Harris', 'Martin', 'Thompson', 'Garcia', 'Martinez', 'Robinson'];
    const roles: UserRole[] = this.allAppRoles().map(r => r.id);
    const users: User[] = [];

    // Ensure the main users are present
    users.push({ id: 'u1', name: 'Admin User', email: 'admin@test.com', role: 'admin' });
    users.push({ id: 'u2', name: 'Data Loader User', email: 'dataloader@test.com', role: 'dataLoader' });
    users.push({ id: 'u3', name: 'Staffing Ops User', email: 'staffing@test.com', role: 'staffingOps' });
    users.push({ id: 'u4', name: 'Alex Johnson', email: 'alex.j@example.com', role: 'admin'});
    
    for (let i = 5; i <= 2505; i++) {
        const firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
        const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
        const name = `${firstName} ${lastName}`;
        const email = `${firstName.toLowerCase()}.${lastName.toLowerCase()}${i}@test.com`;
        const role = roles[Math.floor(Math.random() * roles.length)];
        users.push({ id: `u${i}`, name, email, role });
    }
    return users;
  }

  getUsers(): User[] {
    return this.users();
  }

  updateUser(updatedUser: User): void {
    this.users.update(currentUsers => {
      return currentUsers.map(u => u.id === updatedUser.id ? updatedUser : u);
    });
  }

  getRawFeatures(): MenuItem[] {
    return this.allFeatures();
  }

  getActiveFeatures(): MenuItem[] {
    return this.allFeatures().filter(item => item.isActive);
  }
  
  updateFeatures(features: MenuItem[]): void {
    // A deep copy is important here to ensure signals pick up the change
    this.allFeatures.set(JSON.parse(JSON.stringify(features)));
  }

  getRolePermissions(role: UserRole): string[] {
    return this.rolePermissions()[role] || [];
  }

  setPermissionsForRole(role: UserRole, permissions: string[]): void {
    this.rolePermissions.update(currentPermissions => {
      return { ...currentPermissions, [role]: permissions };
    });
  }

  // --- User Permission Overrides ---

  getAllUserPermissionOverrides(): Record<string, { granted: string[], revoked: string[] }> {
    return this.userPermissionOverrides();
  }
  
  getUserPermissionOverrides(userId: string): { granted: string[], revoked: string[] } {
    return this.userPermissionOverrides()[userId] || { granted: [], revoked: [] };
  }

  setUserPermissionOverrides(userId: string, overrides: { granted: string[], revoked: string[] }): void {
    this.userPermissionOverrides.update(currentOverrides => {
      const newOverrides = { ...currentOverrides };
      if (overrides.granted.length === 0 && overrides.revoked.length === 0) {
        delete newOverrides[userId];
      } else {
        newOverrides[userId] = overrides;
      }
      return newOverrides;
    });
  }
  
  getEffectivePermissionsForUser(user: User): Set<string> {
    const rolePermissions = new Set(this.getRolePermissions(user.role));
    const userOverrides = this.getUserPermissionOverrides(user.id);
    
    // Add granted overrides
    userOverrides.granted.forEach(p => rolePermissions.add(p));
    
    // Remove revoked overrides
    userOverrides.revoked.forEach(p => rolePermissions.delete(p));

    return rolePermissions;
  }

  getFeaturesForUser(user: User): MenuItem[] {
    const allowed = this.getEffectivePermissionsForUser(user);

    if (!allowed.size) return [];

    return this.getActiveFeatures().filter(item => allowed.has(item.id));
  }
}